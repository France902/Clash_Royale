<?php
// ============================================================
//  ACCESSO E REGISTRAZIONE
//
//  Una sola pagina con due schede: "Accedi" e "Registrati".
//  Gli account stanno in utenti.json, un VETTORE di ARRAY ASSOCIATIVI:
//    [
//      { "username": "France", "password": "$2y$10$...", "fazione": "rune", "creato": "..." },
//      ...
//    ]
//  La password NON si salva mai in chiaro: password_hash() in registrazione,
//  password_verify() all'accesso.
//  Se l'accesso riesce, i dati del giocatore vanno in $_SESSION e si va
//  all'arena. arena.php controlla la sessione: senza, rimanda qui.
//
// ============================================================

session_start();
require __DIR__ . '/fazioni.php';

// Gia' dentro? Dritto all'arena
if (isset($_SESSION['utente'])) {
    header('Location: arena.php');
    exit;
}

$fileUtenti = __DIR__ . '/utenti.json';


// ---------- FUNZIONI ----------

// Legge tutti gli utenti dal JSON (vettore vuoto se il file non c'e' ancora)
function leggiUtenti($file) {
    if (!is_file($file)) return [];
    $utenti = json_decode(file_get_contents($file), true);
    if (!is_array($utenti)) return [];
    return $utenti;
}

// Riscrive il JSON con tutti gli utenti. LOCK_EX: se due persone si registrano
// nello stesso istante, una aspetta l'altra invece di rovinare il file.
function salvaUtenti($file, $utenti) {
    $json = json_encode($utenti, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    return file_put_contents($file, $json, LOCK_EX) !== false;
}

// Posizione dell'utente nel vettore, oppure -1 se non esiste.
// Il confronto ignora maiuscole e minuscole: "France" e "france" sono lo stesso nome.
function cercaUtente($utenti, $username) {
    foreach ($utenti as $i => $u) {
        if (strtolower($u['username']) === strtolower($username)) return $i;
    }
    return -1;
}

// Mette il giocatore in sessione e lo manda nell'arena
function entra($username, $fazione) {
    session_regenerate_id(true);   // nuovo id di sessione a ogni accesso (piu' sicuro)
    $_SESSION['utente'] = ['username' => $username, 'fazione' => $fazione];
    header('Location: arena.php');
    exit;
}

// Testo sicuro da mettere nell'HTML (niente tag inseriti dall'utente)
function h($testo) {
    return htmlspecialchars($testo, ENT_QUOTES, 'UTF-8');
}


// ---------- GESTIONE DEI FORM ($_POST) ----------

$errori = [];                                      // vettore di messaggi d'errore
$scheda = 'accedi';                                // scheda da mostrare
$vecchi = ['username' => '', 'fazione' => ''];     // per ricompilare il form dopo un errore

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $azione   = $_POST['azione']   ?? '';
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $vecchi['username'] = $username;

    $utenti = leggiUtenti($fileUtenti);

    if ($azione === 'accedi') {
        $i = cercaUtente($utenti, $username);
        if ($username === '' || $password === '') {
            $errori[] = 'Inserisci nome e password.';
        } elseif ($i === -1 || !password_verify($password, $utenti[$i]['password'])) {
            // Stesso messaggio nei due casi: non si rivela se il nome esiste
            $errori[] = 'Nome o password sbagliati.';
        } else {
            entra($utenti[$i]['username'], $utenti[$i]['fazione']);
        }

    } elseif ($azione === 'registrati') {
        $scheda   = 'registrati';
        $conferma = $_POST['conferma'] ?? '';
        $fazione  = $_POST['fazione']  ?? '';
        $vecchi['fazione'] = $fazione;

        if (!preg_match('/^[A-Za-z0-9_]{3,16}$/', $username)) {
            $errori[] = 'Il nome deve avere da 3 a 16 caratteri: lettere, numeri o _.';
        } elseif (cercaUtente($utenti, $username) !== -1) {
            $errori[] = 'Questo nome e\' gia\' preso.';
        }
        if (strlen($password) < 6) {
            $errori[] = 'La password deve avere almeno 6 caratteri.';
        } elseif ($password !== $conferma) {
            $errori[] = 'Le due password non coincidono.';
        }
        if (!isset($fazioni[$fazione])) {
            $errori[] = 'Scegli una fazione.';
        }

        if (count($errori) === 0) {
            $utenti[] = [
                'username' => $username,
                'password' => password_hash($password, PASSWORD_DEFAULT),
                'fazione'  => $fazione,
                'creato'   => date('Y-m-d H:i'),
            ];
            if (salvaUtenti($fileUtenti, $utenti)) {
                entra($username, $fazione);
            }
            $errori[] = 'Impossibile salvare utenti.json: controlla i permessi della cartella.';
        }
    }
}


// ---------- I CAMPI DEI FORM ----------
// Ogni campo e' un array associativo; un foreach li trasforma in HTML.

$campiAccesso = [
    ['name' => 'username', 'type' => 'text',     'label' => 'Nome giocatore', 'placeholder' => 'Il tuo nome',  'auto' => 'username'],
    ['name' => 'password', 'type' => 'password', 'label' => 'Password',       'placeholder' => '••••••',       'auto' => 'current-password'],
];

$campiRegistrazione = [
    ['name' => 'username', 'type' => 'text',     'label' => 'Nome giocatore',    'placeholder' => '3-16 caratteri',     'auto' => 'username'],
    ['name' => 'password', 'type' => 'password', 'label' => 'Password',          'placeholder' => 'Almeno 6 caratteri', 'auto' => 'new-password'],
    ['name' => 'conferma', 'type' => 'password', 'label' => 'Ripeti la password', 'placeholder' => 'Ancora una volta',   'auto' => 'new-password'],
];

// Da un campo (array associativo) al suo HTML. Solo il nome si ricompila:
// le password, per sicurezza, si riscrivono sempre.
function campoHtml($campo, $vecchi) {
    $valore = '';
    if ($campo['type'] !== 'password' && isset($vecchi[$campo['name']])) {
        $valore = $vecchi[$campo['name']];
    }
    return '<label class="campo">'
         . '<span>' . h($campo['label']) . '</span>'
         . '<input type="' . $campo['type'] . '" name="' . $campo['name'] . '"'
         . ' placeholder="' . h($campo['placeholder']) . '"'
         . ' autocomplete="' . $campo['auto'] . '"'
         . ' value="' . h($valore) . '" required>'
         . '</label>';
}

// ARRAY DI OGGETTI HTML: un elemento <label><input> per ogni campo
$htmlAccesso = [];
foreach ($campiAccesso as $campo) {
    $htmlAccesso[] = campoHtml($campo, $vecchi);
}
$htmlRegistrazione = [];
foreach ($campiRegistrazione as $campo) {
    $htmlRegistrazione[] = campoHtml($campo, $vecchi);
}

// LA TENDINA: un <option> per ogni fazione, generato dall'array $fazioni
$opzioni = ['<option value="" disabled' . ($vecchi['fazione'] === '' ? ' selected' : '') . '>— Scegli la tua fazione —</option>'];
foreach ($fazioni as $chiave => $f) {
    $selezionata = ($vecchi['fazione'] === $chiave) ? ' selected' : '';
    $opzioni[] = '<option value="' . $chiave . '"'
               . ' data-colore="' . $f['colore'] . '" data-motto="' . h($f['motto']) . '"' . $selezionata . '>'
               . $f['icona'] . ' ' . h($f['nome'])
               . '</option>';
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Arena - Accesso</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lilita+One&family=Nunito:wght@700;800&display=swap" rel="stylesheet">
<style>
  :root {
    --blu-scuro: #0d2a5c;      /* il contorno spesso di tutto */
    --giallo-1: #ffe066;  --giallo-2: #f5a900;
    --verde-1:  #8ef06a;  --verde-2:  #3aa82a;
    --titolo: 'Lilita One', 'Arial Black', sans-serif;
    --testo:  'Nunito', Arial, sans-serif;
  }
  * { box-sizing: border-box; }

  html, body { margin: 0; min-height: 100%; }
  body {
    min-height: 100vh;
    display: flex; align-items: center; justify-content: center;
    padding: 24px 12px;
    font-family: var(--testo);
    color: var(--blu-scuro);
    /* cielo blu con raggi che girano piano */
    background: radial-gradient(circle at 50% 35%, #5fd0ff 0%, #2a86e0 40%, #0e3f94 100%);
    overflow-x: hidden;
  }
  body::before {
    content: '';
    position: fixed; left: 50%; top: 35%;
    width: 220vmax; height: 220vmax;
    margin: -110vmax 0 0 -110vmax;
    background: repeating-conic-gradient(rgba(255,255,255,.09) 0 10deg, transparent 10deg 20deg);
    animation: gira 60s linear infinite;
    z-index: -1;
  }
  @keyframes gira { to { transform: rotate(360deg); } }

  /* Testo "da cartone": bianco con contorno scuro e ombra sotto */
  .contorno {
    color: #fff;
    text-shadow:
      -2px -2px 0 var(--blu-scuro),  2px -2px 0 var(--blu-scuro),
      -2px  2px 0 var(--blu-scuro),  2px  2px 0 var(--blu-scuro),
       0    5px 0 var(--blu-scuro);
  }

  .contenitore { width: 100%; max-width: 420px; }

  .logo { text-align: center; margin-bottom: 18px; }
  .logo h1 {
    font-family: var(--titolo);
    font-size: 64px; line-height: 1; margin: 0;
    letter-spacing: 2px;
    transform: rotate(-3deg);
  }
  .logo p { font-family: var(--titolo); font-size: 20px; margin: 10px 0 0; }

  /* Il pannello */
  .pannello {
    background: linear-gradient(#ffffff, #dde8fb);
    border: 4px solid var(--blu-scuro);
    border-radius: 24px;
    box-shadow: 0 8px 0 var(--blu-scuro), 0 22px 40px rgba(0,0,0,.35);
    padding: 18px 20px 24px;
  }

  /* Le due schede */
  .schede { display: flex; gap: 10px; margin-bottom: 18px; }
  .scheda {
    flex: 1;
    font-family: var(--titolo); font-size: 20px;
    padding: 10px 0;
    border: 3px solid var(--blu-scuro);
    border-radius: 14px;
    background: linear-gradient(#9fb6d9, #7590bb);
    box-shadow: inset 0 -4px 0 rgba(0,0,0,.18);
    cursor: pointer;
  }
  .scheda.attiva {
    background: linear-gradient(var(--giallo-1), var(--giallo-2));
    box-shadow: inset 0 -4px 0 rgba(0,0,0,.18), 0 4px 0 var(--blu-scuro);
    transform: translateY(-2px);
  }

  form { display: none; }
  form.attivo { display: block; animation: entra .25s ease-out; }
  @keyframes entra { from { transform: scale(.96); opacity: 0; } }

  /* Campi */
  .campo { display: block; margin-bottom: 14px; }
  .campo span, .etichetta {
    display: block;
    font-family: var(--titolo); font-size: 17px;
    margin: 0 0 6px 4px;
  }
  input, select {
    width: 100%;
    font-family: var(--testo); font-weight: 800; font-size: 18px;
    color: var(--blu-scuro);
    padding: 12px 14px;
    border: 3px solid var(--blu-scuro);
    border-radius: 14px;
    background: #fff;
    box-shadow: inset 0 4px 0 rgba(13,42,92,.12);
    outline: none;
  }
  input:focus, select:focus { border-color: #1e78e6; box-shadow: inset 0 4px 0 rgba(13,42,92,.12), 0 0 0 4px rgba(30,120,230,.3); }
  input::placeholder { color: #9aa8c2; }

  /* La tendina: freccia disegnata a mano al posto di quella del browser */
  select {
    appearance: none; -webkit-appearance: none;
    cursor: pointer;
    padding-right: 46px;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='18' height='12'%3E%3Cpath d='M2 2l7 7 7-7' fill='none' stroke='%230d2a5c' stroke-width='4' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right 14px center;
  }

  /* Anteprima della fazione scelta */
  .stemma {
    display: flex; align-items: center; gap: 10px;
    margin: 10px 0 16px;
    padding: 10px 12px;
    border: 3px solid var(--blu-scuro);
    border-radius: 14px;
    background: var(--colore, #c9d6ec);
    min-height: 52px;
    transition: background .2s;
  }
  .stemma .motto { font-family: var(--titolo); font-size: 17px; }

  /* Bottoni "di gomma" */
  .bottone {
    width: 100%;
    font-family: var(--titolo); font-size: 26px; letter-spacing: 1px;
    padding: 12px 0 14px;
    margin-top: 6px;
    border: 3px solid var(--blu-scuro);
    border-radius: 16px;
    background: linear-gradient(var(--giallo-1), var(--giallo-2));
    box-shadow: inset 0 -7px 0 rgba(0,0,0,.18), inset 0 3px 0 rgba(255,255,255,.6), 0 6px 0 var(--blu-scuro);
    cursor: pointer;
    transition: transform .06s, box-shadow .06s;
  }
  .bottone.verde { background: linear-gradient(var(--verde-1), var(--verde-2)); }
  .bottone:hover  { filter: brightness(1.06); }
  .bottone:active {
    transform: translateY(5px);
    box-shadow: inset 0 -4px 0 rgba(0,0,0,.18), inset 0 3px 0 rgba(255,255,255,.6), 0 1px 0 var(--blu-scuro);
  }

  /* Errori */
  .errori {
    margin: 0 0 16px; padding: 10px 14px 10px 32px;
    border: 3px solid #7a1010;
    border-radius: 14px;
    background: linear-gradient(#ff6b5e, #d93a2e);
    color: #fff; font-weight: 800;
    box-shadow: 0 4px 0 #7a1010;
  }
  .errori li { margin: 2px 0; }

  .nota { text-align: center; font-weight: 800; font-size: 14px; margin: 14px 0 0; opacity: .75; }
  .nota a { color: #1e63c9; cursor: pointer; text-decoration: underline; }
</style>
</head>
<body>

<div class="contenitore">

  <div class="logo">
    <h1 class="contorno">ARENA</h1>
    <p class="contorno">Training Camp</p>
  </div>

  <div class="pannello">

    <div class="schede">
      <button type="button" class="scheda contorno" data-scheda="accedi">Accedi</button>
      <button type="button" class="scheda contorno" data-scheda="registrati">Registrati</button>
    </div>

    <?php if (count($errori) > 0): ?>
      <ul class="errori">
        <?php foreach ($errori as $e): ?>
          <li><?= h($e) ?></li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>

    <!-- ACCESSO -->
    <form method="post" id="accedi">
      <input type="hidden" name="azione" value="accedi">
      <?= implode("\n", $htmlAccesso) ?>
      <button type="submit" class="bottone contorno">GIOCA!</button>
      <p class="nota">Nuovo in arena? <a data-vai="registrati">Crea un account</a></p>
    </form>

    <!-- REGISTRAZIONE -->
    <form method="post" id="registrati">
      <input type="hidden" name="azione" value="registrati">
      <?= implode("\n", $htmlRegistrazione) ?>

      <label class="etichetta" for="fazione">Fazione</label>
      <select name="fazione" id="fazione" required>
        <?= implode("\n", $opzioni) ?>
      </select>
      <div class="stemma" id="stemma">
        <span class="motto contorno" id="motto">Ogni guerriero ha una bandiera.</span>
      </div>

      <button type="submit" class="bottone verde contorno">CREA ACCOUNT</button>
      <p class="nota">Hai gia' un account? <a data-vai="accedi">Accedi</a></p>
    </form>

  </div>
</div>

<script>
// ---------- SCHEDE ----------
// Mostra un form e nasconde l'altro; la scheda iniziale la decide PHP
// (dopo un errore di registrazione resta aperta "Registrati").
function mostra(nome) {
  for (const b of document.querySelectorAll('.scheda')) {
    b.classList.toggle('attiva', b.dataset.scheda === nome);
  }
  for (const f of document.querySelectorAll('form')) {
    f.classList.toggle('attivo', f.id === nome);
  }
}
for (const el of document.querySelectorAll('[data-scheda], [data-vai]')) {
  el.addEventListener('click', function () {
    mostra(el.dataset.scheda || el.dataset.vai);
  });
}
mostra(<?= json_encode($scheda) ?>);

// ---------- ANTEPRIMA DELLA FAZIONE ----------
// Colore e motto vengono dagli attributi data- dell'<option> scelta
const tendina = document.getElementById('fazione');
const stemma  = document.getElementById('stemma');
const motto   = document.getElementById('motto');
function aggiornaStemma() {
  const scelta = tendina.options[tendina.selectedIndex];
  if (!scelta || !scelta.value) return;
  stemma.style.setProperty('--colore', scelta.dataset.colore);
  motto.textContent = scelta.textContent.trim() + ' — ' + scelta.dataset.motto;
}
tendina.addEventListener('change', aggiornaStemma);
aggiornaStemma();
</script>

</body>
</html>
