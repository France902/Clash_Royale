<?php
// ============================================================
//  LOGOUT: chiude la lobby del giocatore, svuota la sessione,
//  la distrugge e torna all'accesso
// ============================================================
session_start();
require __DIR__ . '/lobby.php';

if (isset($_SESSION['utente'])) {
    esciDaLobby($fileLobby, $_SESSION['utente']['username']);   // l'avversario restera' senza lobby
}

$_SESSION = [];       // via tutti i dati
session_destroy();    // via la sessione
header('Location: accesso.php');
exit;