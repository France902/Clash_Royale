<?php
// Si usa solo dentro arena.php: aperto da solo, non fa niente
defined('ARENA_DIR') or exit;

// ============================================================
//  LA PAGINA HTML: canvas, pannelli e script.
//  Le impostazioni arrivano a JavaScript come costanti (blocco <script>
//  qui sotto); il resto del codice sta nei file della cartella js/.
// ============================================================
?>
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="utf-8">
<title>Arena - Training Camp</title>
<link rel="stylesheet" href="css/arena.css?v=<?= $versione ?>">
</head>
<body>

<!-- I pannelli dei due giocatori: li riempie JavaScript con i dati della lobby -->
<div class="giocatore" id="pannello-red"></div>
<div class="giocatore" id="pannello-blue"></div>

<?php if ($errore): ?>
  <div style="color:#ff8080;padding:80px 10px 10px"><?= htmlspecialchars($errore) ?> <a href="logout.php" style="color:#fff">Esci</a></div>
<?php else: ?>

<canvas id="stage"></canvas>
<div id="info"></div>

<!-- La barra dell'elisir: questo div e' la BASE scura, le 10 tacche le crea js/elisir.js -->
<div id="elisir"></div>

<script>
// ---------- IMPOSTAZIONI (arrivano da PHP) ----------
const MAP_URL      = <?= json_encode($mappa . '?v=' . $versione) ?>;
const MARGIN       = <?= (int)$margine ?>;
const MAP_HEIGHT   = <?= (float)$altezzaMappa ?>;
const TOWERS       = <?= json_encode($torri, JSON_UNESCAPED_SLASHES) ?>;
const BARS         = <?= json_encode($barre, JSON_UNESCAPED_SLASHES) ?>;
const SOPRA_TORRI  = <?= json_encode($sopraTorri, JSON_UNESCAPED_SLASHES) ?>; // re e cannone di ogni squadra
const DIFESE       = <?= json_encode($difese, JSON_UNESCAPED_SLASHES) ?>;     // come sparano le torri (+ animazioni della principessa)
const ASSI         = <?= json_encode($assi) ?>;          // per squadra: { blue: [6 assi], red: [6 assi] }
const SOLIDS       = <?= json_encode($blocchi) ?>;       // le torri come blocchi solidi
const SQUARE       = <?= (int)$latoQuadrato ?>;          // lato dei quadrati, in pixel della mappa
const DOT_SIZE     = <?= (int)$diametroCerchio ?>;       // diametro dei cerchi, in pixel della mappa
const DEBUG        = <?= $debug ? 'true' : 'false' ?>;
const BAR_K        = <?= (float)$scalaBarra ?>;          // grandezza delle barre rispetto alla mappa
const CHAR_BAR_K   = <?= (float)$scalaBarraPersonaggio ?>;    // grandezza delle barre dei personaggi
const CHAR_BAR_GAP = <?= (float)$distanzaBarraPersonaggio ?>; // distanza della barra dalla cima dello sprite
const PERSONAGGI   = <?= json_encode($cfgPersonaggi, JSON_UNESCAPED_SLASHES) ?>; // i JSON: { blue: ..., red: ... }
const QUADRATI_RE  = <?= json_encode($quadratiRe) ?>;    // i quadrati intorno alle torri del re
const LIMITI       = <?= json_encode($limiteSchieramento) ?>; // blu schiera sotto, rosso sopra
const MIA_SQUADRA  = <?= json_encode($miaSquadra) ?>;    // 'blue' o 'red': la squadra di chi guarda
const FAZIONI      = <?= json_encode($fazioniPerJs) ?>;  // nome, colore e icona di ogni fazione
const PONTI        = <?= json_encode($ponti) ?>;         // per ogni ponte: x del centro, y delle sponde nord e sud
const MEZZO_PONTE  = <?= (int)$mezzaLarghezzaPonte ?>;   // fin dove (in x dal centro) si e' sul ponte
const MARGINE_PORTE = <?= (int)$scarto ?>;               // le porte dei ponti stanno al massimo qui dal centro

// La parte colorata dentro l'immagine della barra della vita
const BAR_FILL = { x: 2, y: 2, w: 205, h: 17 };

// Aggiornamenti della logica al secondo (deve essere uguale a $tickAlSecondo in PHP)
const TICK_RATE = <?= (int)$tickAlSecondo ?>;

// L'elisir, in "tick di ricarica" (vedi inc/elisir.php): 1 di elisir = TICK_PER_ELISIR
const TACCHE          = <?= (int)$elisirMassimo ?>;      // quante tacche ha la barra (elisir massimo)
const TICK_PER_ELISIR = <?= (int)$tickPerElisir ?>;      // tick per ricaricare 1 di elisir
const ELISIR_MAX      = <?= (int)$elisirMassimoTick ?>;  // la barra piena
const COSTO_ELISIR    = <?= (int)$costoTick ?>;          // quanto costa un Mini P.E.K.K.A
const BARRA_ELISIR    = <?= json_encode($barraElisir) ?>; // grandezza e posizione della barra
</script>

<!-- L'ORDINE CONTA: ogni file usa cose dei file prima di lui -->
<script src="js/utilita.js?v=<?= $versione ?>"></script>
<script src="js/direzioni.js?v=<?= $versione ?>"></script>
<script src="js/fiume.js?v=<?= $versione ?>"></script>
<script src="js/solidi.js?v=<?= $versione ?>"></script>
<script src="js/torri.js?v=<?= $versione ?>"></script>
<script src="js/unita.js?v=<?= $versione ?>"></script>
<script src="js/obiettivi.js?v=<?= $versione ?>"></script>
<script src="js/attacco.js?v=<?= $versione ?>"></script>
<script src="js/movimento.js?v=<?= $versione ?>"></script>
<script src="js/difese.js?v=<?= $versione ?>"></script>
<script src="js/schermo.js?v=<?= $versione ?>"></script>
<script src="js/segnaposto.js?v=<?= $versione ?>"></script>
<script src="js/disegno.js?v=<?= $versione ?>"></script>
<script src="js/sopra_torri.js?v=<?= $versione ?>"></script>
<script src="js/hud.js?v=<?= $versione ?>"></script>
<script src="js/elisir.js?v=<?= $versione ?>"></script>
<script src="js/input.js?v=<?= $versione ?>"></script>
<script src="js/rete.js?v=<?= $versione ?>"></script>
<script src="js/avvio.js?v=<?= $versione ?>"></script>

<?php endif; ?>

</body>
</html>
