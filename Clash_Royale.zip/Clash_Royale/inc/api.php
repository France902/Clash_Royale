<?php
// Si usa solo dentro arena.php: aperto da solo, non fa niente
defined('ARENA_DIR') or exit;

// ============================================================
//  RICHIESTE DEL CLIENT (AJAX), come nel test del movimento sincronizzato:
//    arena.php?azione=stato    -> che ore sono sul server + la mia lobby
//    arena.php?azione=schiera  -> (POST x, y, cid) schiero un Mini P.E.K.K.A
//  Rispondono in JSON e si fermano li' (exit): niente pagina HTML.
// ============================================================
$azione = $_GET['azione'] ?? '';

// Risponde al client con un JSON e chiude
function rispondi($dati) {
    header('Content-Type: application/json');
    echo json_encode($dati);
    exit;
}

// ---------- STATO: l'ora del server e la mia lobby ----------
if ($azione === 'stato') {
    $aperto = apriLobby($fileLobby);
    $ora = oraMs();
    $lobby = pulisciLobby($aperto['lobby'], $ora);
    $i = cercaLobbyDi($lobby, $utente['username']);
    if ($i !== -1) aggiornaVisto($lobby, $i, $utente['username'], $ora);   // "ci sono ancora"
    chiudiLobby($aperto, $lobby, true);

    $miaLobby = null;
    if ($i !== -1) $miaLobby = $lobby[$i];
    rispondi(['ora' => $ora, 'lobby' => $miaLobby]);
}

// ---------- SCHIERA: il giocatore mette in campo un Mini P.E.K.K.A ----------
// Se ne possono schierare quanti se ne vuole: basta avere l'elisir.
if ($azione === 'schiera') {
    $x = (float) ($_POST['x'] ?? -1);
    $y = (float) ($_POST['y'] ?? -1);
    // Il "numero di ricevuta" scelto dal client: torna indietro dentro l'evento,
    // cosi' il client riconosce il suo schieramento quando arriva
    $cid = substr((string) ($_POST['cid'] ?? ''), 0, 40);

    $aperto = apriLobby($fileLobby);
    $ora = oraMs();
    $lobby = $aperto['lobby'];
    $i = cercaLobbyDi($lobby, $utente['username']);

    // Tutti i controlli: se uno fallisce, $errore dice perche'
    $errore = '';
    $squadra = null;
    $tickAdesso = 0;
    if ($i === -1) {
        $errore = 'Non sei in nessuna lobby.';
    } else {
        $squadra = squadraDi($lobby[$i], $utente['username']);
        $dimensioni = getimagesize(ARENA_DIR . '/' . $mappa);   // [larghezza, altezza] della mappa

        if ($lobby[$i]['inizio'] === null || $ora < $lobby[$i]['inizio']) {
            $errore = 'La partita non e\' ancora iniziata.';
        } else {
            // Il tick in cui siamo adesso: e' qui che si paga l'elisir
            $tickAdesso = (int) floor(($ora - $lobby[$i]['inizio']) * $tickAlSecondo / 1000);
            if (elisirAl($lobby[$i]['eventi'], $squadra, $tickAdesso, $elisirMassimoTick, $costoTick) < $costoTick) {
                $errore = 'Elisir insufficiente.';
            }
        }
        if ($x < 0 || $y < 0 || $x > $dimensioni[0] || $y > $dimensioni[1]) {
            $errore = 'Fuori dalla mappa.';
        }
        if ($squadra === 'blue' && $y < $limiteSchieramento['blue']) $errore = 'Puoi schierarlo solo nella tua meta\'.';
        if ($squadra === 'red'  && $y > $limiteSchieramento['red'])  $errore = 'Puoi schierarlo solo nella tua meta\'.';
        foreach ($blocchi as $b) {
            if (abs($x - $b['x']) < $b['halfW'] && abs($y - $b['y']) < $b['halfH']) {
                $errore = 'Non puoi schierarlo sopra una torre.';
            }
        }
    }

    if ($errore !== '') {
        chiudiLobby($aperto, $lobby, false);
        rispondi(['ok' => false, 'errore' => $errore]);
    }

    // L'elisir si paga adesso ('clic'); il Mini P.E.K.K.A compare dopo il ritardo ('tick')
    $lobby[$i]['eventi'][] = [
        'squadra' => $squadra,
        'x'       => round($x, 2),
        'y'       => round($y, 2),
        'clic'    => $tickAdesso,
        'tick'    => $tickAdesso + $ritardoSchieramento,
        'cid'     => $cid,
    ];
    chiudiLobby($aperto, $lobby, true);
    rispondi(['ok' => true]);
}
