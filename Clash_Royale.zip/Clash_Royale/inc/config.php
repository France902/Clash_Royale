<?php
// Si usa solo dentro arena.php: aperto da solo, non fa niente
defined('ARENA_DIR') or exit;

// ============================================================
//  IMPOSTAZIONI: qui si cambiano mappa, torri, corsie, personaggi...
// ============================================================

// Numero aggiunto in fondo agli indirizzi delle immagini (?v=...):
// cambia a ogni caricamento, cosi' il browser non usa immagini vecchie.
$versione = time();

// La mappa
$mappa = 'assets/training_camp/training_camp.png';

// Spazio vuoto intorno alla mappa, in pixel della mappa (su tutti e 4 i lati).
$margine = 100;

// Quanto dell'altezza della pagina occupano mappa + margine (0.9 = 90%, 1 = tutta).
$altezzaMappa = 0.9;

// Come e' fatta l'immagine di ogni tipo di torre:
//   'ancora' = il punto dell'immagine che va messo sulla posizione della torre
//   'scala'  = quanto ingrandire l'immagine
//   'cima'   = y del punto piu' alto della torre nell'immagine
//   'fondo'  = y del punto piu' basso della torre nell'immagine
//   'barra'  = grandezza della barra della vita
$tipi = [
    'king'     => ['ancora' => [203, 182], 'scala' => 0.85, 'cima' => 69, 'fondo' => 295, 'barra' => 0.2],
    'princess' => ['ancora' => [201, 181], 'scala' => 0.8,  'cima' => 86, 'fondo' => 282, 'barra' => 0.1],
];

// Le torri: tipo, squadra e posizione (centro della piattaforma, in pixel della mappa).
// Rosso = in alto, blu = in basso.
$posizioni = [
    ['tipo' => 'king',     'squadra' => 'red',  'x' => 398, 'y' => 40],
    ['tipo' => 'princess', 'squadra' => 'red',  'x' => 149, 'y' => 173],
    ['tipo' => 'princess', 'squadra' => 'red',  'x' => 651, 'y' => 174],
    ['tipo' => 'princess', 'squadra' => 'blue', 'x' => 151, 'y' => 888],
    ['tipo' => 'princess', 'squadra' => 'blue', 'x' => 652, 'y' => 889],
    ['tipo' => 'king',     'squadra' => 'blue', 'x' => 404, 'y' => 1010],
];

// ---------- SOPRA LE TORRI: RE, CANNONE E PRINCIPESSE ----------
// Le immagini del re (cartella del re):
//   <squadra>_king.png, <squadra>_king_cannon.png e cannon_base.png (una per tutti)
// Le principesse sono quelle importate con importa_sprite.php
// (characters/princess_<squadra>.json, posa ferma "idle").
$cartellaRe = 'assets/king_tower';

// Dove stanno e quanto sono grandi:
//   'posizione' = [x, y] del CENTRO del disegno, rispetto al centro della torre,
//                 in pixel della mappa (y negativo = piu' in alto)
//   'altezza'   = quanto e' alto il disegno sulla mappa, in pixel della mappa
// I bordi trasparenti dei PNG non contano: il gioco li toglie da solo.
// In cima alla torre del re c'e' una piattaforma: il re sta sul legno, nella
// meta' DIETRO (rosso: alta, blu: bassa), il cannone nella meta' DAVANTI,
// verso il centro dell'arena.
$sopraLeTorri = [
    're' => [
        'altezza'   => 120,
        'posizione' => ['red' => [0, -50], 'blue' => [0, -20]],
    ],
    'cannone' => [
        'altezza'   => 70,           // la base si ingrandisce insieme al cannone
        'posizione' => ['red' => [0, -8], 'blue' => [0, -60]],
        'base'      => [0, 0],       // la base sotto il cannone: spostamento rispetto al cannone
    ],
    'principessa' => [
        'altezza'   => 80,
        'posizione' => ['red' => [0, -45], 'blue' => [10, -48]],
    ],
];

// ---------- Barre della vita ----------
$cartellaUi = 'assets/ui';

// Vita iniziale delle torri (scende quando vengono attaccate)
$hp_princess = 3800;   // torri principessa
$hp_king     = 6300;   // torre del re

// Dove sta la barra: sopra la torre (rosse) o sotto la base (blu)
$posizioneBarra = ['red' => 'cima', 'blue' => 'base'];

// Grandezza delle barre RISPETTO ALLA MAPPA: la barra si ingrandisce e si
// rimpicciolisce insieme alla mappa, quindi con lo zoom resta sempre della
// stessa dimensione rispetto alle torri. Piu' alto = barre piu' grandi.
$scalaBarra = 5.5;
$distanzaBarra = ['red' => 15, 'blue' => 40];

// Barre dei personaggi: grandezza (come 'barra' delle torri) e quanto stanno
// sopra la cima dello sprite, in pixel della mappa (negativo = piu' in basso)
$scalaBarraPersonaggio    = 0.08;
$distanzaBarraPersonaggio = 2;

// ---------- I PERSONAGGI ----------
// Per ogni squadra, il nome del suo JSON nella cartella characters/
$personaggi = [
    'blue' => 'mini_pekka',
    'red'  => 'mini_pekka_red',
];

// ---------- CORSIE ----------
// Ogni ponte ha un 'asse' (la x del centro del ponte) e, PER OGNI SQUADRA,
// tre y in pixel della mappa:
//   'ingresso' = y dei quadrati PRIMA del ponte (nella propria meta')
//   'ponte'    = y dei cerchi sul ponte
//   'torre'    = y dei quadrati DAVANTI alle torri avversarie (dove si ferma)
// Sono stime fatte sul tuo schermo: usa i segnaposto per controllare.
$corsie = [
    [   // ponte di sinistra
        'asse' => 151,
        'blue' => ['ingresso' => 610, 'ponte' => 545, 'torre' => 260],
        'red'  => ['ingresso' => 510, 'ponte' => 575, 'torre' => 800],
    ],
    [   // ponte di destra
        'asse' => 659,
        'blue' => ['ingresso' => 610, 'ponte' => 545, 'torre' => 260],
        'red'  => ['ingresso' => 510, 'ponte' => 575, 'torre' => 800],
    ],
];

// I quadrati intorno alle torri del re (da dove si attacca il re): due ai lati
// e due davanti. Per ogni quadrato: [spostamento in x, spostamento verso il
// centro dell'arena], rispetto al centro della torre del re, in pixel della mappa.
// Valgono per tutte e due le torri del re (per quella blu "verso il centro" e' in su).
$quadratiRe = [
    [-107,  39],   // a sinistra
    [ 107,  39],   // a destra
    [ -58, 119],   // davanti a sinistra
    [  58, 119],   // davanti a destra
];

// Distanza tra un asse e l'altro: gli assi sono a -scarto, 0 e +scarto dal centro.
// I punti di uno stesso asse hanno la stessa x, quindi si attraversa dritti.
$scarto = 26;

// Grandezze dei segnaposto, in pixel della mappa
$latoQuadrato     = 24;   // quadrati d'ingresso e d'arrivo
$diametroCerchio  = 20;   // cerchi sul ponte

// ---------- SCHIERAMENTO ----------
// Dove ogni giocatore puo' schierare il suo Mini P.E.K.K.A (la sua meta'):
//   blu   -> solo SOTTO la sua y (y piu' grande)
//   rosso -> solo SOPRA la sua y (y piu' piccola)
// In ogni caso mai dentro una torre.
$limiteSchieramento = ['blue' => 600, 'red' => 520];

// Dopo quanti tick dal clic il Mini P.E.K.K.A compare (60 tick = 1 secondo).
// Serve a far arrivare lo schieramento a tutti e due i client prima che valga.
$ritardoSchieramento = 60;

// Tick al secondo della simulazione (deve essere uguale a TICK_RATE in JavaScript)
$tickAlSecondo = 60;

// ---------- ELISIR ----------
// Ogni giocatore ha la sua barra di elisir: si parte pieni, ogni Mini P.E.K.K.A
// schierato costa elisir e la barra si ricarica da sola col tempo.
// Si possono schierare quanti Mini P.E.K.K.A si vuole, se c'e' l'elisir.
$elisirMassimo    = 10;   // elisir con la barra piena (= numero di tacche della barra)
$costoMiniPekka   = 4;    // quanto elisir costa schierare un Mini P.E.K.K.A
$secondiPerElisir = 2;    // ogni quanti secondi torna 1 di elisir

// La barra sullo schermo: dalla parte del proprio campo (blu in basso, rosso in alto)
$barraElisir = [
    'larghezza' => 0.6,   // rispetto alla larghezza della mappa (0.6 = 60%)
    'altezza'   => 44,    // in pixel della mappa: segue lo zoom come tutto il resto
    'bordo'     => 8,     // distanza dal bordo della finestra, in pixel dello schermo
];

// ---------- TORRI SOLIDE ----------
// Ogni torre e' un rettangolo che non si puo' attraversare, centrato sulla
// torre. Per tipo: [meta' larghezza, meta' altezza], in pixel della mappa.
$solidi = [
    'king'     => [60, 55],
    'princess' => [45, 45],
];
// "Spessore" dei personaggi: allarga i rettangoli, cosi' non ci entrano
// nemmeno con il corpo (il loro punto e' il centro dello sprite).
$raggio = 12;

// Mostrare i segnaposto di controllo? (true = si, false = nascosti)
$debug = true;
