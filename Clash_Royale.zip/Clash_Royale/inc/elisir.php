<?php
// Si usa solo dentro arena.php: aperto da solo, non fa niente
defined('ARENA_DIR') or exit;

// ============================================================
//  ELISIR: quanto ne ha una squadra in un certo tick
//
//  Il server non tiene un "contatore" di elisir: lo ricalcola ogni volta
//  dagli schieramenti, come fa il client (js/elisir.js). Cosi' i due conti
//  sono sempre uguali, anche ricaricando la pagina.
//
//  Si conta in TICK DI RICARICA invece che in elisir: 1 di elisir =
//  $tickPerElisir tick. Sono numeri interi, quindi niente arrotondamenti
//  diversi tra PHP e JavaScript.
// ============================================================

$tickPerElisir     = (int) round($secondiPerElisir * $tickAlSecondo);   // 2 s * 60 = 120
$elisirMassimoTick = $elisirMassimo * $tickPerElisir;                   // barra piena

// Quanto costa una carta di una squadra, in tick di ricarica (null = non c'e')
function costoCarta($cfgPersonaggi, $squadra, $carta, $tickPerElisir) {
    if (!isset($cfgPersonaggi[$squadra][$carta]['elixir'])) return null;
    return (int) round($cfgPersonaggi[$squadra][$carta]['elixir'] * $tickPerElisir);
}

// L'elisir di una squadra al tick dato (in tick di ricarica).
// Si parte con la barra piena. Ogni schieramento, nel tick del CLIC ('clic'),
// toglie il SUO costo ('costo', scritto nell'evento quando e' stato fatto);
// tra uno schieramento e l'altro la barra cresce di 1 per tick, ma mai oltre
// il massimo. Gli schieramenti sono in ordine di tempo.
function elisirAl($eventi, $squadra, $tick, $massimo) {
    $tick   = max($tick, 0);      // prima dell'inizio la barra e' piena
    $elisir = $massimo;
    $ultimo = 0;                  // il tick dell'ultimo conto fatto
    foreach ($eventi as $e) {
        if ($e['squadra'] !== $squadra || $e['clic'] > $tick) continue;
        $elisir = min($massimo, $elisir + ($e['clic'] - $ultimo)) - $e['costo'];
        $ultimo = $e['clic'];
    }
    return min($massimo, $elisir + ($tick - $ultimo));
}
