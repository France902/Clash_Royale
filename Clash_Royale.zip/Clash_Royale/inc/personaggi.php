<?php
// Si usa solo dentro arena.php: aperto da solo, non fa niente
defined('ARENA_DIR') or exit;

// ============================================================
//  CARICAMENTO DEI PERSONAGGI (i JSON nella cartella characters/)
// ============================================================

// ---------- CARICAMENTO DEI PERSONAGGI ----------

// Una sezione del JSON (es. "walk") e' completa se ha prefix, firstFrame e lastFrame
function haSezione($cfg, $nome) {
    return isset($cfg[$nome]['prefix'], $cfg[$nome]['firstFrame'], $cfg[$nome]['lastFrame']);
}

// Lista dei PNG di una sezione, es. assets/mini_pekka/blue/mini_pekka_forward_blue_003.png
// str_pad scrive il numero sempre con 3 cifre: 3 -> "003", 12 -> "012"
function elencoFrame($cartella, $sezione, $versione) {
    $lista = [];
    for ($i = $sezione['firstFrame']; $i <= $sezione['lastFrame']; $i++) {
        $numero  = str_pad($i, 3, '0', STR_PAD_LEFT);
        $lista[] = $cartella . '/' . $sezione['prefix'] . $numero . '.png?v=' . $versione;
    }
    return $lista;
}

// Legge il JSON di un personaggio e prepara la lista dei PNG di ogni animazione.
// Restituisce ['cfg' => i dati, 'errore' => '' se e' andato tutto bene]
function caricaPersonaggio($id, $versione) {
    $file = ARENA_DIR . '/characters/' . $id . '.json';
    if (!is_file($file)) {
        return ['cfg' => null, 'errore' => "Personaggio non trovato: characters/$id.json"];
    }

    $cfg = json_decode(file_get_contents($file), true);
    if (!haSezione($cfg, 'walk')) {
        return ['cfg' => null, 'errore' => "characters/$id.json non valido: manca la sezione \"walk\" (prefix, firstFrame, lastFrame)."];
    }

    // La cartella delle immagini: quella scritta nel JSON, altrimenti 'assets'
    $cartella = 'assets';
    if (isset($cfg['assetsDir'])) {
        $cartella = $cfg['assetsDir'];
    }

    // Tutte le animazioni che il JSON puo' avere. Solo "walk" e' obbligatoria:
    // se ne manca una, JavaScript usa quella piu' simile (vedi DIREZIONI).
    $animazioni = [
        'walk',     'walkRight',     'walkLeft',        // cammina verso l'alto
        'walkBack', 'walkBackRight', 'walkBackLeft',    // cammina verso il basso
        'attack',     'attackRight',     'attackLeft',      // attacca verso l'alto
        'attackBack', 'attackBackRight', 'attackBackLeft',  // attacca verso il basso
    ];
    foreach ($animazioni as $nome) {
        if (haSezione($cfg, $nome)) {
            $cfg[$nome]['urls'] = elencoFrame($cartella, $cfg[$nome], $versione);
        }
    }
    return ['cfg' => $cfg, 'errore' => ''];
}

$errore = '';
$cfgPersonaggi = [];
foreach ($personaggi as $squadra => $id) {
    $caricato = caricaPersonaggio($id, $versione);
    $cfgPersonaggi[$squadra] = $caricato['cfg'];
    if ($caricato['errore'] !== '') {
        $errore = $caricato['errore'];
    }
}

