<?php
// Si usa solo dentro arena.php: aperto da solo, non fa niente
defined('ARENA_DIR') or exit;

// ============================================================
//  DIFESE: i parametri delle torri che sparano
//
//  I PARAMETRI (raggio, danno, velocita' d'attacco, proiettile...) stanno
//  nella sezione "tower" di:
//    characters/princess.json   -> le torri principessa (tutte e due le squadre)
//    characters/king.json       -> le torri del re
//  Le ANIMAZIONI della principessa stanno invece nel JSON di ogni squadra,
//  quello che crea importa_sprite.php (characters/princess_red.json e
//  princess_blue.json). Se dentro quelli c'e' anche una sezione "tower", non
//  conta: i parametri si cambiano solo in princess.json e king.json.
//
//  Il significato di ogni parametro e' scritto in js/difese.js.
// ============================================================

// Legge un JSON e lo restituisce come array ([] se manca o non e' valido)
function leggiJson($file) {
    if (!is_file($file)) return [];
    $dati = json_decode(file_get_contents($file), true);
    if (!is_array($dati)) return [];
    return $dati;
}

// Tutto quello che serve a JavaScript per una torre ($id = 'princess' o 'king')
function caricaDifesa($id, $squadra, $versione) {
    // I parametri: dal JSON comune
    $comune = leggiJson(ARENA_DIR . '/characters/' . $id . '.json');
    $torre  = $comune['tower'] ?? [];

    // L'immagine del proiettile: nel nome, {team} diventa la squadra
    $proiettile = $torre['projectile'] ?? [];
    $proiettile['url'] = null;
    if (isset($proiettile['image'])) {
        $proiettile['url'] = str_replace('{team}', $squadra, $proiettile['image']) . '?v=' . $versione;
    }
    $torre['projectile'] = $proiettile;

    // Le animazioni: dal JSON della squadra (solo la principessa ne ha).
    // stdClass = oggetto vuoto: in JavaScript diventa {} anche senza animazioni
    $animato  = leggiJson(ARENA_DIR . '/characters/' . $id . '_' . $squadra . '.json');
    $cartella = $animato['assetsDir'] ?? 'assets/' . $id . '_tower/' . $squadra;
    $torre['sezioni'] = new stdClass();
    foreach (['idle', 'attack', 'attackRight', 'attackLeft'] as $nome) {
        if (haSezione($animato, $nome)) {
            $torre['sezioni']->$nome = elencoFrame($cartella, $animato[$nome], $versione);
        }
    }
    // Da che numero partono i PNG dell'attacco (serve per "shootFrame")
    $torre['firstFrame'] = $animato['attack']['firstFrame'] ?? 0;
    return $torre;
}

$difese = [];
foreach (['red', 'blue'] as $squadra) {
    $difese[$squadra] = [
        'princess' => caricaDifesa('princess', $squadra, $versione),
        'king'     => caricaDifesa('king',     $squadra, $versione),
    ];
}
