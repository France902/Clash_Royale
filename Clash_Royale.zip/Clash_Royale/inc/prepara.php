<?php
// Si usa solo dentro arena.php: aperto da solo, non fa niente
defined('ARENA_DIR') or exit;

// ============================================================
//  PREPARA I DATI PER JAVASCRIPT (assi, blocchi solidi, torri, re e principesse, barre, ponti, fazioni)
// ============================================================

// Gli ASSI di ogni squadra: 3 per ponte, 6 in tutto.
// Ogni asse ha 3 punti sulla stessa x: ingresso, ponte e torre avversaria.
$assi = ['blue' => [], 'red' => []];
foreach ($corsie as $corsia) {
    foreach ([-$scarto, 0, $scarto] as $spostamento) {   // sinistra, centro, destra
        $x = $corsia['asse'] + $spostamento;
        foreach (['blue', 'red'] as $squadra) {
            $y = $corsia[$squadra];
            $assi[$squadra][] = [
                'entry'  => ['x' => $x, 'y' => $y['ingresso']],
                'bridge' => ['x' => $x, 'y' => $y['ponte']],
                'tower'  => ['x' => $x, 'y' => $y['torre']],
            ];
        }
    }
}

// I blocchi solidi: uno per torre (centro + meta' larghezza/altezza, gia' allargate)
$blocchi = [];
foreach ($posizioni as $torre) {
    $tipo = $torre['tipo'];
    $blocchi[] = [
        'x'     => $torre['x'],
        'y'     => $torre['y'],
        'halfW' => $solidi[$tipo][0] + $raggio,   // meta' larghezza
        'halfH' => $solidi[$tipo][1] + $raggio,   // meta' altezza
    ];
}

// Tutto quello che serve per disegnare le torri
$torri = [];
foreach ($posizioni as $torre) {
    $tipo    = $torre['tipo'];
    $squadra = $torre['squadra'];

    if ($tipo === 'king') {
        $vita = $hp_king;
    } else {
        $vita = $hp_princess;
    }

    $torri[] = [
        'url'     => "assets/{$tipo}_tower/{$tipo}_tower_{$squadra}.png?v=" . $versione,
        'type'    => $tipo,
        'team'    => $squadra,
        'anchorX' => $tipi[$tipo]['ancora'][0],
        'anchorY' => $tipi[$tipo]['ancora'][1],
        'scale'   => $tipi[$tipo]['scala'],
        'top'     => $tipi[$tipo]['cima'],
        'bottom'  => $tipi[$tipo]['fondo'],
        'bar'     => $tipi[$tipo]['barra'],
        'hp'      => $vita,
        'x'       => $torre['x'],
        'y'       => $torre['y'],
    ];
}

// Cosa sta sopra le torri del re: per ogni squadra il re e il suo cannone,
// piu' la base del cannone (una per tutti). Le principesse sono in inc/difese.php
$sopraTorri = [
    'base'  => "$cartellaRe/cannon_base.png?v=" . $versione,
    'pezzi' => $sopraLeTorri,   // posizioni e grandezze
];
foreach (['red', 'blue'] as $squadra) {
    $sopraTorri[$squadra] = [
        're'          => "$cartellaRe/{$squadra}_king.png?v=" . $versione,
        'cannone'     => "$cartellaRe/{$squadra}_king_cannon.png?v=" . $versione,
    ];
}

$barre = [
    'base'     => "$cartellaUi/health_bar_base.png?v=" . $versione,
    'red'      => "$cartellaUi/health_bar_red.png?v="  . $versione,
    'blue'     => "$cartellaUi/health_bar_blue.png?v=" . $versione,
    'gap'      => $distanzaBarra,
    'position' => $posizioneBarra,
];

// Per i pannelli dei giocatori: di ogni fazione bastano nome, colore e icona
$fazioniPerJs = [];
foreach ($fazioni as $chiave => $f) {
    $fazioniPerJs[$chiave] = ['nome' => $f['nome'], 'colore' => $f['colore'], 'icona' => $f['icona']];
}

// I PONTI, ricavati dalle corsie: per ognuno la x del centro e le y delle due
// sponde (nord = ingresso dei rossi, sud = ingresso dei blu). Servono per
// attraversare il fiume quando si insegue un nemico dall'altra parte.
$ponti = [];
foreach ($corsie as $corsia) {
    $ponti[] = ['x' => $corsia['asse'], 'nord' => $corsia['red']['ingresso'], 'sud' => $corsia['blue']['ingresso']];
}
$mezzaLarghezzaPonte = $scarto + 4;   // fin dove (in x dal centro) si e' ancora sul ponte
