<?php
/**
 * Test Latenza Inter-Dispositivo (PHP + JavaScript AJAX)
 * Questo script gestisce sia la logica backend per la condivisione dello stato via file JSON,
 * sia l'interfaccia frontend per il test della latenza in tempo reale tramite polling.
 */

session_start();

$file_stato = 'stato_condiviso.json';

// Inizializza il file JSON dello stato condiviso se non esiste ancora
if (!file_exists($file_stato)) {
    file_put_contents($file_stato, json_encode([
        'colore' => '#3182ce',
        'ultimo_click_da' => 'Nessuno',
        'timestamp_ms' => 0
    ]));
}

// GESTIONE RICHIESTE AJAX
if (isset($_GET['azione'])) {
    header('Content-Type: application/json');
    
    // 1. Azione di cambio colore (Triggerata dal click di un client)
    if ($_GET['azione'] === 'cambia_colore') {
        $colori = ['#e53e3e', '#38a169', '#3182ce', '#d69e2e', '#805ad5', '#e2e8f0'];
        
        $nuovo_stato = [
            'colore' => $colori[array_rand($colori)],
            'ultimo_click_da' => str_contains(strtolower($_SERVER['HTTP_USER_AGENT'] ?? ''), 'mobile') ? 'Smartphone' : 'PC',
            'timestamp_ms' => round(microtime(true) * 1000) // Timestamp server in millisecondi
        ];
        
        file_put_contents($file_stato, json_encode($nuovo_stato));
        echo json_encode($nuovo_stato);
        exit;
    }
    
    // 2. Azione di polling per ottenere lo stato corrente
    if ($_GET['azione'] === 'ottieni_stato') {
        echo file_get_contents($file_stato);
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Latenza di Rete</title>
    <style>
        body { font-family: sans-serif; text-align: center; padding: 20px; background-color: #f7fafc; color: #2d3748; }
        .container { max-width: 500px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        #quadrato {
            width: 200px; height: 200px; margin: 30px auto; background-color: #3182ce;
            border-radius: 15px; cursor: pointer; transition: background-color 0.1s ease;
            display: flex; align-items: center; justify-content: center;
            color: white; font-weight: bold; font-size: 1.2rem; user-select: none;
            box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1);
        }
        #quadrato:active { transform: scale(0.98); }
        .info-box { background-color: #edf2f7; padding: 15px; border-radius: 8px; margin-top: 20px; text-align: left; }
        .latenza-valore { font-size: 1.5rem; font-weight: bold; color: #e53e3e; }
    </style>
</head>
<body>

<div class="container">
    <h2>Test Latenza Inter-Dispositivo</h2>
    <p>Clicca sul quadrato per cambiare colore a <strong>tutti i dispositivi</strong> connessi.</p>

    <div id="quadrato">CLICCA QUI</div>

    <div class="info-box">
        <div>Ultimo click da: <span id="info-dispositivo">Nessuno</span></div>
        <div style="margin-top: 10px;">
            Latenza stimata dell'ultimo cambio: <br>
            <span id="info-latenza" class="latenza-valore">0</span> <span class="latenza-valore">ms</span>
        </div>
    </div>
</div>

<script>
    const el = {
        quadrato: document.getElementById('quadrato'),
        dispositivo: document.getElementById('info-dispositivo'),
        latenza: document.getElementById('info-latenza')
    };
    
    let ultimoTimestampConosciuto = 0;

    /**
     * Aggiorna l'interfaccia grafica con i dati ricevuti dal server.
     * @param {Object} stato - Oggetto JSON contenente colore, utente e timestamp.
     * @param {boolean} isMe - True se l'azione è stata eseguita dal client locale.
     */
    function aggiornaInterfaccia(stato, isMe) {
        el.quadrato.style.backgroundColor = stato.colore;
        el.dispositivo.textContent = `${stato.ultimo_click_da} (${isMe ? "Tu" : "Remoto"})`;
        
        let diff = Date.now() - stato.timestamp_ms;
        ultimoTimestampConosciuto = stato.timestamp_ms;

        if (isMe) {
            el.latenza.textContent = `Locale (~${diff})`;
        } else {
            el.latenza.textContent = diff > 0 ? diff : "<200";
        }
    }

    // Event Listener: Invia una richiesta POST/GET asincrona al click sul quadrato
    el.quadrato.addEventListener('click', () => {
        fetch(`${window.location.pathname}?azione=cambia_colore`)
            .then(res => res.json())
            .then(stato => aggiornaInterfaccia(stato, true));
    });

    // Funzione di Polling: Interroga regolarmente il server per verificare aggiornamenti remoti
    function controllaAggiornamenti() {
        fetch(`${window.location.pathname}?azione=ottieni_stato`)
            .then(res => res.json())
            .then(stato => {
                if (stato.timestamp_ms !== ultimoTimestampConosciuto) {
                    aggiornaInterfaccia(stato, false);
                }
            });
    }

    setInterval(controllaAggiornamenti, 1);
</script>

</body>
</html>