<?php
// ============================================================
//  LE 5 FAZIONI
//  Array associativo: chiave (quella salvata nel JSON) => dati della fazione.
//  Lo usano sia accesso.php (per la tendina) sia arena.php (per il badge).
// ============================================================
$fazioni = [
    'grifoni' => ['nome' => 'Ordine dei Grifoni', 'colore' => '#f5b921', 'icona' => '🦅', 'motto' => "Dall'alto, sempre."],
    'zanne'   => ['nome' => 'Clan delle Zanne',   'colore' => '#e0483d', 'icona' => '🐺', 'motto' => 'Il branco non dimentica.'],
    'maree'   => ['nome' => 'Lega delle Maree',   'colore' => '#2f9be8', 'icona' => '🌊', 'motto' => 'Paziente come la risacca.'],
    'braci'   => ['nome' => 'Tribù delle Braci',  'colore' => '#ff7a1a', 'icona' => '🔥', 'motto' => 'Basta una scintilla.'],
    'rune'    => ['nome' => 'Circolo delle Rune', 'colore' => '#a463f2', 'icona' => '🔮', 'motto' => 'Chi legge i segni, vince.'],
];
