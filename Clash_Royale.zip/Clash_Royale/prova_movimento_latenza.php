<?php
/**
 * Test Movimento Sincronizzato (PHP + JavaScript + Funzione Matematica Temporale)
 * Il movimento è calcolato matematicamente in base al tempo, garantendo 
 * la perfetta sincronia su tutti i dispositivi aperti senza conflitti di scrittura.
 */

session_start();

$file_stato = 'stato_movimento.json';

// Inizializza il file JSON con il timestamp di riferimento del movimento
if (!file_exists($file_stato)) {
    file_put_contents($file_stato, json_encode([
        'timestamp_avvio' => round(microtime(true) * 1000),
        'ampiezza' => 150 // Massimo spostamento in pixel a destra e sinistra
    ]));
}

// GESTIONE RICHIESTA AJAX PER LA POSIZIONE
if (isset($_GET['azione']) && $_GET['azione'] === 'ottieni_stato') {
    header('Content-Type: application/json');
    
    $stato = json_decode(file_get_contents($file_stato), true);
    $ora_attuale_ms = round(microtime(true) * 1000);
    
    // Calcola il tempo trascorso dall'avvio
    $tempo_trascorso = $ora_attuale_ms - $stato['timestamp_avvio'];
    
    // Calcola la coordinata X usando la funzione seno: oscilla fluidamente tra -ampiezza e +ampiezza
    // Dividendo per 400 regoliamo la velocità del movimento
    $x = sin($tempo_trascorso / 400) * $stato['ampiezza'];
    
    echo json_encode([
        'x' => round($x, 2),
        'timestamp_ms' => $ora_attuale_ms
    ]);
    exit;
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Movimento Sincronizzato</title>
    <style>
        body { font-family: sans-serif; text-align: center; padding: 20px; background-color: #f7fafc; color: #2d3748; }
        .container { max-width: 500px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        
        #quadrato {
            width: 100px; 
            height: 100px; 
            margin: 30px auto; 
            background-color: #3182ce;
            border-radius: 15px; 
            display: flex; 
            align-items: center; 
            justify-content: center;
            color: white; 
            font-weight: bold; 
            font-size: 0.9rem;
            box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1);
            
            /* AGGIUNGI QUESTE RIGHE PER ELIMINARE GLI ARTEFATTI */
            will-change: transform;
            transform: translateZ(0); 
        }
        
        .info-box { background-color: #edf2f7; padding: 15px; border-radius: 8px; margin-top: 20px; text-align: left; }
        .valore-x { font-weight: bold; color: #3182ce; }
    </style>
</head>
<body>

<div class="container">
    <h2>Movimento Sincronizzato</h2>
    <p>Questo quadrato si muove in autonomia ed è perfettamente sincronizzato su <strong>tutti i dispositivi</strong> connessi.</p>

    <!-- Il quadrato non è più cliccabile -->
    <div id="quadrato">SINCRONO</div>

    <div class="info-box">
        <div>Coordinata X calcolata: <span id="info-x" class="valore-x">0</span> px</div>
    </div>
</div>

<script>
    const quadrato = document.getElementById('quadrato');
    const infoX = document.getElementById('info-x');

    /**
     * Interroga regolarmente il server per ottenere la coordinata X sincronizzata
     */
    function aggiornaMovimento() {
        fetch(`${window.location.pathname}?azione=ottieni_stato`)
            .then(res => res.json())
            .then(data => {
                // Sposta il quadrato in orizzontale usando CSS transform (translateX)
                quadrato.style.transform = `translateX(${data.x}px)`;
                infoX.textContent = data.x;
            });
    }

    // Frequenza di aggiornamento elevata (ogni 50ms) per garantire fluidità e sincronia visiva
    setInterval(aggiornaMovimento, 7);
</script>

</body>
</html>