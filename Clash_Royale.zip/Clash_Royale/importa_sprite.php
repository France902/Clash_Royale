<?php
// ============================================================
//  IMPORTA SPRITE
//
//  Prende i PNG da una cartella qualsiasi del PC e li copia nel progetto
//  con il nome giusto, una posa alla volta:
//    1. scrivi la cartella di partenza, scegli la squadra e cosa importi:
//       un personaggio (es. mini_pekka) o la torre principessa
//    2. scegli la posa (es. "Cammina in avanti")
//    3. clicca i frame di quella posa (clic sul primo, MAIUSC + clic
//       sull'ultimo per prenderli tutti in mezzo)
//    4. premi "Copia": i file finiscono in assets/<personaggio>/<squadra>/
//       rinominati 000, 001, 002... nell'ordine del nome originale,
//       e il JSON characters/<personaggio>_<squadra>.json si aggiorna da solo
//    5. la pagina passa da sola alla posa successiva
//
//  Le pose A SINISTRA si fanno da sole: ogni volta che la pagina si apre,
//  le pose a destra gia' importate vengono copiate, capovolte in orizzontale
//  (effetto specchio) e rinominate come la posa a sinistra.
//  TORRE PRINCIPESSA: la principessa non cammina, attacca soltanto. Ha 3
//  pose (attacca di fronte, a destra, a sinistra), tutte da importare a mano
//  (niente specchio). I file vanno in assets/princess_tower/<squadra>/ con il
//  nome princess_<posa>_<squadra>_000.png e il JSON e'
//  characters/princess_<squadra>.json. La posa FERMA ("idle") e' il primo
//  frame di "Attacca di fronte": nel JSON c'e' una sezione "idle" che punta a
//  quel frame, senza file in piu'.
//
//  Serve l'estensione GD di PHP (in XAMPP: nel php.ini togli il ; davanti
//  a "extension=gd" e riavvia Apache).
//
//  ATTENZIONE: legge e scrive file sul PC. Usala solo sul server locale,
//  mai su un sito pubblico.
// ============================================================

session_start();

// ---------- IMPOSTAZIONI ----------

// Le pose di un PERSONAGGIO (cammina e attacca):
// chiave nel JSON => [descrizione, pezzo di nome del file]
// Il file si chiama: <personaggio>_<pezzo>_<squadra>_000.png
// es. mini_pekka_attack_forward_30_red_004.png
$posePersonaggio = [
    'walk'            => ['Cammina in avanti',              'forward'],
    'walkRight'       => ['Cammina in avanti a destra',     '30'],
    'walkLeft'        => ['Cammina in avanti a sinistra',   'minus_30'],
    'walkBack'        => ['Cammina indietro',               'behind'],
    'walkBackRight'   => ['Cammina indietro a destra',      'behind_30'],
    'walkBackLeft'    => ['Cammina indietro a sinistra',    'behind_minus_30'],
    'attack'          => ['Attacca in avanti',              'attack_forward'],
    'attackRight'     => ['Attacca in avanti a destra',     'attack_forward_30'],
    'attackLeft'      => ['Attacca in avanti a sinistra',   'attack_forward_minus_30'],
    'attackBack'      => ['Attacca indietro',               'attack_behind'],
    'attackBackRight' => ['Attacca indietro a destra',      'attack_behind_30'],
    'attackBackLeft'  => ['Attacca indietro a sinistra',    'attack_behind_minus_30'],
];

$squadre = ['red' => 'Rosso', 'blue' => 'Blu'];

// Le pose a sinistra che si creano da sole: posa a sinistra => posa a destra da specchiare
$specchiPersonaggio = [
    'walkLeft'       => 'walkRight',
    'walkBackLeft'   => 'walkBackRight',
    'attackLeft'     => 'attackRight',
    'attackBackLeft' => 'attackBackRight',
];

// Le pose della PRINCIPESSA sulla torre: non cammina, attacca e basta.
// Stessi pezzi di nome del personaggio, es. princess_attack_forward_30_red_004.png
$posePrincipessa = [
    'attack'      => ['Attacca di fronte',   'attack_forward'],
    'attackRight' => ['Attacca a destra',    'attack_forward_30'],
    'attackLeft'  => ['Attacca a sinistra',  'attack_forward_minus_30'],
];

// Le cose che si possono importare. Per ognuna:
//   'nome'     = cosa si vede nel menu
//   'pose'     = le sue pose
//   'specchi'  = le pose a sinistra che si fanno da sole ([] = nessuna)
//   'fisso'    = nome fisso del personaggio ('' = lo scrive l'utente)
//   'cartella' = la cartella dentro assets/ ('' = quella col nome del personaggio)
//   'idle'     = la posa il cui PRIMO frame e' anche la posa ferma ('' = nessuna)
$tipi = [
    'personaggio' => [
        'nome'     => 'Personaggio (cammina e attacca)',
        'pose'     => $posePersonaggio,
        'specchi'  => $specchiPersonaggio,
        'fisso'    => '',
        'cartella' => '',
        'idle'     => '',
    ],
    'principessa' => [
        'nome'     => 'Torre principessa',
        'pose'     => $posePrincipessa,
        'specchi'  => [],
        'fisso'    => 'princess',
        'cartella' => 'princess_tower',
        'idle'     => 'attack',
    ],
];


// ---------- PICCOLI AIUTI ----------

// Rende un testo sicuro da scrivere dentro l'HTML
function h($testo) {
    return htmlspecialchars($testo, ENT_QUOTES, 'UTF-8');
}

// Il nome del file finisce con .png? (maiuscole o minuscole)
function ePng($nome) {
    return strtolower(pathinfo($nome, PATHINFO_EXTENSION)) === 'png';
}

// La cartella di partenza scritta dall'utente, senza la barra finale
function leggiCartella($valore) {
    return rtrim(trim($valore), "/\\");
}

// L'inizio del nome dei file di una posa, es. "mini_pekka_forward_red_"
function prefisso($personaggio, $pezzo, $squadra) {
    return $personaggio . '_' . $pezzo . '_' . $squadra . '_';
}

// La cartella dove vanno i file, vista dal progetto: es. "assets/mini_pekka/red"
// o "assets/princess_tower/red". E' anche quella scritta nel JSON (assetsDir).
function cartellaAssets($tipo, $personaggio, $squadra) {
    $cartella = $personaggio;
    if ($tipo['cartella'] !== '') $cartella = $tipo['cartella'];
    return 'assets/' . $cartella . '/' . $squadra;
}

// La stessa cartella, ma come percorso sul disco
function cartellaArrivo($tipo, $personaggio, $squadra) {
    return __DIR__ . '/' . cartellaAssets($tipo, $personaggio, $squadra);
}

// Tutti i PNG di una cartella, in ordine "naturale" (2 prima di 10)
function elencoPng($cartella) {
    $lista = [];
    foreach (scandir($cartella) as $nome) {
        if (ePng($nome) && is_file($cartella . '/' . $nome)) {
            $lista[] = $nome;
        }
    }
    natcasesort($lista);
    return array_values($lista);
}

// Aggiorna (o crea) il JSON del personaggio per quella squadra
function aggiornaJson($personaggio, $squadra, $chiave, $prefisso, $quanti, $tipo) {
    $file = __DIR__ . '/characters/' . $personaggio . '_' . $squadra . '.json';

    if (is_file($file)) {
        $dati = json_decode(file_get_contents($file), true);
    } else {
        // Primo file per questa squadra: si parte dal JSON del personaggio
        // (nome, scala, movimento, tempi dell'attacco...), se esiste
        $base = __DIR__ . '/characters/' . $personaggio . '.json';
        if (is_file($base)) {
            $dati = json_decode(file_get_contents($base), true);
        } else {
            $dati = ['name' => $personaggio];
        }
        // ...ma senza i nomi dei file dell'altra squadra: quelli si rifanno
        foreach ($tipo['pose'] as $k => $info) {
            if (isset($dati[$k])) {
                unset($dati[$k]['prefix'], $dati[$k]['firstFrame'], $dati[$k]['lastFrame']);
                if (count($dati[$k]) === 0) unset($dati[$k]);
            }
        }
        unset($dati['idle']);   // anche la posa ferma punta ai file dell'altra squadra
    }

    $dati['assetsDir'] = cartellaAssets($tipo, $personaggio, $squadra);
    if (!isset($dati[$chiave])) $dati[$chiave] = [];
    $dati[$chiave]['prefix']     = $prefisso;
    $dati[$chiave]['firstFrame'] = 0;
    $dati[$chiave]['lastFrame']  = $quanti - 1;

    // La posa ferma (idle) e' il primo frame di un'altra posa (per la
    // principessa: "Attacca di fronte"). Nel JSON punta a quel frame soltanto.
    if ($chiave === $tipo['idle']) {
        $dati['idle'] = ['prefix' => $prefisso, 'firstFrame' => 0, 'lastFrame' => 0];
    }

    if (!is_dir(dirname($file))) mkdir(dirname($file), 0777, true);
    file_put_contents($file, json_encode($dati, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
}


// ---------- SPECCHIO (le pose a sinistra) ----------

// Copia un PNG capovolgendolo in orizzontale, tenendo la trasparenza
function specchia($da, $a) {
    $img = imagecreatefrompng($da);
    imageflip($img, IMG_FLIP_HORIZONTAL);
    imagealphablending($img, false);   // non mescolare i colori con lo sfondo...
    imagesavealpha($img, true);        // ...e salvare anche la trasparenza
    imagepng($img, $a);
    imagedestroy($img);
}

// La data di modifica piu' recente / piu' vecchia di una lista di file
function piuRecente($lista) {
    $data = 0;
    foreach ($lista as $f) $data = max($data, filemtime($f));
    return $data;
}
function piuVecchio($lista) {
    $data = PHP_INT_MAX;
    foreach ($lista as $f) $data = min($data, filemtime($f));
    return $data;
}

// Crea le pose a sinistra dalle pose a destra.
// Le rifa' solo se mancano, se i frame sono di numero diverso o se la
// posa a destra e' stata reimportata dopo. Restituisce i messaggi da mostrare.
function aggiornaSpecchi($personaggio, $squadra, $tipo) {
    $messaggi = [];
    $pose     = $tipo['pose'];
    $specchi  = $tipo['specchi'];
    $cartella = cartellaArrivo($tipo, $personaggio, $squadra);

    foreach ($specchi as $sinistra => $destra) {
        $prefDestra   = prefisso($personaggio, $pose[$destra][1], $squadra);
        $prefSinistra = prefisso($personaggio, $pose[$sinistra][1], $squadra);

        $fileDestra   = glob($cartella . '/' . $prefDestra . '*.png') ?: [];
        $fileSinistra = glob($cartella . '/' . $prefSinistra . '*.png') ?: [];

        if (count($fileDestra) === 0) continue;   // la destra non c'e' ancora

        $daRifare = count($fileSinistra) !== count($fileDestra);
        if (!$daRifare && piuRecente($fileDestra) > piuVecchio($fileSinistra)) {
            $daRifare = true;
        }
        if (!$daRifare) continue;                 // gia' a posto

        if (!function_exists('imageflip')) {
            $messaggi[] = ['errore', 'Per creare le pose a sinistra serve l\'estensione GD: nel php.ini togli il ; davanti a extension=gd e riavvia Apache.'];
            return $messaggi;
        }

        // Via i vecchi file a sinistra, poi uno specchio per ogni file a destra
        foreach ($fileSinistra as $f) unlink($f);
        foreach ($fileDestra as $f) {
            $numero = substr(basename($f), strlen($prefDestra));   // es. "004.png"
            specchia($f, $cartella . '/' . $prefSinistra . $numero);
        }

        aggiornaJson($personaggio, $squadra, $sinistra, $prefSinistra, count($fileDestra), $tipo);
        $messaggi[] = ['ok', $pose[$sinistra][0] . ': creati ' . count($fileDestra) .
                             ' file specchiando "' . $pose[$destra][0] . '"'];
    }
    return $messaggi;
}


// ---------- 1) MOSTRARE UN'IMMAGINE DELLA CARTELLA DI PARTENZA ----------
// Il browser non puo' aprire file fuori dal sito: le anteprime passano da qui.
if (isset($_GET['img'])) {
    $cartella = leggiCartella($_GET['src'] ?? '');
    $nome     = basename($_GET['img']);          // solo il nome: niente "../"
    $percorso = $cartella . '/' . $nome;
    if (ePng($nome) && is_file($percorso)) {
        header('Content-Type: image/png');
        header('Cache-Control: max-age=3600');
        readfile($percorso);
    } else {
        http_response_code(404);
    }
    exit;
}


// ---------- 2) LE SCELTE DELL'UTENTE ----------
$cartella    = leggiCartella($_REQUEST['src'] ?? '');
$squadra     = $_REQUEST['team'] ?? 'red';
$personaggio = strtolower(trim($_REQUEST['char'] ?? 'mini_pekka'));

// Cosa si importa: un personaggio o la torre principessa
$codiceTipo = $_REQUEST['tipo'] ?? 'personaggio';
if (!isset($tipi[$codiceTipo])) $codiceTipo = 'personaggio';
$tipo    = $tipi[$codiceTipo];
$pose    = $tipo['pose'];
$specchi = $tipo['specchi'];
if ($tipo['fisso'] !== '') $personaggio = $tipo['fisso'];   // la principessa si chiama sempre "princess"

$errore = '';
if ($cartella === '') {
    $errore = 'Scrivi la cartella dove sono i PNG.';
} elseif (!is_dir($cartella)) {
    $errore = 'Cartella non trovata: ' . $cartella;
} elseif (!isset($squadre[$squadra])) {
    $errore = 'Squadra non valida.';
} elseif (!preg_match('/^[a-z0-9_]+$/', $personaggio)) {
    $errore = 'Il nome del personaggio puo\' avere solo lettere minuscole, numeri e _ (es. mini_pekka).';
}


// ---------- 3) INVIO: COPIA I FILE ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $errore === '') {
    $chiave = $_POST['pose'] ?? '';
    $scelti = $_POST['files'] ?? [];

    if (!isset($pose[$chiave])) {
        $_SESSION['messaggio'] = ['errore', 'Scegli una posa.'];
    } elseif (count($scelti) === 0) {
        $_SESSION['messaggio'] = ['errore', 'Non hai selezionato nessun frame.'];
    } else {
        $arrivo = cartellaArrivo($tipo, $personaggio, $squadra);
        if (!is_dir($arrivo)) mkdir($arrivo, 0777, true);

        $prefisso = prefisso($personaggio, $pose[$chiave][1], $squadra);
        $numero = 0;
        foreach ($scelti as $nome) {
            $nome = basename($nome);
            $da = $cartella . '/' . $nome;
            $a  = $arrivo . '/' . $prefisso . str_pad($numero, 3, '0', STR_PAD_LEFT) . '.png';
            if (ePng($nome) && is_file($da)) {
                copy($da, $a);
                $numero++;
            }
        }

        aggiornaJson($personaggio, $squadra, $chiave, $prefisso, $numero, $tipo);

        // Ricorda quali file sono gia' stati usati (per mostrarli sbiaditi)
        if (!isset($_SESSION['usati'][$cartella])) $_SESSION['usati'][$cartella] = [];
        foreach ($scelti as $nome) {
            $_SESSION['usati'][$cartella][] = basename($nome);
        }

        $ultimo = str_pad($numero - 1, 3, '0', STR_PAD_LEFT);
        $_SESSION['messaggio'] = ['ok',
            $pose[$chiave][0] . ': copiati ' . $numero . ' file come ' . $prefisso . '000 ... ' . $ultimo .
            '.png in ' . cartellaAssets($tipo, $personaggio, $squadra) . ' (JSON aggiornato)'];

        // La posa successiva nella lista, saltando quelle a sinistra (si fanno da sole)
        $chiavi = array_keys($pose);
        $posto  = array_search($chiave, $chiavi) + 1;
        while (isset($chiavi[$posto]) && isset($specchi[$chiavi[$posto]])) {
            $posto++;
        }
        $prossima = $chiavi[$posto] ?? $chiave;
    }

    // Si ricarica la pagina con un normale indirizzo: cosi' aggiornando
    // la pagina non si ricopiano i file per sbaglio
    header('Location: ?' . http_build_query([
        'src' => $cartella, 'team' => $squadra, 'char' => $personaggio, 'tipo' => $codiceTipo,
        'pose' => $prossima ?? $chiave,
    ]));
    exit;
}


// ---------- 4) PREPARA LA PAGINA ----------
$messaggi = [];
if (isset($_SESSION['messaggio'])) $messaggi[] = $_SESSION['messaggio'];
unset($_SESSION['messaggio']);

$file  = [];
$usati = [];
$stato = [];   // per ogni posa: quanti file ci sono gia' e quanti se ne aspettano

if ($errore === '') {
    // Prima di tutto: le pose a sinistra dallo specchio di quelle a destra
    foreach (aggiornaSpecchi($personaggio, $squadra, $tipo) as $m) {
        $messaggi[] = $m;
    }

    $file  = elencoPng($cartella);
    $usati = $_SESSION['usati'][$cartella] ?? [];

    // Quanti frame ha la stessa posa nel JSON del personaggio (es. quello blu)
    $base = __DIR__ . '/characters/' . $personaggio . '.json';
    $datiBase = is_file($base) ? json_decode(file_get_contents($base), true) : [];

    foreach ($pose as $chiave => $info) {
        $prefisso = prefisso($personaggio, $info[1], $squadra);
        $esistenti = glob(cartellaArrivo($tipo, $personaggio, $squadra) . '/' . $prefisso . '*.png');

        $atteso = 0;
        if (isset($datiBase[$chiave]['lastFrame'])) {
            $atteso = $datiBase[$chiave]['lastFrame'] - ($datiBase[$chiave]['firstFrame'] ?? 0) + 1;
        }

        $stato[$chiave] = [
            'prefisso' => $prefisso,
            'fatti'    => $esistenti ? count($esistenti) : 0,
            'atteso'   => $atteso,
        ];
    }
}

// Posa selezionata: quella dell'indirizzo, altrimenti la prima non ancora fatta
$posaScelta = $_GET['pose'] ?? '';
if (!isset($pose[$posaScelta])) {
    $posaScelta = array_key_first($pose);   // la prima posa del tipo scelto
    foreach ($stato as $chiave => $s) {
        if ($s['fatti'] === 0 && !isset($specchi[$chiave])) { $posaScelta = $chiave; break; }
    }
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="utf-8">
<title>Importa sprite</title>
<style>
  * { box-sizing: border-box; }
  body { margin: 0; background: #2b2b2b; color: #eee; font-family: Arial, sans-serif; font-size: 14px; }
  header { padding: 12px 16px; background: #1e1e1e; display: flex; gap: 12px; align-items: end; flex-wrap: wrap; }
  header label { display: flex; flex-direction: column; gap: 4px; font-size: 12px; color: #aaa; }
  input[type=text], select { padding: 6px 8px; background: #333; color: #eee; border: 1px solid #555; border-radius: 4px; font-size: 14px; }
  #src { width: 420px; }
  button { padding: 7px 14px; border: 0; border-radius: 4px; background: #3ab0ff; color: #000; font-weight: bold; cursor: pointer; }
  button:disabled { background: #555; color: #888; cursor: default; }
  button.secondario { background: #444; color: #eee; font-weight: normal; }

  .messaggio { margin: 12px 16px 0; padding: 10px 12px; border-radius: 4px; }
  .messaggio.ok { background: #1f4d2e; }
  .messaggio.errore { background: #5a2323; }

  main { display: flex; height: calc(100vh - 70px); }
  /* Colonna delle pose */
  #pose { width: 300px; padding: 12px; overflow-y: auto; background: #252525; }
  #pose label { display: block; padding: 8px; margin-bottom: 4px; border-radius: 4px; cursor: pointer; }
  #pose label:hover { background: #333; }
  #pose input { margin-right: 6px; }
  #pose label:has(input:checked) { background: #2d4a63; }
  .stato { display: block; margin-left: 22px; font-size: 12px; color: #999; }
  .stato.fatto { color: #00ff6a; }

  /* Griglia dei frame */
  #destra { flex: 1; display: flex; flex-direction: column; }
  #barra { padding: 10px 12px; display: flex; gap: 10px; align-items: center; flex-wrap: wrap; border-bottom: 1px solid #3a3a3a; }
  #filtro { width: 260px; }
  #griglia { flex: 1; overflow-y: auto; padding: 12px; display: grid; grid-template-columns: repeat(auto-fill, minmax(110px, 1fr)); gap: 8px; align-content: start; }
  .frame { display: block; padding: 4px; border: 2px solid transparent; border-radius: 4px; background: #333; cursor: pointer; user-select: none; }
  .frame input { display: none; }
  /* sfondo a scacchi: cosi' si vede se il PNG e' trasparente */
  .frame img { display: block; width: 100%; aspect-ratio: 1; object-fit: contain;
    background: repeating-conic-gradient(#999 0 25%, #ccc 0 50%) 0 0 / 16px 16px; }
  .frame span { display: block; margin-top: 4px; font-size: 11px; word-break: break-all; color: #ccc; }
  .frame:has(input:checked) { border-color: #00ff6a; background: #1f4d2e; }
  .frame.usato { opacity: .35; }
  .frame.nascosto { display: none; }

  #invio { padding: 10px 12px; border-top: 1px solid #3a3a3a; display: flex; gap: 12px; align-items: center; }
  #anteprima { color: #aaa; }
  #avviso { color: #ff9a1f; }
</style>
</head>
<body>

<!-- Scelte principali: cartella, squadra, personaggio -->
<form method="get">
  <header>
    <label>Cartella con i PNG
      <input type="text" id="src" name="src" value="<?= h($cartella) ?>" placeholder="C:\Users\France\Desktop\sprite_rossi">
    </label>
    <label>Squadra
      <select name="team">
        <?php foreach ($squadre as $codice => $nome): ?>
          <option value="<?= $codice ?>" <?= $codice === $squadra ? 'selected' : '' ?>><?= $nome ?></option>
        <?php endforeach; ?>
      </select>
    </label>
    <!-- Cambiando tipo la pagina si ricarica subito, con le sue pose -->
    <label>Cosa importi
      <select name="tipo" onchange="this.form.submit()">
        <?php foreach ($tipi as $codice => $t): ?>
          <option value="<?= $codice ?>" <?= $codice === $codiceTipo ? 'selected' : '' ?>><?= h($t['nome']) ?></option>
        <?php endforeach; ?>
      </select>
    </label>
    <!-- Per la torre principessa il nome e' fisso ("princess"): non si scrive -->
    <label>Personaggio
      <input type="text" name="char" value="<?= h($personaggio) ?>" placeholder="mini_pekka" <?= $tipo['fisso'] !== '' ? 'disabled' : '' ?>>
    </label>
    <button type="submit">Apri</button>
  </header>
</form>

<?php foreach ($messaggi as $m): ?>
  <div class="messaggio <?= $m[0] ?>"><?= h($m[1]) ?></div>
<?php endforeach; ?>

<?php if ($errore): ?>
  <div class="messaggio errore"><?= h($errore) ?></div>
<?php else: ?>

<!-- Scelta della posa e dei frame: questo modulo copia i file -->
<form method="post" id="modulo">
  <input type="hidden" name="src"  value="<?= h($cartella) ?>">
  <input type="hidden" name="team" value="<?= h($squadra) ?>">
  <input type="hidden" name="char" value="<?= h($personaggio) ?>">
  <input type="hidden" name="tipo" value="<?= h($codiceTipo) ?>">

  <main>
    <div id="pose">
      <?php foreach ($pose as $chiave => $info): ?>
        <?php $s = $stato[$chiave]; ?>
        <label>
          <input type="radio" name="pose" value="<?= $chiave ?>"
                 data-prefisso="<?= h($s['prefisso']) ?>" data-atteso="<?= $s['atteso'] ?>"
                 <?= $chiave === $posaScelta ? 'checked' : '' ?>>
          <?= h($info[0]) ?>
          <?php if ($s['fatti'] > 0): ?>
            <span class="stato fatto">fatta: <?= $s['fatti'] ?> file</span>
          <?php else: ?>
            <span class="stato">da fare<?= $s['atteso'] ? ' (' . $s['atteso'] . ' frame)' : '' ?></span>
          <?php endif; ?>
          <?php if (isset($specchi[$chiave])): ?>
            <span class="stato">si crea da sola: specchio di "<?= h($pose[$specchi[$chiave]][0]) ?>"</span>
          <?php endif; ?>
          <?php if ($chiave === $tipo['idle']): ?>
            <span class="stato">il primo frame e' anche la posa ferma (idle)</span>
          <?php endif; ?>
        </label>
      <?php endforeach; ?>
    </div>

    <div id="destra">
      <div id="barra">
        <input type="text" id="filtro" placeholder="Filtra per nome (es. attack)">
        <button type="button" class="secondario" id="nessuno">Deseleziona tutto</button>
        <label><input type="checkbox" id="nascondiUsati"> Nascondi i file gia' usati</label>
        <span><?= count($file) ?> PNG nella cartella &middot; clic = un frame, MAIUSC + clic = tutti quelli in mezzo</span>
      </div>

      <div id="griglia">
        <?php foreach ($file as $nome): ?>
          <label class="frame<?= in_array($nome, $usati) ? ' usato' : '' ?>" data-nome="<?= h(strtolower($nome)) ?>">
            <input type="checkbox" name="files[]" value="<?= h($nome) ?>">
            <img loading="lazy" alt="" src="?img=<?= urlencode($nome) ?>&src=<?= urlencode($cartella) ?>">
            <span><?= h($nome) ?></span>
          </label>
        <?php endforeach; ?>
      </div>

      <div id="invio">
        <button type="submit" id="copia" disabled>Copia</button>
        <span id="anteprima"></span>
        <span id="avviso"></span>
      </div>
    </div>
  </main>
</form>

<script>
// ---------- SELEZIONE DEI FRAME ----------
const caselle   = document.querySelectorAll('.frame input');
const riquadri  = document.querySelectorAll('.frame');
const filtro    = document.getElementById('filtro');
const nascondi  = document.getElementById('nascondiUsati');
const copia     = document.getElementById('copia');
const anteprima = document.getElementById('anteprima');
const avviso    = document.getElementById('avviso');

let ultimoCliccato = null;   // posizione dell'ultimo frame cliccato

// Il frame e' visibile? (non nascosto dal filtro o da "nascondi usati")
function visibile(i) {
  return !riquadri[i].classList.contains('nascosto');
}

// MAIUSC + clic: seleziona (o deseleziona) tutti i frame visibili tra
// l'ultimo cliccato e questo
for (let i = 0; i < caselle.length; i++) {
  caselle[i].addEventListener('click', function (evento) {
    if (evento.shiftKey && ultimoCliccato !== null) {
      const da = Math.min(ultimoCliccato, i);
      const a  = Math.max(ultimoCliccato, i);
      for (let j = da; j <= a; j++) {
        if (visibile(j)) caselle[j].checked = caselle[i].checked;
      }
    }
    ultimoCliccato = i;
    aggiorna();
  });
}

// Filtro per nome e "nascondi usati"
function applicaFiltri() {
  const testo = filtro.value.trim().toLowerCase();
  for (const r of riquadri) {
    let nascosto = false;
    if (testo !== '' && !r.dataset.nome.includes(testo)) nascosto = true;
    if (nascondi.checked && r.classList.contains('usato')) nascosto = true;
    r.classList.toggle('nascosto', nascosto);
  }
}
filtro.addEventListener('input', applicaFiltri);
nascondi.addEventListener('change', applicaFiltri);

document.getElementById('nessuno').addEventListener('click', function () {
  for (const c of caselle) c.checked = false;
  aggiorna();
});

// Cambiando posa si aggiorna il testo sotto
for (const r of document.querySelectorAll('#pose input')) {
  r.addEventListener('change', aggiorna);
}

// Scrive in basso cosa succedera' premendo "Copia"
function aggiorna() {
  let quanti = 0;
  for (const c of caselle) {
    if (c.checked) quanti++;
  }

  const posa = document.querySelector('#pose input:checked');
  copia.disabled = (quanti === 0 || posa === null);
  copia.textContent = 'Copia ' + quanti + ' file';

  anteprima.textContent = '';
  avviso.textContent = '';
  if (posa === null || quanti === 0) return;

  const ultimo = String(quanti - 1).padStart(3, '0');   // 3 cifre: 7 -> "007"
  anteprima.textContent = '-> ' + posa.dataset.prefisso + '000 ... ' + ultimo + '.png';

  // Avviso se i frame sono diversi da quelli della stessa posa nell'altra squadra
  const atteso = Number(posa.dataset.atteso);
  if (atteso > 0 && atteso !== quanti) {
    avviso.textContent = 'Attenzione: la stessa posa nel JSON del personaggio ha ' + atteso + ' frame';
  }
}

aggiorna();
</script>

<?php endif; ?>
</body>
</html>