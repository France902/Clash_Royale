<?php
// ============================================================
//  LOBBY: le partite tra due giocatori
//
//  Le lobby stanno in lobby.json, un VETTORE di ARRAY ASSOCIATIVI:
//    [
//      {
//        "id": "6735a1f2c0d9e",
//        "giocatori": [
//          { "username": "France", "fazione": "grifoni", "squadra": "blue", "visto": 1763650000000 },
//          { "username": "Luca",   "fazione": "rune",    "squadra": "red",  "visto": 1763650000150 }
//        ],
//        "inizio": 1763650003000,     <- ora (in millisecondi) in cui parte la partita
//        "eventi": [                  <- gli schieramenti, in ordine
//          { "squadra": "blue", "x": 412.5, "y": 780.25, "tick": 245 }
//        ]
//      }
//    ]
//  - Il primo giocatore che entra crea la lobby ed e' BLU.
//  - Il secondo entra nella stessa lobby ed e' ROSSO: la partita parte 3
//    secondi dopo ("inizio").
//  - "visto" = l'ultima volta che il giocatore si e' fatto sentire. Chi non si
//    fa sentire da troppo tempo e' uscito: la sua lobby viene chiusa.
//
//  Il file viene letto e scritto da tanti giocatori insieme: per non
//  rovinarlo, chi lo apre lo "chiude a chiave" (flock) finche' non ha finito.
// ============================================================

$fileLobby = __DIR__ . '/lobby.json';

// Dopo quanti millisecondi senza notizie un giocatore si considera uscito
const ASSENZA_MASSIMA = 15000;

// Quanti millisecondi dopo l'arrivo del secondo giocatore parte la partita
const ATTESA_INIZIO = 3000;

// L'ora attuale in millisecondi (come nel test del movimento sincronizzato)
function oraMs() {
    return (int) round(microtime(true) * 1000);
}

// Apre lobby.json e lo chiude a chiave: gli altri aspettano il loro turno.
// Restituisce ['file' => il file aperto, 'lobby' => il vettore delle lobby]
function apriLobby($percorso) {
    $file = fopen($percorso, 'c+');   // c+ = leggi e scrivi; se non c'e', crealo
    flock($file, LOCK_EX);            // la chiave: da qui in poi il file e' solo nostro
    $testo = stream_get_contents($file);
    $lobby = json_decode($testo, true);
    if (!is_array($lobby)) $lobby = [];
    return ['file' => $file, 'lobby' => $lobby];
}

// Riscrive lobby.json (se $salva e' true) e restituisce la chiave
function chiudiLobby($aperto, $lobby, $salva) {
    $file = $aperto['file'];
    if ($salva) {
        ftruncate($file, 0);          // svuota il file...
        rewind($file);                // ...torna all'inizio...
        fwrite($file, json_encode(array_values($lobby), JSON_PRETTY_PRINT));   // ...e riscrivilo
    }
    flock($file, LOCK_UN);            // restituisce la chiave
    fclose($file);
}

// Posizione della lobby in cui gioca questo utente, oppure -1
function cercaLobbyDi($lobby, $username) {
    foreach ($lobby as $i => $l) {
        foreach ($l['giocatori'] as $g) {
            if ($g['username'] === $username) return $i;
        }
    }
    return -1;
}

// Toglie le lobby in cui qualcuno non si fa sentire da troppo tempo
function pulisciLobby($lobby, $ora) {
    $rimaste = [];
    foreach ($lobby as $l) {
        $tuttiPresenti = true;
        foreach ($l['giocatori'] as $g) {
            if ($ora - $g['visto'] > ASSENZA_MASSIMA) $tuttiPresenti = false;
        }
        if ($tuttiPresenti) $rimaste[] = $l;
    }
    return $rimaste;
}

// Segna che l'utente si e' appena fatto sentire
function aggiornaVisto(&$lobby, $i, $username, $ora) {
    foreach ($lobby[$i]['giocatori'] as $k => $g) {
        if ($g['username'] === $username) $lobby[$i]['giocatori'][$k]['visto'] = $ora;
    }
}

// La squadra dell'utente in una lobby ('blue' o 'red')
function squadraDi($lobbyUna, $username) {
    foreach ($lobbyUna['giocatori'] as $g) {
        if ($g['username'] === $username) return $g['squadra'];
    }
    return null;
}

// L'utente entra in una lobby:
//   1) se e' gia' in una lobby (es. ha ricaricato la pagina), resta li'
//   2) se c'e' una lobby con un giocatore solo, entra come ROSSO e la partita parte
//   3) altrimenti crea una lobby nuova ed e' BLU
// Restituisce la sua squadra. La fazione serve agli altri per mostrare il suo pannello.
function entraInLobby($percorso, $username, $fazione) {
    $aperto = apriLobby($percorso);
    $ora = oraMs();
    $lobby = pulisciLobby($aperto['lobby'], $ora);

    // 1) Gia' dentro una lobby
    $i = cercaLobbyDi($lobby, $username);
    if ($i !== -1) {
        aggiornaVisto($lobby, $i, $username, $ora);
        $squadra = squadraDi($lobby[$i], $username);
        chiudiLobby($aperto, $lobby, true);
        return $squadra;
    }

    // 2) Una lobby che aspetta il secondo giocatore
    foreach ($lobby as $k => $l) {
        if (count($l['giocatori']) === 1) {
            $lobby[$k]['giocatori'][] = ['username' => $username, 'fazione' => $fazione, 'squadra' => 'red', 'visto' => $ora];
            $lobby[$k]['inizio'] = $ora + ATTESA_INIZIO;
            chiudiLobby($aperto, $lobby, true);
            return 'red';
        }
    }

    // 3) Nessuno da sfidare: lobby nuova, si aspetta
    $lobby[] = [
        'id'        => uniqid(),
        'giocatori' => [['username' => $username, 'fazione' => $fazione, 'squadra' => 'blue', 'visto' => $ora]],
        'inizio'    => null,
        'eventi'    => [],
    ];
    chiudiLobby($aperto, $lobby, true);
    return 'blue';
}

// L'utente esce (logout): la sua lobby viene chiusa
function esciDaLobby($percorso, $username) {
    $aperto = apriLobby($percorso);
    $lobby = $aperto['lobby'];
    $i = cercaLobbyDi($lobby, $username);
    if ($i !== -1) unset($lobby[$i]);
    chiudiLobby($aperto, $lobby, true);
}