<?php
// ============================================================
//  ANTEPRIMA DELLE ANIMAZIONI
//
//  Fa girare in loop TUTTE le animazioni di un personaggio, una accanto
//  all'altra, per controllare che siano complete:
//    - in alto scegli il JSON (es. mini_pekka.json, mini_pekka_red.json)
//    - le animazioni sono disposte come le direzioni:
//          sinistra | dritto | destra
//      cosi' si confronta subito la sinistra con la destra
//    - se una sezione manca nel JSON lo scrive, e dice quale animazione
//      usera' il gioco al suo posto
//    - se manca un PNG lo scrive con il nome del file
//  Tutte le animazioni sono disegnate alla STESSA scala: se un personaggio
//  "salta" di grandezza tra una posa e l'altra, si vede.
// ============================================================

$versione = time();   // per non far usare al browser immagini vecchie

// Le animazioni, nella disposizione della pagina: una riga per tipo,
// tre colonne (sinistra, dritto, destra)
$righe = [
    'Cammina in avanti'  => ['walkLeft',       'walk',       'walkRight'],
    'Cammina indietro'   => ['walkBackLeft',   'walkBack',   'walkBackRight'],
    'Attacca in avanti'  => ['attackLeft',     'attack',     'attackRight'],
    'Attacca indietro'   => ['attackBackLeft', 'attackBack', 'attackBackRight'],
];

// Se una sezione manca, il gioco usa questa (come in arena.php)
$riserva = [
    'walk' => null,               'attack' => null,
    'walkRight' => 'walk',        'attackRight' => 'attack',
    'walkLeft' => 'walk',         'attackLeft' => 'attack',
    'walkBack' => 'walk',         'attackBack' => 'attack',
    'walkBackRight' => 'walkBack', 'attackBackRight' => 'attackBack',
    'walkBackLeft' => 'walkBack',  'attackBackLeft' => 'attackBack',
];

// Una sezione del JSON e' completa se ha prefix, firstFrame e lastFrame
function haSezione($cfg, $nome) {
    return isset($cfg[$nome]['prefix'], $cfg[$nome]['firstFrame'], $cfg[$nome]['lastFrame']);
}

function h($testo) {
    return htmlspecialchars($testo, ENT_QUOTES, 'UTF-8');
}

// ---------- QUALE JSON ----------
$elencoJson = [];
foreach (glob(__DIR__ . '/characters/*.json') ?: [] as $percorso) {
    $elencoJson[] = basename($percorso);
}

$scelto = $_GET['json'] ?? 'mini_pekka.json';
if (!in_array($scelto, $elencoJson) && count($elencoJson) > 0) {
    $scelto = $elencoJson[0];
}

$errore = '';
$cfg = null;
if (count($elencoJson) === 0) {
    $errore = 'Nessun JSON nella cartella characters/';
} else {
    $cfg = json_decode(file_get_contents(__DIR__ . '/characters/' . $scelto), true);
    if (!is_array($cfg)) $errore = 'Il file ' . $scelto . ' non e\' un JSON valido.';
}

// ---------- PREPARA LE ANIMAZIONI ----------
$animazioni = [];
if ($errore === '') {
    $cartella = $cfg['assetsDir'] ?? 'assets';
    $tickCamminata = $cfg['walk']['ticksPerFrame'] ?? 3;

    foreach ($riserva as $chiave => $nulla) {
        $anim = [
            'tipo'      => (strpos($chiave, 'attack') === 0) ? 'attack' : 'walk',
            'urls'      => [],
            'nomiFile'  => [],
            'mancanti'  => [],
            'ticks'     => $cfg[$chiave]['ticksPerFrame'] ?? $tickCamminata,
            'sostituto' => null,
        ];

        if (haSezione($cfg, $chiave)) {
            $sezione = $cfg[$chiave];
            for ($i = $sezione['firstFrame']; $i <= $sezione['lastFrame']; $i++) {
                $nome = $sezione['prefix'] . str_pad($i, 3, '0', STR_PAD_LEFT) . '.png';
                $percorso = $cartella . '/' . $nome;
                $anim['nomiFile'][] = $nome;
                $anim['urls'][] = $percorso . '?v=' . $versione;
                if (!is_file(__DIR__ . '/' . $percorso)) $anim['mancanti'][] = $nome;
            }
        } else {
            // Manca: cerca quale animazione usera' il gioco al suo posto
            $d = $riserva[$chiave];
            while ($d !== null && !haSezione($cfg, $d)) {
                $d = $riserva[$d];
            }
            $anim['sostituto'] = $d;
        }

        $animazioni[$chiave] = $anim;
    }
}

// I tempi dell'attacco (dalla sezione "attack", valgono per tutte le direzioni)
$attacco = $cfg['attack'] ?? [];
$tempiAttacco = [
    'slow'        => $attacco['slowTicksPerFrame'] ?? 3,
    'fast'        => $attacco['fastTicksPerFrame'] ?? ($attacco['slowTicksPerFrame'] ?? 3),
    'slowUntil'   => $attacco['slowUntilFrame'] ?? 0,
    'damageIndex' => isset($attacco['damageFrame']) ? $attacco['damageFrame'] - ($attacco['firstFrame'] ?? 0) : -1,
];
?>
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="utf-8">
<title>Anteprima animazioni</title>
<style>
  * { box-sizing: border-box; }
  body { margin: 0; background: #2b2b2b; color: #eee; font-family: Arial, sans-serif; font-size: 14px; }
  header { padding: 12px 16px; background: #1e1e1e; display: flex; gap: 14px; align-items: center; flex-wrap: wrap; }
  select, button { padding: 6px 10px; background: #333; color: #eee; border: 1px solid #555; border-radius: 4px; font-size: 14px; cursor: pointer; }
  .errore { margin: 16px; padding: 10px; background: #5a2323; border-radius: 4px; }

  main { padding: 16px; }
  h2 { margin: 18px 0 8px; font-size: 16px; color: #ffd400; }
  .riga { display: grid; grid-template-columns: repeat(3, 230px); gap: 12px; }

  .cella { background: #333; border-radius: 6px; padding: 8px; border: 2px solid transparent; }
  .cella.problema { border-color: #ff3b3b; }
  .cella.assente  { border-color: #ff9a1f; }
  .titolo { font-weight: bold; margin-bottom: 6px; }
  /* sfondo a scacchi: si vede se il PNG e' trasparente */
  canvas { display: block; width: 210px; height: 210px; border-radius: 4px;
    background: repeating-conic-gradient(#999 0 25%, #ccc 0 50%) 0 0 / 20px 20px; }
  .dati { margin-top: 6px; font-size: 12px; color: #bbb; min-height: 32px; word-break: break-all; }
  .dati .colpo { color: #ff3b3b; font-weight: bold; }
  .avviso { margin-top: 4px; font-size: 12px; color: #ff9a1f; }
  .rosso  { color: #ff6b6b; }
</style>
</head>
<body>

<header>
  <form method="get">
    Personaggio:
    <select name="json" onchange="this.form.submit()">
      <?php foreach ($elencoJson as $nome): ?>
        <option <?= $nome === $scelto ? 'selected' : '' ?>><?= h($nome) ?></option>
      <?php endforeach; ?>
    </select>
  </form>
  <button id="pausa">Pausa</button>
  <button id="indietro" disabled>&#9664; frame</button>
  <button id="avanti" disabled>frame &#9654;</button>
  Velocita':
  <select id="velocita">
    <option value="0.25">0.25x</option>
    <option value="0.5">0.5x</option>
    <option value="1" selected>1x</option>
    <option value="2">2x</option>
  </select>
</header>

<?php if ($errore): ?>
  <div class="errore"><?= h($errore) ?></div>
<?php else: ?>

<main>
  <?php foreach ($righe as $titolo => $chiavi): ?>
    <h2><?= h($titolo) ?></h2>
    <div class="riga">
      <?php foreach ($chiavi as $chiave): ?>
        <?php $a = $animazioni[$chiave]; ?>
        <div class="cella<?= $a['sostituto'] !== null || count($a['urls']) === 0 ? ' assente' : '' ?><?= count($a['mancanti']) ? ' problema' : '' ?>"
             id="cella-<?= $chiave ?>">
          <div class="titolo"><?= h($chiave) ?></div>
          <canvas width="420" height="420"></canvas>
          <div class="dati"></div>

          <?php if (count($a['urls']) === 0): ?>
            <div class="avviso">
              Manca nel JSON.
              <?php if ($a['sostituto'] !== null): ?>
                In gioco usa "<?= h($a['sostituto']) ?>".
              <?php else: ?>
                Nessuna animazione da usare al suo posto.
              <?php endif; ?>
            </div>
          <?php endif; ?>

          <?php if (count($a['mancanti'])): ?>
            <div class="avviso rosso">
              PNG mancanti (<?= count($a['mancanti']) ?>):<br>
              <?= h(implode(', ', $a['mancanti'])) ?>
            </div>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endforeach; ?>
</main>

<script>
// ---------- DATI (arrivano da PHP) ----------
const ANIMAZIONI = <?= json_encode($animazioni, JSON_UNESCAPED_SLASHES) ?>;
const ATTACCO    = <?= json_encode($tempiAttacco) ?>;
const TICK_RATE  = 60;   // aggiornamenti al secondo, come in arena.php

// ---------- PREPARA LE CELLE ----------
// Per ogni animazione: le sue immagini, il canvas, e a che frame e' arrivata
const celle = [];
let latoMassimo = 1;   // il lato piu' grande tra tutte le immagini: decide la scala comune

for (const chiave in ANIMAZIONI) {
  const anim = ANIMAZIONI[chiave];
  if (anim.urls.length === 0) continue;   // animazione assente: niente da far girare

  const div = document.getElementById('cella-' + chiave);
  const cella = {
    anim: anim,
    canvas: div.querySelector('canvas'),
    dati: div.querySelector('.dati'),
    immagini: [],
    frame: 0,
    frameTime: 0
  };

  for (const url of anim.urls) {
    const img = new Image();
    img.onload = function () {
      latoMassimo = Math.max(latoMassimo, img.naturalWidth, img.naturalHeight);
    };
    img.src = url;
    cella.immagini.push(img);
  }
  celle.push(cella);
}

// ---------- TEMPI ----------
// Quanti tick dura un frame: la camminata ha un valore fisso,
// l'attacco ha i primi frame lenti e poi veloci (come in arena.php)
function durataFrame(cella) {
  if (cella.anim.tipo === 'walk') return cella.anim.ticks;
  if (cella.frame <= ATTACCO.slowUntil) return ATTACCO.slow;
  return ATTACCO.fast;
}

// Un tick: il frame avanza quando e' durato abbastanza, poi ricomincia da capo
function tick(cella) {
  cella.frameTime++;
  const durata = durataFrame(cella);
  if (cella.frameTime < durata) return;
  cella.frameTime -= durata;
  cella.frame = (cella.frame + 1) % cella.immagini.length;
}

// Sposta tutte le animazioni di un frame (per i pulsanti quando e' in pausa)
function spostaFrame(passo) {
  for (const c of celle) {
    const n = c.immagini.length;
    c.frame = (c.frame + passo + n) % n;   // + n: cosi' da 0 indietro va all'ultimo
    c.frameTime = 0;
  }
  disegna();
}

// ---------- DISEGNO ----------
function disegna() {
  for (const c of celle) {
    const ctx = c.canvas.getContext('2d');
    const lato = c.canvas.width;
    ctx.clearRect(0, 0, lato, lato);

    const img = c.immagini[c.frame];
    if (img.complete && img.naturalWidth > 0) {
      // Stessa scala per tutte le animazioni, immagine al centro
      const scala = lato * 0.95 / latoMassimo;
      const w = img.naturalWidth * scala;
      const h = img.naturalHeight * scala;
      ctx.drawImage(img, (lato - w) / 2, (lato - h) / 2, w, h);
    }

    // Sotto: numero del frame e nome del file
    let testo = 'frame ' + (c.frame + 1) + '/' + c.immagini.length + ' - ' + c.anim.nomiFile[c.frame];
    if (c.anim.tipo === 'attack' && c.frame === ATTACCO.damageIndex) {
      testo += ' <span class="colpo">COLPO</span>';   // il frame in cui arriva il danno
    }
    c.dati.innerHTML = testo;
  }
}

// ---------- ANIMAZIONE ----------
let inPausa = false;
let velocita = 1;
let ultimoTempo = performance.now();
let accumulatore = 0;

function loop(adesso) {
  if (!inPausa) {
    accumulatore += Math.min(adesso - ultimoTempo, 250) * velocita;
    while (accumulatore >= 1000 / TICK_RATE) {
      for (const c of celle) tick(c);
      accumulatore -= 1000 / TICK_RATE;
    }
  }
  ultimoTempo = adesso;
  disegna();
  requestAnimationFrame(loop);
}
requestAnimationFrame(loop);

// ---------- PULSANTI ----------
const pulsantePausa = document.getElementById('pausa');
const pulsanteIndietro = document.getElementById('indietro');
const pulsanteAvanti = document.getElementById('avanti');

pulsantePausa.addEventListener('click', function () {
  inPausa = !inPausa;
  if (inPausa) pulsantePausa.textContent = 'Riprendi';
  else         pulsantePausa.textContent = 'Pausa';
  pulsanteIndietro.disabled = !inPausa;   // frame per frame solo in pausa
  pulsanteAvanti.disabled = !inPausa;
});
pulsanteIndietro.addEventListener('click', function () { spostaFrame(-1); });
pulsanteAvanti.addEventListener('click', function () { spostaFrame(1); });

document.getElementById('velocita').addEventListener('change', function () {
  velocita = Number(this.value);
});
</script>

<?php endif; ?>
</body>
</html>
