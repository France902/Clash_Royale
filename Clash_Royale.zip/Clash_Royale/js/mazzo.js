// ============================================================
//  IL MAZZO: le carte che posso schierare e quella scelta
//
//  A sinistra della mappa c'e' una pila di bottoni, uno per carta, con il
//  nome del personaggio e il suo costo. La carta scelta e' evidenziata e si
//  cambia cliccando un bottone o con le frecce della tastiera.
//  Un bottone diventa sbiadito quando non c'e' abbastanza elisir per quella carta.
// ============================================================

const MAZZO = MAZZI[MIA_SQUADRA];   // le mie carte, in ordine (es. ['mini_pekka', 'knight'])
let cartaScelta = 0;                // il posto della carta scelta nel mazzo

const pilaCarte = document.getElementById('carte');
const bottoniCarte = [];            // un bottone per carta, nello stesso ordine del mazzo

// La carta scelta adesso (es. 'knight')
function cartaAttuale() {
  return MAZZO[cartaScelta];
}

// Sceglie la carta al posto i. Si gira in tondo: dopo l'ultima torna la prima.
function scegliCarta(i) {
  cartaScelta = (i + MAZZO.length) % MAZZO.length;   // % = resto: tiene i tra 0 e il numero di carte
  for (let j = 0; j < bottoniCarte.length; j++) {
    bottoniCarte[j].classList.toggle('scelta', j === cartaScelta);
  }
}

// Crea un bottone per ogni carta: nome del personaggio e costo nella goccia.
// textContent (non innerHTML): un nome nel JSON non puo' diventare codice HTML.
function creaPilaCarte() {
  for (let i = 0; i < MAZZO.length; i++) {
    const cfg = PERSONAGGI[MIA_SQUADRA][MAZZO[i]];

    const bottone = document.createElement('button');
    bottone.type = 'button';
    const nome = document.createElement('span');
    nome.textContent = cfg.name;
    const costo = document.createElement('span');
    costo.className = 'costo';
    costo.textContent = cfg.elixir;
    bottone.appendChild(nome);
    bottone.appendChild(costo);

    bottone.addEventListener('click', function () {
      scegliCarta(i);
      bottone.blur();   // il bottone non resta "attivo": le frecce continuano a funzionare
    });
    pilaCarte.appendChild(bottone);
    bottoniCarte.push(bottone);
  }
  scegliCarta(0);
}

// Le frecce cambiano carta: su/sinistra = quella prima, giu'/destra = quella dopo
function tastoPremuto(evento) {
  let passo = 0;
  if (evento.key === 'ArrowUp'   || evento.key === 'ArrowLeft')  passo = -1;
  if (evento.key === 'ArrowDown' || evento.key === 'ArrowRight') passo = 1;
  if (passo === 0) return;
  evento.preventDefault();          // le frecce non fanno scorrere la pagina
  scegliCarta(cartaScelta + passo);
}

// Mette la pila nello spazio vuoto a sinistra della mappa, a meta' altezza
// (la chiama layout() quando cambia la finestra)
function posizionaPilaCarte() {
  const larghezza = Math.max(Math.min(mapLeft - 20, 190), 100);   // tra 100 e 190 pixel
  pilaCarte.style.width = larghezza + 'px';
}

// A ogni fotogramma: sbiadisce le carte che adesso non posso permettermi
function aggiornaPilaCarte() {
  for (let i = 0; i < MAZZO.length; i++) {
    bottoniCarte[i].classList.toggle('scarica', !hoElisir(MAZZO[i]));
  }
}
