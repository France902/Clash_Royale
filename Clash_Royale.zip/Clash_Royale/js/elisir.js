// ============================================================
//  ELISIR: quanto ne ho e la sua barra
//
//  Come per la partita, l'elisir non si "tiene": si CALCOLA dagli
//  schieramenti e dal tempo del server, con lo stesso conto del server
//  (inc/elisir.php). Si conta in tick di ricarica: 1 di elisir =
//  TICK_PER_ELISIR tick. Sullo schermo si divide e diventa elisir vero.
// ============================================================

// L'elisir di una squadra al tick dato (in tick di ricarica).
// Si parte con la barra piena. Ogni schieramento, nel tick del CLIC ('clic'),
// toglie il costo; tra uno schieramento e l'altro la barra cresce di 1 per
// tick, ma mai oltre il massimo. (Uguale a elisirAl in inc/elisir.php)
function elisirAl(squadra, tick) {
  tick = Math.max(tick, 0);       // prima dell'inizio la barra e' piena
  let elisir = ELISIR_MAX;
  let ultimo = 0;                 // il tick dell'ultimo conto fatto
  for (const e of eventi) {
    if (e.squadra !== squadra || e.clic > tick) continue;
    elisir = Math.min(ELISIR_MAX, elisir + (e.clic - ultimo)) - COSTO_ELISIR;
    ultimo = e.clic;
  }
  return Math.min(ELISIR_MAX, elisir + (tick - ultimo));
}

// Il mio elisir ADESSO (in tick di ricarica). Si usa il tick con la virgola,
// cosi' la barra cresce fluida. Gli schieramenti appena cliccati, che il
// server non ha ancora confermato, si pagano subito: la barra scende al clic.
function elisirMio() {
  if (inizioPartita === null) return ELISIR_MAX;   // si aspetta l'avversario: barra piena
  let tick = (oraServer() - inizioPartita) * TICK_RATE / 1000;
  // Un mio schieramento confermato e' sempre gia' successo, anche se il
  // nostro orologio e' un pelo indietro rispetto a quello del server
  for (const e of eventi) {
    if (e.squadra === MIA_SQUADRA) tick = Math.max(tick, e.clic);
  }
  return Math.max(elisirAl(MIA_SQUADRA, tick) - inAttesa.length * COSTO_ELISIR, 0);
}

// Ho abbastanza elisir per schierare un Mini P.E.K.K.A?
function hoElisir() {
  return elisirMio() >= COSTO_ELISIR;
}

// ---------- LA BARRA ----------
// #elisir (in pagina.php) e' la BASE scura, sempre visibile. Dentro ci sono
// TACCHE div (una per elisir), ognuna con il suo riempimento colorato.
// L'ultima tacca piena a meta' si riempie a meta': la barra cresce fluida.
const barraElisir = document.getElementById('elisir');
const riempimenti = [];            // il div colorato di ogni tacca
const larghezzeAttuali = [];       // l'ultima larghezza scritta (per non riscriverla a ogni fotogramma)

function creaBarraElisir() {
  for (let i = 0; i < TACCHE; i++) {
    const tacca = document.createElement('div');
    tacca.className = 'tacca';
    const riempimento = document.createElement('div');
    riempimento.className = 'riempimento';
    tacca.appendChild(riempimento);
    barraElisir.appendChild(tacca);
    riempimenti.push(riempimento);
    larghezzeAttuali.push('');
  }
}

// Mette la barra al suo posto (la chiama layout() quando cambia la finestra):
// centrata sulla mappa, dalla parte del mio campo (blu in basso, rosso in alto)
function posizionaBarraElisir() {
  const larghezza = mapImg.width * mapScale * BARRA_ELISIR.larghezza;
  const s = barraElisir.style;
  s.width  = larghezza + 'px';
  s.height = BARRA_ELISIR.altezza * mapScale + 'px';
  s.left   = mapLeft + (mapImg.width * mapScale - larghezza) / 2 + 'px';
  if (MIA_SQUADRA === 'blue') {
    s.top = '';
    s.bottom = BARRA_ELISIR.bordo + 'px';
    // le righe di debug (in basso a destra) salgono sopra la barra, per non finirci sotto
    info.style.bottom = BARRA_ELISIR.bordo + BARRA_ELISIR.altezza * mapScale + 8 + 'px';
  } else {
    s.bottom = '';
    s.top = BARRA_ELISIR.bordo + 'px';
  }
}

// A ogni fotogramma: ogni tacca si riempie di quanto le spetta
// (tacca i: piena se elisir >= i + 1, vuota se elisir <= i, a meta' in mezzo)
function aggiornaBarraElisir() {
  const elisir = elisirMio() / TICK_PER_ELISIR;   // da tick di ricarica a elisir
  for (let i = 0; i < TACCHE; i++) {
    const pieno = Math.min(Math.max(elisir - i, 0), 1);
    const larghezza = (pieno * 100).toFixed(1) + '%';
    if (larghezza !== larghezzeAttuali[i]) {
      riempimenti[i].style.width = larghezza;
      larghezzeAttuali[i] = larghezza;
    }
  }
}
