// ============================================================
//  PICCOLI AIUTI: valori mancanti, distanze, punto piu' vicino
// ============================================================

// Vero se un valore NON c'e' (per esempio manca nel JSON)
function manca(valore) {
  return valore === undefined || valore === null;
}

// Restituisce il valore, oppure quello predefinito se il valore manca.
// Esempio: oppure(cfg.scale, 1) -> la scala del JSON, o 1 se non c'e'.
function oppure(valore, predefinito) {
  if (manca(valore)) return predefinito;
  return valore;
}

// Lunghezza di un vettore (dx, dy): teorema di Pitagora.
// Si usa Math.sqrt e non Math.hypot: sqrt da' lo STESSO risultato su ogni
// browser, e i due giocatori devono calcolare esattamente gli stessi numeri.
function lunghezza(dx, dy) {
  return Math.sqrt(dx * dx + dy * dy);
}

// Distanza tra due punti
function distanza(x1, y1, x2, y2) {
  return lunghezza(x2 - x1, y2 - y1);
}

// Tra i punti della lista, quello piu' vicino al punto (x, y)
function piuVicino(lista, x, y) {
  let migliore = lista[0];
  for (const p of lista) {
    if (distanza(p.x, p.y, x, y) < distanza(migliore.x, migliore.y, x, y)) {
      migliore = p;
    }
  }
  return migliore;
}
