// ============================================================
//  AVVIO: caricamento delle immagini, ciclo di animazione, partenza
// ============================================================

// ---------- ANIMAZIONE ----------
// Il browser chiama loop() a ogni fotogramma dello schermo (60, 144... volte al secondo).
// A che tick siamo NON lo decide il nostro computer: si calcola dall'ora del
// server, quindi e' lo stesso tick per tutti e due i giocatori.
function loop() {
  if (inizioPartita !== null) {
    const tickAdesso = Math.floor((oraServer() - inizioPartita) * TICK_RATE / 1000);
    avanzaFinoA(tickAdesso);
  }

  draw();
  writeInfo();
  aggiornaBarraElisir();
  aggiornaPilaCarte();
  requestAnimationFrame(loop);   // richiama loop() al prossimo fotogramma
}

// ---------- AVVIO ----------

// Carica un'immagine. Una "Promise" e' una promessa di risultato:
// l'immagine arriva dopo un po', e "await" aspetta che arrivi.
function loadImage(src) {
  return new Promise(function (ok, errore) {
    const img = new Image();
    img.onload  = function () { ok(img); };
    img.onerror = function () { errore(new Error('Immagine non trovata: ' + src)); };
    img.src = src;
  });
}

// Carica tutte le immagini di una lista (insieme) e aspetta che arrivino tutte
function caricaTutte(indirizzi) {
  const promesse = [];
  for (const url of indirizzi) {
    promesse.push(loadImage(url));
  }
  return Promise.all(promesse);
}

async function avvio() {
  try {
    // 1) Le immagini
    mapImg = await loadImage(MAP_URL);

    barImgs = {
      base: await loadImage(BARS.base),
      red:  await loadImage(BARS.red),
      blue: await loadImage(BARS.blue)
    };

    // Camminate e attacchi di tutte le 6 direzioni, una volta per ogni carta
    // di ogni mazzo: li usano tutti i personaggi di quella carta
    for (const team of ['blue', 'red']) {
      for (const carta of MAZZI[team]) {
        const cfg = PERSONAGGI[team][carta];
        SPRITE[team][carta] = { walk: {}, attack: {} };
        for (const d in DIREZIONI) {
          const camminata = sezionePer(cfg, d, 'walk');
          const attacco   = sezionePer(cfg, d, 'attack');
          SPRITE[team][carta].walk[d] = await caricaTutte(camminata.urls);
          if (attacco !== null) SPRITE[team][carta].attack[d] = await caricaTutte(attacco.urls);
          else                  SPRITE[team][carta].attack[d] = [];   // nessun attacco
        }
      }
    }

    for (const t of TOWERS) {
      t.img   = await loadImage(t.url);
      t.maxHp = t.hp;               // la vita iniziale e' anche quella massima
    }
    await caricaSopraTorri();       // re, cannoni e principesse

    // 2) I segnaposto di controllo, la barra dell'elisir e le carte
    creaSegnaposto();
    creaBarraElisir();
    creaPilaCarte();

    // 3) Posizioni, eventi e primo giro
    layout();
    window.addEventListener('resize', layout);       // finestra ridimensionata = rifai i calcoli
    canvas.addEventListener('click', clicGiocatore); // clic = schiera la carta scelta
    window.addEventListener('keydown', tastoPremuto); // frecce = cambia carta

    resetArena();   // si parte con il campo vuoto

    // 4) Si chiede lo stato al server ogni 150 ms, e si parte
    chiediStato();
    setInterval(chiediStato, 150);
    requestAnimationFrame(loop);
  } catch (err) {
    info.textContent = err.message;   // se un'immagine manca, lo scrive in basso
  }
}

avvio();
