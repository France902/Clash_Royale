// ============================================================
//  AVVIO: caricamento delle immagini, ciclo di animazione, partenza
// ============================================================

// ---------- ANIMAZIONE ----------
// Il browser chiama loop() a ogni fotogramma dello schermo (60, 144... volte al secondo).
// A che tick siamo NON lo decide il nostro computer: si calcola dall'ora del
// server, quindi e' lo stesso tick per tutti e due i giocatori.
function loop() {
  if (inizioPartita !== null) {
    const tickAdesso = Math.floor((oraServer() - inizioPartita) * TICK_RATE / 1000);
    avanzaFinoA(tickAdesso);
  }

  draw();
  writeInfo();
  aggiornaBarraElisir();
  requestAnimationFrame(loop);   // richiama loop() al prossimo fotogramma
}

// ---------- AVVIO ----------

// Carica un'immagine. Una "Promise" e' una promessa di risultato:
// l'immagine arriva dopo un po', e "await" aspetta che arrivi.
function loadImage(src) {
  return new Promise(function (ok, errore) {
    const img = new Image();
    img.onload  = function () { ok(img); };
    img.onerror = function () { errore(new Error('Immagine non trovata: ' + src)); };
    img.src = src;
  });
}

// Carica tutte le immagini di una lista (insieme) e aspetta che arrivino tutte
function caricaTutte(indirizzi) {
  const promesse = [];
  for (const url of indirizzi) {
    promesse.push(loadImage(url));
  }
  return Promise.all(promesse);
}

async function avvio() {
  try {
    // 1) Le immagini
    mapImg = await loadImage(MAP_URL);

    barImgs = {
      base: await loadImage(BARS.base),
      red:  await loadImage(BARS.red),
      blue: await loadImage(BARS.blue)
    };

    // Camminate e attacchi di tutte le 6 direzioni, una volta per squadra:
    // li usano tutti i Mini P.E.K.K.A di quella squadra
    for (const team of ['blue', 'red']) {
      for (const d in DIREZIONI) {
        const camminata = sezionePer(PERSONAGGI[team], d, 'walk');
        const attacco   = sezionePer(PERSONAGGI[team], d, 'attack');
        SPRITE[team].walk[d] = await caricaTutte(camminata.urls);
        if (attacco !== null) SPRITE[team].attack[d] = await caricaTutte(attacco.urls);
        else                  SPRITE[team].attack[d] = [];   // nessun attacco
      }
    }

    for (const t of TOWERS) {
      t.img   = await loadImage(t.url);
      t.maxHp = t.hp;               // la vita iniziale e' anche quella massima
    }
    await caricaSopraTorri();       // re, cannoni e principesse

    // 2) I segnaposto di controllo e la barra dell'elisir
    creaSegnaposto();
    creaBarraElisir();

    // 3) Posizioni, eventi e primo giro
    layout();
    window.addEventListener('resize', layout);       // finestra ridimensionata = rifai i calcoli
    canvas.addEventListener('click', clicGiocatore); // clic = schiera un Mini P.E.K.K.A

    resetArena();   // si parte con il campo vuoto

    // 4) Si chiede lo stato al server ogni 150 ms, e si parte
    chiediStato();
    setInterval(chiediStato, 150);
    requestAnimationFrame(loop);
  } catch (err) {
    info.textContent = err.message;   // se un'immagine manca, lo scrive in basso
  }
}

avvio();
