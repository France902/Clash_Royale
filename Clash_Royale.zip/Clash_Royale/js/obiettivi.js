// ============================================================
//  OBIETTIVI: dove andare (ponte, torre o nemico) e quando cambiare idea
// ============================================================

// Il quadrato di attacco piu' vicino al punto (x, y), tra quelli davanti a
// torri avversarie ancora in piedi. null = non ci sono piu' torri da attaccare.
function quadratoTorrePiuVicino(u, x, y) {
  const liberi = [];
  for (const q of u.quadratiTorre) {
    if (!distrutta(q.torre)) liberi.push(q);
  }
  if (liberi.length === 0) return null;
  return piuVicino(liberi, x, y);
}

// Il nemico vivo piu' vicino A PIEDI (passando dai ponti). null = nessun
// nemico in campo, o il personaggio non sa attaccare.
// A parita' di distanza vince quello schierato prima: cosi' la scelta e' la
// stessa su tutti e due gli schermi.
function nemicoPiuVicino(u) {
  if (!puoAttaccare(u)) return null;
  let migliore = null;
  let distanzaMigliore = Infinity;
  for (const n of UNITA) {
    if (!n.alive || n.team === u.team) continue;   // morti e compagni non contano
    const d = distanzaAPiedi(u, n);
    if (d < distanzaMigliore) {
      distanzaMigliore = d;
      migliore = n;
    }
  }
  return migliore;
}

// Sceglie la prossima meta: insegue il nemico piu' vicino se e' piu' vicino
// del quadrato di torre (ancora in piedi) "quadrato", altrimenti va al quadrato.
function scegliMeta(u, quadrato) {
  const nemico = nemicoPiuVicino(u);
  let versoNemico = Infinity;      // Infinity = "lontanissimo" (nessun nemico)
  if (nemico !== null) versoNemico = distanzaAPiedi(u, nemico);
  let versoTorre = Infinity;
  if (quadrato !== null) versoTorre = distanzaAPiedi(u, quadrato);

  if (versoNemico === Infinity && versoTorre === Infinity) {
    stopHere(u);                   // niente da attaccare: si ferma
  } else if (versoNemico < versoTorre) {
    u.preda = nemico;              // insegue il nemico (la torre si decide quando muore)
    u.phase = 'nemico';
  } else {
    u.path.push(quadrato);         // va al quadrato della torre
    u.target = u.path[u.step];
    u.phase = 'torre';
  }
  colorDots();
}

// Sul ponte: confronta il nemico con il quadrato della torre del suo asse
// (se quella torre e' gia' distrutta, con il quadrato di torre piu' vicino).
function planAfterBridge(u) {
  let quadrato = u.axis.tower;
  if (distrutta(quadrato.torre)) quadrato = quadratoTorrePiuVicino(u, u.x, u.y);
  scegliMeta(u, quadrato);
}

// Ha distrutto una torre (o e' arrivato davanti a una torre gia' caduta):
// punta l'obiettivo piu' vicino, un nemico o la torre piu' vicina (di solito il re)
function cercaObiettivo(u) {
  riprendiCammino(u);
  scegliMeta(u, quadratoTorrePiuVicino(u, u.x, u.y));
}

// Il nemico che attaccava o inseguiva e' morto (ucciso da lui o da un
// compagno): riprende il percorso. Se lo stava inseguendo (o non aveva piu'
// punti), va al quadrato di torre piu' vicino al punto in cui e' morto.
function dopoUccisione(u, morto) {
  riprendiCammino(u);
  if (u.preda !== null || u.step >= u.path.length) {
    u.preda = null;
    const quadrato = quadratoTorrePiuVicino(u, morto.x, morto.y);
    if (quadrato === null) {       // non ci sono piu' torri da attaccare
      stopHere(u);
      colorDots();
      return;
    }
    u.path.push(quadrato);
    u.step = u.path.length - 1;    // si va dritti al quadrato (si salta il resto della corsia)
    u.phase = 'torre';
  }
  u.target = u.path[u.step];
  colorDots();
}

// A ogni passo controlla se deve cambiare idea:
//   - la preda e' morta (l'ha uccisa un compagno): riprende il percorso
//   - sta inseguendo, ma un altro nemico e' piu' vicino: insegue quello
//   - non sta inseguendo, ma un nemico e' piu' vicino della meta (es. e'
//     appena comparso davanti a lui): lascia la meta e insegue il nemico.
//     Vale fin dal primo passo, anche rispetto al primo quadrato d'ingresso.
function rivalutaObiettivo(u) {
  if (u.preda !== null && !u.preda.alive) dopoUccisione(u, u.preda);
  if (u.state !== 'walk') return;                // dopoUccisione puo' averlo fermato

  const nemico = nemicoPiuVicino(u);
  if (nemico === null || nemico === u.preda) return;
  if (u.preda === null && distanzaAPiedi(u, nemico) >= distanzaAPiedi(u, u.target)) return;

  u.preda = nemico;
  u.phase = 'nemico';
  u.slide = null;
  colorDots();
}
