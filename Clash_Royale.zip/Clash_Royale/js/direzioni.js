// ============================================================
//  LE 6 DIREZIONI: quale sprite usare in base all'angolo di marcia
// ============================================================

// Ogni personaggio puo' guardare in 6 direzioni SULLO SCHERMO, ognuna con la
// sua camminata e il suo attacco:
//
//        left     forward     right         <- verso l'alto
//                    |
//      backLeft     back    backRight       <- verso il basso
//
// Per ogni direzione: il nome della sezione nel JSON per camminare ('walk')
// e per attaccare ('attack'). 'riserva' = la direzione da usare se nel JSON
// questa manca (es. manca attackRight -> si usa attack, quello dritto).
const DIREZIONI = {
  forward:   { walk: 'walk',          attack: 'attack',          riserva: null },
  right:     { walk: 'walkRight',     attack: 'attackRight',     riserva: 'forward' },
  left:      { walk: 'walkLeft',      attack: 'attackLeft',      riserva: 'forward' },
  back:      { walk: 'walkBack',      attack: 'attackBack',      riserva: 'forward' },
  backRight: { walk: 'walkBackRight', attack: 'attackBackRight', riserva: 'back' },
  backLeft:  { walk: 'walkBackLeft',  attack: 'attackBackLeft',  riserva: 'back' }
};

// La sezione del JSON (cfg) per una direzione; tipo = 'walk' oppure 'attack'.
// Se manca, prova con la sua riserva, poi con la riserva della riserva...
function sezionePer(cfg, direzione, tipo) {
  let d = direzione;
  while (d !== null) {
    const sezione = cfg[DIREZIONI[d][tipo]];
    if (sezione && sezione.urls) return sezione;
    d = DIREZIONI[d].riserva;
  }
  return null;   // non c'e' nemmeno quella dritta
}

// L'angolo di una direzione (dx, dy), in gradi:
// 0 = verso l'alto, positivo = verso destra, negativo = verso sinistra, 180 = verso il basso
function angoloDi(dx, dy) {
  return Math.atan2(dx, -dy) * 180 / Math.PI;   // atan2 da' radianti: * 180 / PI li fa gradi
}

// Da un angolo alla direzione giusta tra le 6.
// Entro "tolleranza" gradi dal dritto (su o giu') conta come dritto.
function direzioneDaAngolo(angolo, tolleranza) {
  const quanto = Math.abs(angolo);   // quanto si gira, senza badare al lato
  const aDestra = angolo > 0;

  if (quanto <= tolleranza)       return 'forward';
  if (quanto >= 180 - tolleranza) return 'back';

  if (quanto <= 90) {                // diagonale verso l'alto
    if (aDestra) return 'right';
    return 'left';
  }
  if (aDestra) return 'backRight';   // diagonale verso il basso
  return 'backLeft';
}
