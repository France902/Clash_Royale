// ============================================================
//  ATTACCO: colpo, danno, ricarica
// ============================================================

// Puo' attaccare? (servono i frame d'attacco)
function puoAttaccare(u) {
  return u.attackSets.forward.length > 0;
}

// Il nemico vivo piu' vicino (in linea d'aria) tra quelli a portata.
// null = nessuno a portata. A parita' vince quello schierato prima.
function nemicoAPortata(u) {
  if (!puoAttaccare(u)) return null;
  let migliore = null;
  let distanzaMigliore = Infinity;
  for (const n of UNITA) {
    if (!n.alive || n.team === u.team) continue;
    const d = distanza(u.x, u.y, n.x, n.y);
    if (d <= u.range && d < distanzaMigliore) {
      distanzaMigliore = d;
      migliore = n;
    }
  }
  return migliore;
}

// Si gira verso il bersaglio (torre o nemico) e comincia a colpirlo
function iniziaAttacco(u, bersaglio) {
  u.bersaglio = bersaglio;
  u.angle = angoloDi(bersaglio.x - u.x, bersaglio.y - u.y);
  u.attackSet = direzioneDaAngolo(u.angle, u.turnAngle);   // l'attacco nella direzione giusta
  startSwing(u);
}

// Inizia un colpo: riparte dal primo frame di attacco
function startSwing(u) {
  u.state = 'attack';
  u.frame = 0;
  u.frameTime = 0;
  u.hitDone = false;                         // nuovo colpo: il danno e' ancora da fare
}

// Si ferma: fine del ciclo
function stopHere(u) {
  u.state = 'stop';
  u.frame = 0;
  u.frameTime = 0;
}

// Torna a camminare (dopo aver ucciso il nemico, o se e' scappato)
function riprendiCammino(u) {
  u.bersaglio = null;
  u.state = 'walk';
  u.frame = 0;
  u.frameTime = 0;
  u.slide = null;
}

// Il bersaglio e' un personaggio ed e' andato fuori portata?
function bersaglioLontano(u) {
  const b = u.bersaglio;
  if (!eUnita(b)) return false;   // le torri non scappano
  return distanza(u.x, u.y, b.x, b.y) > u.range + u.speed;
}

// Il bersaglio e' a zero (l'ha finito lui o un compagno): cosa fare adesso
function bersaglioFinito(u) {
  const b = u.bersaglio;
  if (eUnita(b))              dopoUccisione(u, b);   // nemico morto: riprende il percorso
  else if (b.type === 'king') stopHere(u);           // re distrutto: ha vinto, si ferma
  else                        cercaObiettivo(u);     // torre distrutta: punta l'obiettivo piu' vicino
}

// Fa passare un tick dell'animazione. Ritorna true quando il colpo e' finito.
function nextAttackFrame(u) {
  let durata = u.fastTicks;
  if (u.frame <= u.slowUntil) durata = u.slowTicks;   // i primi frame sono lenti

  u.frameTime++;
  if (u.frameTime < durata) return false;   // il frame deve durare ancora

  u.frameTime -= durata;
  u.frame++;
  if (u.frame < u.attackSets[u.attackSet].length) return false;

  u.frame = 0;                              // ultimo frame finito: colpo completato
  return true;
}

function updateAttack(u) {
  const finito = nextAttackFrame(u);
  const b = u.bersaglio;

  // Arrivato al frame del danno: il bersaglio perde vita (mai sotto zero), una volta sola per colpo
  if (!u.hitDone && (finito || u.frame >= u.damageIndex)) {
    b.hp = Math.max(b.hp - u.damage, 0);
    u.hitDone = true;
    if (eUnita(b) && b.hp === 0) {
      b.alive = false;                      // il nemico muore: sparisce subito
    }
  }

  if (!finito) return;                      // l'animazione del colpo non e' ancora finita

  // Animazione finita: il bersaglio e' a zero?
  if (b.hp === 0) {
    bersaglioFinito(u);
    return;
  }

  // Il nemico e' scappato? Torna a camminare
  if (bersaglioLontano(u)) {
    riprendiCammino(u);
    return;
  }

  u.state = 'reload';                       // altrimenti ricarica e poi colpisce ancora
  u.tickRicarica = 0;
  u.frameTime = 0;
}

function updateReload(u) {
  // Mentre ricarica, un compagno puo' aver finito il bersaglio
  if (u.bersaglio.hp === 0) {
    bersaglioFinito(u);
    return;
  }

  // Resta fermo sul primo frame d'attacco finche' la ricarica non e' finita
  u.tickRicarica++;
  if (u.tickRicarica < u.durataRicarica) return;

  if (bersaglioLontano(u)) riprendiCammino(u);
  else                     startSwing(u);
}
