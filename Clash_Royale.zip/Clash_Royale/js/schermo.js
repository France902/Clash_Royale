// ============================================================
//  SCHERMO: canvas, grandezza della mappa, da pixel della mappa a pixel dello schermo
// ============================================================

const canvas = document.getElementById('stage');
const ctx    = canvas.getContext('2d');
const info   = document.getElementById('info');

let mapImg  = null;
let barImgs = {};

let mapScale = 1;
let mapLeft  = 0;
let mapTop   = 0;
let arenaLeft = 0, arenaTop = 0, arenaW = 0, arenaH = 0;
let viewW = 0, viewH = 0;   // dimensioni della finestra in pixel CSS

// ---------- POSIZIONE E GRANDEZZA ----------
function layout() {
  // Schermi ad alta densita' e zoom del browser: il canvas ha piu' pixel
  // di quelli che occupa nella pagina (dpr = pixel reali per pixel CSS),
  // cosi' le immagini restano nitide invece di essere ingrandite dal browser.
  const dpr = window.devicePixelRatio || 1;
  viewW = window.innerWidth;
  viewH = window.innerHeight;
  canvas.width  = Math.round(viewW * dpr);
  canvas.height = Math.round(viewH * dpr);
  canvas.style.width  = viewW + 'px';
  canvas.style.height = viewH + 'px';
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);   // da qui in poi si disegna in pixel CSS
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';

  // Grandezza della mappa con il margine intorno
  const w = mapImg.width  + 2 * MARGIN;
  const h = mapImg.height + 2 * MARGIN;

  // Il fattore di ingrandimento e' il piu' grande che fa stare tutto nella finestra
  mapScale  = Math.min(viewW / w, viewH * MAP_HEIGHT / h);
  arenaW    = w * mapScale;
  arenaH    = h * mapScale;
  arenaLeft = (viewW - arenaW) / 2;   // centrata in orizzontale
  arenaTop  = (viewH - arenaH) / 2;   // e in verticale

  mapLeft = arenaLeft + MARGIN * mapScale;
  mapTop  = arenaTop  + MARGIN * mapScale;

  placeDots();   // anche i segnaposto vanno rimessi al loro posto
  posizionaBarraElisir();   // e anche la barra dell'elisir
}

// Da pixel della mappa a pixel dello schermo
function toScreenX(mx) { return mapLeft + mx * mapScale; }
function toScreenY(my) { return mapTop  + my * mapScale; }

// Dal punto dello schermo (pixel CSS) al punto della mappa: il contrario di toScreenX/Y
function toMapX(sx) { return (sx - mapLeft) / mapScale; }
function toMapY(sy) { return (sy - mapTop)  / mapScale; }
