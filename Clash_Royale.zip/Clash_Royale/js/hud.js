// ============================================================
//  HUD: avvisi, righe di informazione e pannelli dei giocatori
// ============================================================

// Messaggio breve in basso (es. "elisir insufficiente").
// Dura 2 secondi VERI (non tick: la simulazione a volte corre per recuperare).
let avviso = '';
let avvisoFino = 0;
function mostraAvviso(testo) {
  avviso = testo;
  avvisoFino = performance.now() + 2000;
}

// La scritta grande alla fine della partita ('' = non e' finita)
function messaggioFinePartita() {
  for (const t of TOWERS) {
    if (t.type !== 'king' || !distrutta(t)) continue;
    if (t.team === MIA_SQUADRA) return 'Hai perso!';
    return 'Hai vinto!';
  }
  return '';
}

// Una riga di testo per personaggio, in basso a destra
function descriviUnita(u) {
  let testo = u.nome;
  if (u.team === 'blue') testo += ' blu';
  else                   testo += ' rosso';
  testo += ' #' + u.numero;

  testo += ' | vita: ' + u.hp + ' | ' + u.state;
  if (u.slide !== null) {
    if (u.slide.side < 0) testo += ' (scivola a sinistra)';
    else                  testo += ' (scivola a destra)';
  }
  testo += ' | verso: ' + u.phase;

  const b = u.bersaglio;
  if (b !== null) {
    if (eUnita(b)) testo += ' | attacca il nemico: ';
    else           testo += ' | attacca la torre: ';
    testo += b.hp + '/' + b.maxHp;
  }

  // La direzione in cui guarda: quella dell'attacco se sta attaccando
  if (u.state === 'attack' || u.state === 'reload') testo += ' | ' + u.attackSet;
  else                                             testo += ' | ' + u.set;
  testo += ' | x: ' + Math.round(u.x) + ' y: ' + Math.round(u.y);
  return testo;
}

function writeInfo() {
  // Una riga per ogni personaggio vivo
  const righe = [];
  for (const u of UNITA) {
    if (u.alive) righe.push(descriviUnita(u));
  }
  if (righe.length === 0) righe.push('nessun personaggio in campo');
  let testo = righe.join('\n');

  // Chi sta giocando contro chi
  if (lobbyAttuale !== null) {
    const nomi = [];
    for (const g of lobbyAttuale.giocatori) {
      let nome = g.username;
      if (g.squadra === 'blue') nome += ' (blu)';
      else                      nome += ' (rosso)';
      if (g.squadra === MIA_SQUADRA) nome += ' = tu';
      else if (ultimaOraServer - g.visto > 5000) nome += ' - NON RISPONDE';
      nomi.push(nome);
    }
    testo += '\nlobby: ' + nomi.join(' contro ') + ' | tick: ' + tickSimulato;
  }

  if (partitaIniziata() && !partitaFinita() && hoElisir()) {
    testo += '\nclicca nella tua meta\' per schierare un Mini P.E.K.K.A';
  }
  // In debug: le principesse non ancora importate
  if (DEBUG) {
    if (immaginiSopra.red.principessa === null)  testo += '\nmanca la principessa rossa: importala con importa_sprite.php';
    if (immaginiSopra.blue.principessa === null) testo += '\nmanca la principessa blu: importala con importa_sprite.php';
    for (const url of proiettiliMancanti) testo += '\nproiettile non trovato: ' + url;
  }
  if (performance.now() < avvisoFino) testo += '\n' + avviso;
  info.textContent = testo;
}

// ---------- I PANNELLI DEI GIOCATORI ----------
// Il giocatore blu in basso a sinistra, il rosso in alto a sinistra.
// Si rifanno solo quando cambia qualcosa: rifarli ogni 150 ms farebbe
// "perdere" il clic sul pulsante Esci.
let ultimiPannelli = '';

function aggiornaPannelli() {
  // Chi gioca in ogni squadra (null = posto ancora libero)
  const perSquadra = { blue: null, red: null };
  for (const g of lobbyAttuale.giocatori) {
    perSquadra[g.squadra] = g;
  }

  const chiave = JSON.stringify([perSquadra.blue && perSquadra.blue.username,
                                 perSquadra.red  && perSquadra.red.username]);
  if (chiave === ultimiPannelli) return;   // niente di nuovo
  ultimiPannelli = chiave;

  riempiPannello('blue', perSquadra.blue);
  riempiPannello('red',  perSquadra.red);
}

// Riempie il pannello di una squadra. Si usano textContent e createElement
// (non innerHTML): un nome scritto dall'utente non puo' diventare codice HTML.
function riempiPannello(team, giocatore) {
  const pannello = document.getElementById('pannello-' + team);
  pannello.textContent = '';   // svuota

  if (giocatore === null) {
    const attesa = document.createElement('span');
    attesa.className = 'attesa';
    attesa.textContent = 'In attesa di un avversario...';
    pannello.appendChild(attesa);
    return;
  }

  let fazione = FAZIONI[giocatore.fazione];
  if (!fazione) fazione = { nome: 'Senza fazione', colore: '#888', icona: '⚔️' };
  pannello.style.setProperty('--colore', fazione.colore);

  const icona = document.createElement('span');
  icona.textContent = fazione.icona;

  const testi = document.createElement('div');
  const nome = document.createElement('div');
  nome.textContent = giocatore.username;
  if (giocatore.squadra === MIA_SQUADRA) nome.textContent += ' (tu)';
  const nomeFazione = document.createElement('div');
  nomeFazione.className = 'fazione';
  nomeFazione.textContent = fazione.nome;
  testi.appendChild(nome);
  testi.appendChild(nomeFazione);

  pannello.appendChild(icona);
  pannello.appendChild(testi);

  // Il pulsante Esci solo nel proprio pannello
  if (giocatore.squadra === MIA_SQUADRA) {
    const esci = document.createElement('a');
    esci.href = 'logout.php';
    esci.textContent = 'Esci';
    pannello.appendChild(esci);
  }
}
