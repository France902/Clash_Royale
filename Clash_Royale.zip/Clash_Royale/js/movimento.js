// ============================================================
//  IL MOTORE DI MOVIMENTO: passi, scivolate, camminata e tick di logica
// ============================================================

// Cosa fare quando arriva su un punto del percorso
function arrivatoAlPunto(u) {
  u.x = u.target.x;
  u.y = u.target.y;
  u.step++;
  u.slide = null;

  // Finita la prima parte (e' sul ponte): sceglie se inseguire un nemico o andare alla torre
  if (u.step >= u.path.length && u.phase === 'ponte') {
    planAfterBridge(u);
  }

  if (u.preda !== null) return;      // insegue un nemico: il punto da raggiungere e' lui

  if (u.step >= u.path.length) {
    // Era l'ultimo punto: e' davanti alla torre di quel quadrato
    const torre = u.target.torre;
    if (!puoAttaccare(u) || !torre)  stopHere(u);           // non sa attaccare
    else if (!distrutta(torre))      iniziaAttacco(u, torre);
    else                             cercaObiettivo(u);     // gia' caduta: cerca altro
  } else {
    u.target = u.path[u.step];       // altrimenti passa al punto successivo
  }
}

// Un tick di movimento: un passo verso la meta.
function moveStep(u) {
  // 1) Un nemico e' a portata? Si ferma e attacca il piu' vicino
  const vicino = nemicoAPortata(u);
  if (vicino !== null) {
    iniziaAttacco(u, vicino);
    return;
  }

  // 2) La preda e' morta, o un nemico si e' avvicinato piu' della meta?
  rivalutaObiettivo(u);
  if (u.state !== 'walk') return;    // puo' essersi fermato (niente piu' da attaccare)

  // 3) Dove sta andando: dal nemico (se lo insegue) o al punto del percorso.
  //    Se la meta e' sull'altra sponda del fiume, prima si passa dal ponte.
  let meta = u.target;
  if (u.preda !== null) meta = u.preda;
  const tappa = prossimaTappa(u, meta);

  const dx = tappa.x - u.x;
  const dy = tappa.y - u.y;
  const dist = lunghezza(dx, dy);

  // Se manca meno di un passo, si mette esattamente sul punto
  // (cosi' non "balla" avanti e indietro oltre il punto).
  if (dist <= u.speed) {
    if (tappa !== meta) {            // era solo una porta del ponte: si prosegue
      u.x = tappa.x;
      u.y = tappa.y;
      u.slide = null;
      return;
    }
    if (u.preda === null) {          // era il punto del percorso: arrivato
      arrivatoAlPunto(u);
      return;
    }
  }
  if (dist === 0) return;   // gia' sopra il nemico: niente da fare

  // Direzione dritta verso la meta: il vettore diviso la sua lunghezza
  // ha lunghezza 1, moltiplicato per la velocita' e' esattamente un passo.
  let vx = dx / dist;
  let vy = dy / dist;

  // 4) Il passo dritto finirebbe dentro una torre? Allora inizia a scivolare,
  //    dal lato in cui si trova rispetto al centro della torre.
  if (u.slide === null) {
    const box = torreCheContiene(u.x + vx * u.speed, u.y + vy * u.speed);
    if (box !== null) {
      let side;
      if (u.x < box.x)      side = -1;   // e' a sinistra della torre: scivola a sinistra
      else if (u.x > box.x) side = 1;    // e' a destra: scivola a destra
      else if (dx < 0)      side = -1;   // esattamente al centro: segue la direzione della meta
      else                  side = 1;
      u.slide = { box: box, side: side };
    }
  }

  // 5) Se la linea dritta fino alla tappa non tocca piu' la torre (o la torre
  //    e' stata distrutta), smette di scivolare
  if (u.slide !== null) {
    if (distrutta(u.slide.box.torre) || !segmentHitsBox(u.x, u.y, tappa.x, tappa.y, u.slide.box)) {
      u.slide = null;
    }
  }

  // 6) Scivolando: tanto movimento orizzontale, poco verticale (obliquo).
  //    Se anche cosi' entrerebbe nella torre, resta solo l'orizzontale.
  if (u.slide !== null) {
    vx = u.slide.side;
    vy = Math.sign(dy) * u.slideSlope;   // Math.sign: -1 se va su, +1 se va giu'
    const len = lunghezza(vx, vy);
    vx = vx / len;
    vy = vy / len;
    if (insideBox(u.x + vx * u.speed, u.y + vy * u.speed, u.slide.box)) {
      vx = u.slide.side;
      vy = 0;
    }
  }

  setDirection(u, vx, vy);   // la camminata segue la direzione vera (anche quando scivola)
  u.x += vx * u.speed;
  u.y += vy * u.speed;
}

// ---------- CAMMINATA ----------

// Cambia camminata (una delle 6 direzioni) senza far saltare le gambe:
// le camminate possono avere un numero diverso di frame, quindi si tiene
// la STESSA "fase" del passo (es. a meta' passo resta a meta' passo).
function changeSet(u, nome) {
  if (nome === u.set) return;
  const fase = u.frame / u.walkSets[u.set].length;   // 0 = inizio passo, 1 = fine
  const nuoviFrame = u.walkSets[nome].length;
  u.set   = nome;
  u.frame = Math.min(Math.floor(fase * nuoviFrame), nuoviFrame - 1);
  u.frameTime = 0;
}

// Dal vettore di marcia (dx, dy) ricava l'angolo e sceglie la camminata.
function setDirection(u, dx, dy) {
  u.angle = angoloDi(dx, dy);
  changeSet(u, direzioneDaAngolo(u.angle, u.turnAngle));
}

// Un tick di animazione: le gambe avanzano
function animateWalk(u) {
  const frames = u.walkSets[u.set];
  const durata = oppure(u.sezioniCamminata[u.set].ticksPerFrame, 3);   // ogni camminata ha la sua velocita'
  u.frameTime++;
  if (u.frameTime < durata) return;
  u.frameTime -= durata;
  u.frame = (u.frame + 1) % frames.length;   // % = dopo l'ultimo frame torna al primo
}

// Un tick di logica per un personaggio: fa la cosa giusta in base allo stato
function updateUnita(u) {
  if (!u.alive) return;                     // i morti non fanno niente

  if (u.state === 'walk') {
    moveStep(u);
    if (u.state === 'walk') animateWalk(u); // potrebbe aver appena smesso di camminare
  } else if (u.state === 'attack') {
    updateAttack(u);
  } else if (u.state === 'reload') {
    updateReload(u);
  }
}

// Un tick di logica per tutti: prima i personaggi, nell'ordine in cui sono
// stati schierati, poi le torri e i proiettili (js/difese.js).
// Partita finita (un re e' caduto): tutti si fermano dove sono.
function update() {
  const finita = partitaFinita();
  for (const u of UNITA) {
    if (finita) {
      if (u.alive && u.state !== 'stop') stopHere(u);
    } else {
      updateUnita(u);
    }
  }
  if (finita) {
    proiettili = [];               // niente piu' colpi in volo
    return;
  }
  updateDifese();
}
