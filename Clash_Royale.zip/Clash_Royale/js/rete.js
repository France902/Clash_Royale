// ============================================================
//  SINCRONIZZAZIONE CON IL SERVER: orologio, stato della partita, eventi, simulazione
// ============================================================

// ---------- L'OROLOGIO DEL SERVER ----------
// Gli orologi dei due computer non segnano la stessa ora: si usa quella del
// server. Ad ogni risposta si stima la differenza tra il nostro orologio e il
// suo. La risposta ci mette un po' ad arrivare: si suppone che l'andata e il
// ritorno durino uguale, quindi l'ora del server "adesso" e' quella che ci ha
// mandato piu' meta' del viaggio. Si tiene la stima del viaggio piu' veloce
// (quella con meno incertezza).
let differenzaOrologio = 0;      // ora del server - ora nostra (millisecondi)
let viaggioMigliore = Infinity;  // il viaggio piu' veloce visto finora
let ultimaOraServer = 0;         // l'ultima ora ricevuta dal server

function oraServer() {
  return Date.now() + differenzaOrologio;
}

// ---------- LO STATO DELLA PARTITA ----------
let lobbyAttuale  = null;   // la lobby ricevuta dal server (null = non ancora arrivata)
let inizioPartita = null;   // ora (del server) in cui e' partita la partita
let eventi        = [];     // gli schieramenti: { squadra, carta, costo, x, y, clic, tick, cid }
let tickSimulato  = 0;      // fin dove e' arrivata la nostra simulazione
let inAttesa      = [];     // i miei clic non ancora confermati: { x, y, carta, costo, cid }

function partitaIniziata() {
  return inizioPartita !== null && oraServer() >= inizioPartita;
}

// Toglie dai clic in attesa quello con questo numero di ricevuta (se c'e')
function togliAttesa(cid) {
  for (let i = 0; i < inAttesa.length; i++) {
    if (inAttesa[i].cid === cid) {
      inAttesa.splice(i, 1);
      return;
    }
  }
}

// Il testo grande al centro prima della partita ('' = niente)
function messaggioPrimaDellaPartita() {
  if (lobbyAttuale === null) return 'Connessione...';
  if (inizioPartita === null) return 'In attesa di un avversario...';
  const mancano = inizioPartita - oraServer();
  if (mancano > 0) return 'Si parte tra ' + Math.ceil(mancano / 1000) + '...';
  return '';
}

// ---------- CHIEDERE LO STATO AL SERVER ----------
// Come nel test del movimento sincronizzato: si chiede continuamente al server
// lo stato. Qui ogni 150 ms basta, perche' gli schieramenti valgono 1 secondo
// dopo il clic: c'e' tutto il tempo di riceverli.
let richiestaInCorso = false;

async function chiediStato() {
  if (richiestaInCorso) return;   // una richiesta alla volta
  richiestaInCorso = true;
  try {
    const partenza = Date.now();
    const risposta = await fetch('?azione=stato');
    const dati = await risposta.json();
    const arrivo = Date.now();

    // Aggiorna la stima dell'orologio del server
    const viaggio = arrivo - partenza;
    if (viaggio <= viaggioMigliore) {
      viaggioMigliore = viaggio;
      differenzaOrologio = (dati.ora + viaggio / 2) - arrivo;
    }
    ultimaOraServer = dati.ora;

    // La lobby non c'e' piu' (l'avversario e' uscito): si ricarica la pagina
    // e si entra in una lobby nuova, in attesa di un altro avversario
    if (dati.lobby === null) {
      mostraAvviso('L\'avversario e\' uscito: nuova lobby...');
      setTimeout(function () { location.reload(); }, 1500);
      return;
    }

    lobbyAttuale  = dati.lobby;
    inizioPartita = dati.lobby.inizio;
    aggiornaPannelli();
    riceviEventi(dati.lobby.eventi);
  } catch (err) {
    mostraAvviso('Connessione al server persa, riprovo...');
  }
  richiestaInCorso = false;
}

// Arrivano gli schieramenti dal server. Il server li aggiunge solo in fondo,
// quindi quelli nuovi sono quelli dopo i vecchi.
function riceviEventi(nuovi) {
  if (nuovi.length === eventi.length) return;   // niente di nuovo

  // Uno schieramento nuovo doveva gia' succedere (e' arrivato in ritardo)?
  // Allora la simulazione e' sbagliata: si rifa' tutto da capo, dal tick 0.
  let daRifare = false;
  for (let i = eventi.length; i < nuovi.length; i++) {
    if (nuovi[i].tick < tickSimulato) daRifare = true;
    if (nuovi[i].squadra === MIA_SQUADRA) togliAttesa(nuovi[i].cid);   // il mio e' arrivato
  }
  eventi = nuovi;
  if (daRifare) {
    resetArena();
    tickSimulato = 0;
  }
}

// ---------- NUOVA PARTITA ----------
// Torri a vita piena e campo vuoto (si usa anche per rifare la simulazione da capo)
function resetArena() {
  for (const t of TOWERS) {
    t.hp = t.maxHp;
  }
  UNITA.length = 0;          // via tutti i personaggi...
  rimuoviPartenze();         // ...e i loro segnaposto di partenza
  preparaDifese();           // torri pronte, nessun proiettile in volo
  colorDots();
  placeDots();
}

// ---------- LA SIMULAZIONE ----------
// Porta la simulazione fino al tick "obiettivo". A ogni tick: prima gli
// schieramenti di quel tick (nell'ordine del server), poi un passo di
// logica. Stessi eventi negli stessi tick = stesso risultato.
function avanzaFinoA(obiettivo) {
  while (tickSimulato < obiettivo) {
    for (const e of eventi) {
      if (e.tick === tickSimulato) {
        schiera(e.squadra, e.x, e.y, e.carta);
        colorDots();
        placeDots();
      }
    }
    update();
    tickSimulato++;
  }
}
