// ============================================================
//  I PERSONAGGI: creazione, schieramento in campo, chi e' nemico di chi
// ============================================================

// ---------- I PERSONAGGI IN CAMPO ----------
// Tutti i personaggi schierati nella partita, nell'ordine in cui sono comparsi.
// Ogni giocatore ne puo' schierare quanti ne vuole, delle carte del suo mazzo (se ha l'elisir).
// I morti restano nella lista (alive = false) ma non fanno piu' niente.
// L'ORDINE CONTA: a ogni tick si muovono in quest'ordine, che e' lo stesso su
// tutti e due gli schermi (quello degli schieramenti sul server).
const UNITA = [];

// Le immagini di ogni carta di ogni squadra, per ognuna delle 6 DIREZIONI:
// SPRITE[squadra][carta] = { walk: {...}, attack: {...} }. Le carica avvio.js
// una volta sola e le usano tutti i personaggi di quella carta.
const SPRITE = { blue: {}, red: {} };

// Crea un personaggio della squadra data ('blue' o 'red') dal JSON della sua carta.
// Le posizioni sono in PIXEL DELLA MAPPA (come le torri), cosi' non
// cambiano quando cambia la finestra.
function creaUnita(team, carta) {
  const cfg = PERSONAGGI[team][carta];
  const movimento = oppure(cfg.movement, {});
  const attacco   = oppure(cfg.attack, {});

  const u = {
    unita: true,                       // e' un personaggio (le torri non hanno questo campo)
    team: team,
    carta: carta,                      // quale carta e' (es. 'knight')
    nome: cfg.name,
    numero: 0,                         // il suo numero nella squadra: 1, 2, 3... (per le scritte)

    // --- impostazioni dal JSON ---
    speed:      oppure(movimento.speed, 2),        // pixel DELLA MAPPA per tick
    turnAngle:  oppure(movimento.turnAngle, 15),   // oltre questi gradi dal dritto usa la diagonale
    slideSlope: oppure(movimento.slideSlope, 0.25),// scivolando: passi in verticale per ogni passo in orizzontale
    scale:      oppure(cfg.scale, 1),              // grandezza rispetto ai PNG (poi moltiplicata per la mappa)
    anchor:     oppure(cfg.anchor, { x: 0.5, y: 0.5 }), // punto dello sprite che sta sulla posizione (0-1)
    maxHp:      oppure(cfg.hp, 0),                 // vita piena (0 = niente barra)
    damage:     oppure(attacco.damage, 0),         // vita tolta da ogni colpo
    range:      oppure(attacco.range, 0),          // da quanto lontano colpisce un personaggio
    slowTicks:  oppure(attacco.slowTicksPerFrame, 3),                                  // primi frame dell'attacco
    fastTicks:  oppure(attacco.fastTicksPerFrame, oppure(attacco.slowTicksPerFrame, 3)), // frame successivi
    slowUntil:  oppure(attacco.slowUntilFrame, 0), // ultimo frame "lento"

    // --- animazioni: per ogni direzione la sezione del JSON e le immagini (della squadra) ---
    sezioniCamminata: {},
    sezioniAttacco: {},
    walkSets: SPRITE[team][carta].walk,
    attackSets: SPRITE[team][carta].attack,

    // --- il percorso ---
    assi: ASSI[team],                  // i suoi 6 assi
    quadratiTorre: QUADRATI_TORRE[team], // i quadrati da cui attacca le torri avversarie
    inizio: { x: 0, y: 0 },            // da dove e' partito
    axis: null,                        // l'asse scelto
    path: [],                          // i punti da toccare, in ordine
    step: 0,                           // a quale punto del percorso sta andando
    target: null,                      // il punto verso cui sta camminando adesso
    preda: null,                       // il nemico che sta inseguendo (null = nessuno)

    // --- lo stato ---
    x: 0, y: 0,                        // dove si trova
    hp: 0,                             // vita attuale
    alive: false,                      // e' vivo? (false = morto)
    state: 'walk',                     // 'walk' = cammina, 'attack' = colpisce, 'reload' = ricarica,
                                       // 'stop' = fermo (partita finita o niente attacco)
    bersaglio: null,                   // chi sta attaccando: una torre o un nemico
    tickRicarica: 0,                   // tick passati in ricarica
    hitDone: false,                    // in questo colpo il danno e' gia' stato fatto?
    slide: null,                       // se sta scivolando: { box: la torre, side: -1 sinistra / +1 destra }
    phase: 'ponte',                    // dove sta andando: 'ponte', 'nemico' o 'torre'
    set: 'forward',                    // quale camminata usa: una delle 6 DIREZIONI
    attackSet: 'forward',              // quale attacco usa: una delle 6 DIREZIONI
    angle: 0,                          // angolo di marcia (gradi)
    frame: 0,                          // quale immagine mostrare
    frameTime: 0,                      // da quanti tick si vede il frame corrente
    cima: 0                            // y sullo schermo della cima dello sprite (per la barra)
  };

  for (const d in DIREZIONI) {
    u.sezioniCamminata[d] = sezionePer(cfg, d, 'walk');
    u.sezioniAttacco[d]   = sezionePer(cfg, d, 'attack');
  }

  // ---- I tempi dell'attacco ----
  // Un colpo = l'animazione d'attacco (primi frame lenti, poi veloci).
  // Tra un colpo e l'altro c'e' la ricarica, ferma sul primo frame.
  // I tempi si leggono dalla sezione "attack" e valgono per tutte le direzioni.
  let nAttacco = 0;
  if (u.sezioniAttacco.forward !== null) nAttacco = u.sezioniAttacco.forward.urls.length;

  // Il frame in cui il colpo ARRIVA davvero. "damageFrame" nel JSON e' il
  // NUMERO DEL PNG; la lista parte da firstFrame, quindi si sottrae.
  // Se manca, il danno arriva sull'ultimo frame.
  u.damageIndex = nAttacco - 1;
  if (!manca(attacco.damageFrame)) {
    u.damageIndex = attacco.damageFrame - oppure(attacco.firstFrame, 0);
  }

  // Un colpo ogni hitSpeed secondi: la ricarica e' quello che resta dopo l'animazione
  const tickTraColpi = oppure(attacco.hitSpeed, 1) * TICK_RATE;
  const nLenti       = Math.min(u.slowUntil + 1, nAttacco);
  const durataColpo  = nLenti * u.slowTicks + (nAttacco - nLenti) * u.fastTicks;
  u.durataRicarica   = Math.max(tickTraColpi - durataColpo, 0);

  return u;
}

// E' un personaggio? (altrimenti e' una torre)
function eUnita(cosa) {
  return cosa.unita === true;
}

// Quanti personaggi di una squadra sono stati schierati finora
function quantiDellaSquadra(team) {
  let n = 0;
  for (const u of UNITA) {
    if (u.team === team) n++;
  }
  return n;
}

// Crea un nuovo personaggio della squadra (dalla carta data), lo mette in
// campo nel punto (x, y) della mappa e gli prepara il percorso
function schiera(team, x, y, carta) {
  const u = creaUnita(team, carta);
  u.numero = quantiDellaSquadra(team) + 1;
  UNITA.push(u);

  u.x = x;
  u.y = y;
  u.inizio.x = u.x;
  u.inizio.y = u.y;
  u.hp = u.maxHp;
  u.alive = true;

  // L'asse col quadrato d'ingresso piu' vicino, tra tutti e 6
  u.axis = u.assi[0];
  for (const asse of u.assi) {
    const d1 = distanza(asse.entry.x, asse.entry.y, u.x, u.y);
    const d2 = distanza(u.axis.entry.x, u.axis.entry.y, u.x, u.y);
    if (d1 < d2) u.axis = asse;
  }

  // Prima parte del percorso: quadrato d'ingresso -> cerchio sul ponte.
  // Il resto (nemico o torre) si decide quando arriva sul ponte.
  u.path   = [u.axis.entry, u.axis.bridge];
  u.phase  = 'ponte';
  u.step   = 0;
  u.target = u.path[0];

  // Il suo segnaposto di partenza (si vede solo in debug, finche' e' vivo)
  aggiungiSegnaposto(u.inizio, DOT_SIZE, 'partenza', team, null).unita = u;
  return u;
}
