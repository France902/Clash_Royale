// ============================================================
//  TORRI E QUADRATI DI ATTACCO
// ============================================================

// Una torre e' distrutta quando la sua vita e' a zero
function distrutta(t) {
  return t.hp <= 0;
}

// Ogni blocco solido "sa" a quale torre appartiene (sono nello stesso ordine)
for (let i = 0; i < SOLIDS.length; i++) {
  SOLIDS[i].torre = TOWERS[i];
}

// Per ogni squadra: i quadrati da cui attacca le torri avversarie.
// Ogni quadrato "sa" quale torre si attacca da li': quadrato.torre
const QUADRATI_TORRE = { blue: [], red: [] };

for (const team of ['blue', 'red']) {
  // Le torri avversarie, divise tra principesse e re
  const principesse = [];
  let re = null;
  for (const t of TOWERS) {
    if (t.team === team) continue;          // le proprie torri non si attaccano
    if (t.type === 'king') re = t;
    else                   principesse.push(t);
  }

  // I quadrati delle corsie: davanti alla torre principessa piu' vicina
  for (const asse of ASSI[team]) {
    const q = asse.tower;
    q.torre = piuVicino(principesse, q.x, q.y);
    QUADRATI_TORRE[team].push(q);
  }

  // I quadrati intorno al re. "Verso il centro" e' in giu' per il re rosso
  // (che sta in alto) e in su per il re blu (che sta in basso).
  let verso = 1;
  if (re.team === 'blue') verso = -1;
  for (const spostamento of QUADRATI_RE) {
    QUADRATI_TORRE[team].push({
      x: re.x + spostamento[0],
      y: re.y + verso * spostamento[1],
      torre: re
    });
  }
}

// La partita e' finita quando un re e' distrutto: da li' nessuno si muove piu'
function partitaFinita() {
  for (const t of TOWERS) {
    if (t.type === 'king' && distrutta(t)) return true;
  }
  return false;
}
