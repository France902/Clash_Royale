// ============================================================
//  DIFESE: le torri sparano ai personaggi nemici
//
//  TORRE PRINCIPESSA: quando un nemico entra nel suo raggio, la principessa
//  ripete l'animazione d'attacco finche' c'e' un nemico a portata. Al frame
//  di sparo parte una freccia verso il punto in cui il nemico era IN QUEL
//  MOMENTO. Quando la freccia arriva, il nemico perde vita, che lo prenda o
//  no (niente controllo delle collisioni).
//  TORRE DEL RE: stessa cosa, ma senza animazione: la palla parte subito.
//
//  E' tutto dentro la simulazione e si conta in tick, come per i
//  personaggi: cosi' tutti e due gli schermi vedono gli stessi colpi.
//
//  I PARAMETRI, nella sezione "tower" di characters/princess.json e king.json:
//    range         raggio, in pixel della mappa, misurato dal centro della torre
//    damage        vita tolta da ogni colpo
//    hitSpeed      secondi tra un colpo e l'altro
//    ticksPerFrame quanti tick dura ogni frame dell'animazione (principessa)
//    shootFrame    il NUMERO DEL PNG in cui parte la freccia (4 = il quinto: 000, 001... 004)
//    turnAngle     entro quanti gradi dal dritto usa la posa "di fronte" (principessa)
//    projectile    image      il PNG del proiettile ({team} = red o blue)
//                  speed      pixel della mappa per tick
//                  size       quanto e' lungo il disegno sulla mappa, in pixel della mappa
//                  imageAngle dove punta il PNG: 0 = in su, 90 = a destra, 180 = in giu'
// ============================================================

// I proiettili in volo
let proiettili = [];

// Le impostazioni di ogni torre, lette una volta sola dai JSON (con dei valori
// di riserva se un parametro manca)
for (const t of TOWERS) {
  const cfg = DIFESE[t.team][t.type];
  let rangeRiserva = 300;
  if (t.type === 'king') rangeRiserva = 400;
  t.arma = {
    range:        oppure(cfg.range, rangeRiserva),
    damage:       oppure(cfg.damage, 100),
    ricarica:     Math.round(oppure(cfg.hitSpeed, 1) * TICK_RATE),   // tick tra un colpo e l'altro
    tickPerFrame: oppure(cfg.ticksPerFrame, 3),
    turnAngle:    oppure(cfg.turnAngle, 20),
    // il frame in cui parte la freccia, come posto nella lista (che parte da firstFrame)
    sparoIndex:   oppure(cfg.shootFrame, 4) - oppure(cfg.firstFrame, 0),
    velocita:     oppure(oppure(cfg.projectile, {}).speed, 10),
    sezioni:      cfg.sezioni   // le animazioni della principessa (liste di PNG); il re non ne ha
  };
}

// Torri pronte, nessun proiettile in volo (inizio partita, o simulazione rifatta da capo)
function preparaDifese() {
  proiettili = [];
  for (const t of TOWERS) {
    t.difesa = {
      bersaglio: null,       // il nemico a cui spara (null = nessuno a portata)
      stato: 'ferma',        // 'ferma' oppure 'attacco' (animazione in corso)
      direzione: 'attack',   // la posa: 'attack' (di fronte), 'attackRight', 'attackLeft'
      frame: 0,              // il frame dell'animazione
      frameTime: 0,          // da quanti tick si vede il frame
      ricarica: 0,           // tick che mancano prima di poter cominciare un altro colpo
      sparato: false         // in questo colpo la freccia e' gia' partita?
    };
  }
}
preparaDifese();

// La principessa ha le animazioni d'attacco? (il re no: spara e basta)
function haAnimazione(t) {
  const attacco = t.arma.sezioni.attack;
  return !manca(attacco) && attacco.length > 0;
}

// E' un nemico della torre, vivo e dentro il suo raggio?
function aPortataTorre(t, u) {
  return u.alive && u.team !== t.team && distanza(t.x, t.y, u.x, u.y) <= t.arma.range;
}

// Il bersaglio della torre: quello di prima, finche' resta a portata;
// altrimenti il nemico piu' vicino (a parita', quello schierato prima)
function scegliBersaglioTorre(t) {
  const prima = t.difesa.bersaglio;
  if (prima !== null && aPortataTorre(t, prima)) return prima;

  let migliore = null;
  let distanzaMigliore = Infinity;
  for (const u of UNITA) {
    if (!aPortataTorre(t, u)) continue;
    const d = distanza(t.x, t.y, u.x, u.y);
    if (d < distanzaMigliore) {
      distanzaMigliore = d;
      migliore = u;
    }
  }
  return migliore;
}

// Da dove parte il colpo: dalla principessa o dal cannone (inc/config.php, $sopraLeTorri)
function puntoDiSparo(t) {
  let pos = SOPRA_TORRI.pezzi.principessa.posizione[t.team];
  if (t.type === 'king') pos = SOPRA_TORRI.pezzi.cannone.posizione[t.team];
  return { x: t.x + pos[0], y: t.y + pos[1] };
}

// Spara: il proiettile vola fino al punto in cui il bersaglio e' ADESSO.
// Il viaggio dura un numero intero di tick, deciso alla partenza.
function spara(t, u) {
  const da = puntoDiSparo(t);
  const a  = { x: u.x, y: u.y };
  const viaggio = Math.max(1, Math.ceil(distanza(da.x, da.y, a.x, a.y) / t.arma.velocita));
  proiettili.push({
    torre: t,
    da: da,
    a: a,
    bersaglio: u,
    danno: t.arma.damage,
    tick: 0,                                   // tick passati in volo
    viaggio: viaggio,                          // tick per arrivare
    angolo: angoloDi(a.x - da.x, a.y - da.y)   // la direzione del volo (0 = in su)
  });
}

// La posa della principessa verso il nemico. "Di fronte" e' verso l'altra
// meta' del campo: in su per il blu, in giu' per il rosso. Fuori dalla
// tolleranza: a destra o a sinistra, come sullo schermo.
function direzionePrincipessa(t, u) {
  let avanti = u.y - t.y;
  if (t.team === 'red') avanti = -avanti;      // per il rosso "avanti" e' in giu'
  const angolo = angoloDi(u.x - t.x, avanti);
  if (Math.abs(angolo) <= t.arma.turnAngle) return 'attack';
  if (u.x > t.x) return 'attackRight';
  return 'attackLeft';
}

// I frame della posa in uso (se la posa laterale manca, quella di fronte)
function framesTorre(t) {
  const frames = t.arma.sezioni[t.difesa.direzione];
  if (manca(frames)) return t.arma.sezioni.attack;
  return frames;
}

// Un tick di una torre
function updateTorre(t) {
  if (distrutta(t)) return;
  const d = t.difesa;
  d.bersaglio = scegliBersaglioTorre(t);
  if (d.ricarica > 0) d.ricarica--;

  // Re: spara appena la ricarica e' finita, senza animazione
  if (!haAnimazione(t)) {
    if (d.bersaglio !== null && d.ricarica === 0) {
      spara(t, d.bersaglio);
      d.ricarica = t.arma.ricarica;
    }
    return;
  }

  // Principessa ferma: se c'e' un nemico e la ricarica e' finita, comincia un colpo
  if (d.stato === 'ferma') {
    if (d.bersaglio === null || d.ricarica > 0) return;
    d.stato = 'attacco';
    d.frame = 0;
    d.frameTime = 0;
    d.sparato = false;
    d.ricarica = t.arma.ricarica;   // il prossimo colpo non prima di hitSpeed secondi
  }

  // Si gira verso il nemico (se c'e' ancora)
  if (d.bersaglio !== null) d.direzione = direzionePrincipessa(t, d.bersaglio);
  const frames = framesTorre(t);
  if (d.frame >= frames.length) d.frame = frames.length - 1;   // la posa nuova ha meno frame

  // Al frame di sparo parte la freccia (se c'e' ancora qualcuno a cui tirarla)
  if (!d.sparato && d.frame >= Math.min(t.arma.sparoIndex, frames.length - 1)) {
    d.sparato = true;
    if (d.bersaglio !== null) spara(t, d.bersaglio);
  }

  // L'animazione va avanti; finita, si torna "ferma" e, se c'e' ancora un
  // nemico, il colpo dopo parte appena finisce la ricarica
  d.frameTime++;
  if (d.frameTime < t.arma.tickPerFrame) return;
  d.frameTime = 0;
  d.frame++;
  if (d.frame >= frames.length) {
    d.stato = 'ferma';
    d.frame = 0;
  }
}

// Un tick dei proiettili: quelli arrivati fanno danno al loro bersaglio
function updateProiettili() {
  const inVolo = [];
  for (const p of proiettili) {
    p.tick++;
    if (p.tick < p.viaggio) {
      inVolo.push(p);
      continue;
    }
    const u = p.bersaglio;
    if (!u.alive) continue;                 // e' gia' morto: niente danno
    u.hp = Math.max(u.hp - p.danno, 0);
    if (u.hp === 0) {
      u.alive = false;                      // muore: sparisce subito
      colorDots();
    }
  }
  proiettili = inVolo;
}

// Un tick di tutte le difese: prima le torri (nell'ordine di TOWERS), poi i proiettili
function updateDifese() {
  for (const t of TOWERS) updateTorre(t);
  updateProiettili();
}
