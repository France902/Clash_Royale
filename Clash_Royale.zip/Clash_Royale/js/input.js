// ============================================================
//  INPUT DEL GIOCATORE: il clic che schiera un Mini P.E.K.K.A
// ============================================================

// Il punto (y) e' nella meta' della mia squadra?
function nellaMiaMeta(y) {
  if (MIA_SQUADRA === 'blue') return y >= LIMITI.blue;
  return y <= LIMITI.red;
}

// Il punto e' sopra una torre (anche distrutta)? Come il controllo del server,
// che non sa quali torri sono cadute: sulle rovine non si schiera.
function sopraUnaTorre(x, y) {
  for (const b of SOLIDS) {
    if (insideBox(x, y, b)) return true;
  }
  return false;
}

// Ogni schieramento ha un "numero di ricevuta" (cid): il server lo rimette
// nell'evento, cosi' quando l'evento arriva si sa quale clic in attesa togliere
let contaClic = 0;

// Il giocatore ha cliccato: chiede al server di schierare un Mini P.E.K.K.A.
// Si puo' cliccare di nuovo subito (anche prima della risposta), se c'e'
// abbastanza elisir. Il personaggio NON compare subito: compare quando la
// simulazione arriva al tick deciso dal server, uguale per tutti e due.
async function clicGiocatore(evento) {
  const x = toMapX(evento.clientX);
  const y = toMapY(evento.clientY);

  // Primi controlli qui (il server li rifa' comunque)
  const dentroMappa = x >= 0 && x <= mapImg.width && y >= 0 && y <= mapImg.height;
  if (!dentroMappa) return;
  if (!partitaIniziata()) {
    mostraAvviso('La partita non e\' ancora iniziata');
    return;
  }
  if (partitaFinita()) {
    mostraAvviso('La partita e\' finita');
    return;
  }
  if (!nellaMiaMeta(y)) {
    mostraAvviso('Puoi schierarlo solo nella tua meta\' del campo');
    return;
  }
  if (sopraUnaTorre(x, y)) {
    mostraAvviso('Non puoi schierarlo sopra una torre');
    return;
  }
  if (!hoElisir()) {
    mostraAvviso('Elisir insufficiente');
    return;
  }

  // Finche' il server non lo conferma: un cerchio li' e l'elisir gia' pagato
  const attesa = { x: x, y: y, cid: Date.now() + '-' + contaClic };
  contaClic++;
  inAttesa.push(attesa);

  // Invio al server (POST, come un form)
  try {
    const dati = new FormData();
    dati.append('x', x);
    dati.append('y', y);
    dati.append('cid', attesa.cid);
    const risposta = await fetch('?azione=schiera', { method: 'POST', body: dati });
    const esito = await risposta.json();
    if (!esito.ok) {
      mostraAvviso(esito.errore);
      togliAttesa(attesa.cid);     // rifiutato: l'elisir torna indietro
    }
  } catch (err) {
    mostraAvviso('Connessione al server persa');
    togliAttesa(attesa.cid);
  }
  chiediStato();   // si fa dare subito l'evento con il suo tick
}
