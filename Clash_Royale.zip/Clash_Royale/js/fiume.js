// ============================================================
//  IL FIUME E I PONTI: come si arriva a una meta senza passare dall'acqua
// ============================================================

// Il fiume divide la mappa in due sponde: NORD (rossa, in alto) e SUD (blu).
// Si passa solo dai ponti. Ogni ponte ha due "porte": una sulla sponda nord
// e una sulla sponda sud, alla x del centro del ponte.
const Y_FIUME = (PONTI[0].nord + PONTI[0].sud) / 2;   // la linea a meta' del fiume

// Il punto (y) e' sulla sponda nord?
function aNord(y) {
  return y < Y_FIUME;
}

// Il punto (x, y) e' sopra il ponte p?
function sulPonte(x, y, p) {
  return Math.abs(x - p.x) <= MEZZO_PONTE && y >= p.nord && y <= p.sud;
}

// La PORTA di un ponte dalla parte della sponda di (y): il punto in cui si
// sale o si scende dal ponte. La sua x e' quella di chi ci passa (xVicina),
// tenuta dentro la larghezza del ponte: cosi' chi segue una corsia va dritto.
function porta(p, y, xVicina) {
  const x = Math.min(Math.max(xVicina, p.x - MARGINE_PORTE), p.x + MARGINE_PORTE);
  if (aNord(y)) return { x: x, y: p.nord };
  return { x: x, y: p.sud };
}

// Il ponte su cui si trova (x, y), oppure null
function ponteSotto(x, y) {
  for (const p of PONTI) {
    if (sulPonte(x, y, p)) return p;
  }
  return null;
}

// Il punto (x, y) e' esattamente sul punto "q"?
function sopra(x, y, q) {
  return distanza(x, y, q.x, q.y) < 0.01;
}

// Da (x, y), il prossimo punto verso cui camminare per arrivare alla meta
// SENZA mai entrare nel fiume fuori dai ponti:
//   1) sono su un ponte: se la meta e' sullo stesso ponte vado dritto,
//      altrimenti prima scendo dalla porta dalla parte della meta
//   2) la meta e' su un ponte: prima vado alla porta di quel ponte dalla mia parte
//   3) stessa sponda: dritto
//   4) sponde diverse: vado al ponte con il giro piu' corto
function tappaDa(x, y, meta) {
  const pioSotto = ponteSotto(x, y);
  const ponteMeta = ponteSotto(meta.x, meta.y);

  // 1) Sono sul ponte
  if (pioSotto !== null) {
    if (pioSotto === ponteMeta) return meta;
    const discesa = porta(pioSotto, meta.y, x);
    if (!sopra(x, y, discesa)) return discesa;
    // gia' sulla porta: e' come essere sulla sponda, si continua sotto
  }

  // 2) La meta e' su un ponte (es. l'avversario lo sta attraversando)
  if (ponteMeta !== null) {
    const salita = porta(ponteMeta, y, meta.x);
    if (!sopra(x, y, salita)) return salita;
    return meta;
  }

  // 3) Stessa sponda
  if (aNord(y) === aNord(meta.y)) return meta;

  // 4) Sponde diverse: il ponte con il giro piu' corto
  //    (fino alla porta, attraverso il ponte, dall'altra porta alla meta)
  let migliore = null;
  let giroMigliore = Infinity;
  for (const p of PONTI) {
    const entrata = porta(p, y, x);
    const uscita  = porta(p, meta.y, x);
    const giro = distanza(x, y, entrata.x, entrata.y)
               + distanza(entrata.x, entrata.y, uscita.x, uscita.y)
               + distanza(uscita.x, uscita.y, meta.x, meta.y);
    if (giro < giroMigliore) {
      giroMigliore = giro;
      migliore = entrata;
    }
  }
  return migliore;
}

// Il prossimo punto verso cui deve camminare il personaggio
function prossimaTappa(u, meta) {
  return tappaDa(u.x, u.y, meta);
}

// Quanta strada A PIEDI c'e' da un personaggio a una meta: si seguono le
// stesse tappe che farebbe camminando (ponte compreso) e si sommano i pezzi.
function distanzaAPiedi(u, meta) {
  let x = u.x, y = u.y;
  let totale = 0;
  for (let i = 0; i < 5; i++) {               // al massimo qualche tappa
    const t = tappaDa(x, y, meta);
    totale += distanza(x, y, t.x, t.y);
    if (t === meta) return totale;
    x = t.x;
    y = t.y;
  }
  return totale + distanza(x, y, meta.x, meta.y);
}
