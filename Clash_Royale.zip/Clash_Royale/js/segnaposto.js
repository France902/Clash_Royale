// ============================================================
//  SEGNAPOSTO DI CONTROLLO: i cerchi e i quadrati di debug sopra il canvas
// ============================================================

// I segnaposto di controllo (div). Ognuno ricorda: il div, il punto che
// segna, quanto e' grande, il tipo ('ponte', 'ingresso', 'arrivo',
// 'partenza'), la squadra e l'asse a cui appartiene. Quelli di 'partenza'
// ricordano anche il loro personaggio (unita).
let segnaposto = [];

// Crea un segnaposto, lo aggiunge alla lista e lo restituisce
function aggiungiSegnaposto(punto, lato, tipo, team, asse) {
  const div = document.createElement('div');
  div.className = 'punto ' + tipo;
  if (DEBUG) div.style.display = 'block';
  else       div.style.display = 'none';
  document.body.appendChild(div);
  const s = { div: div, punto: punto, lato: lato, tipo: tipo, team: team, asse: asse, unita: null };
  segnaposto.push(s);
  return s;
}

// I segnaposto fissi: quelli delle corsie e quelli intorno ai re.
// Quelli di partenza li aggiunge schiera(), uno per personaggio.
function creaSegnaposto() {
  for (const team of ['blue', 'red']) {
    for (const asse of ASSI[team]) {
      aggiungiSegnaposto(asse.bridge, DOT_SIZE, 'ponte',    team, asse);
      aggiungiSegnaposto(asse.entry,  SQUARE,   'ingresso', team, asse);
      aggiungiSegnaposto(asse.tower,  SQUARE,   'arrivo',   team, asse);
    }
  }
  // I quadrati intorno ai re (quelli delle corsie ci sono gia')
  for (const team of ['blue', 'red']) {
    for (const q of QUADRATI_TORRE[team]) {
      if (q.torre.type === 'king') aggiungiSegnaposto(q, SQUARE, 'arrivo', team, null);
    }
  }
}

// Toglie i segnaposto di partenza (nuova partita: i personaggi non ci sono piu')
function rimuoviPartenze() {
  const restano = [];
  for (const s of segnaposto) {
    if (s.tipo === 'partenza') s.div.remove();
    else                       restano.push(s);
  }
  segnaposto = restano;
}

// Mette ogni segnaposto sul suo punto della mappa
function placeDots() {
  for (const s of segnaposto) {
    const size = s.lato * mapScale;
    s.div.style.width  = size + 'px';
    s.div.style.height = size + 'px';
    s.div.style.left   = toScreenX(s.punto.x) + 'px';
    s.div.style.top    = toScreenY(s.punto.y) + 'px';
  }
}

// Diventano verdi: gli assi scelti dai personaggi vivi (ingresso e ponte)
// e i quadrati di torre che fanno parte dei loro percorsi
function colorDots() {
  for (const s of segnaposto) {
    let scelto = false;
    for (const u of UNITA) {
      if (!u.alive || u.team !== s.team) continue;
      if ((s.tipo === 'ponte' || s.tipo === 'ingresso') && s.asse === u.axis) scelto = true;
      if (s.tipo === 'arrivo' && u.path.includes(s.punto)) scelto = true;
    }

    let classe = 'punto ' + s.tipo;
    if (s.tipo === 'ponte' && scelto) classe = 'punto bersaglio';   // il cerchio scelto
    else if (scelto)                  classe += ' scelto';
    if (s.team === 'red') classe += ' rossa';

    s.div.className = classe;

    // Il punto di partenza si vede solo finche' il suo personaggio e' vivo
    if (s.tipo === 'partenza') {
      if (DEBUG && s.unita.alive) s.div.style.display = 'block';
      else                        s.div.style.display = 'none';
    }
  }
}
