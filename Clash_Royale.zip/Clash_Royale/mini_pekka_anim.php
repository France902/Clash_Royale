<?php
// ============================================================
//  ANIMAZIONE DI UN PERSONAGGIO CHE AVANZA
//
//  Il personaggio ha 3 stati:
//    1. walk   -> cammina in una direzione
//    2. attack -> arrivato a meta' schermo si ferma e attacca
//    3. reload -> tra un attacco e l'altro aspetta (ricarica)
//  Dopo l'ultimo attacco torna a camminare, e cosi' all'infinito.
//
//  Cartelle:
//    character_anim.php
//    characters/mini_pekka.json   <- le impostazioni del personaggio
//    assets/mini_pekka/           <- i PNG (il percorso e' scritto nel JSON)
//
//  Apri: character_anim.php              (personaggio di default)
//        character_anim.php?char=nome    (carica characters/nome.json)
//
//  Per cambiare la cartella dei PNG: modifica "assetsDir" nel JSON.
// ============================================================


// ============================================================
//  PARTE PHP: gira sul server, prima che la pagina arrivi al browser.
//  Legge il JSON e prepara la lista dei file PNG da caricare.
// ============================================================

// Nome del personaggio: se nell'indirizzo c'e' ?char=nome usa quello,
// altrimenti usa 'mini_pekka'. L'operatore ?? significa "se non esiste, usa questo".
$charId = $_GET['char'] ?? 'mini_pekka';

// Percorso del file JSON, partendo dalla cartella di questo file (__DIR__)
$file = __DIR__ . '/characters/' . $charId . '.json';

$errore = '';    // se qualcosa va storto, qui scriviamo il messaggio
$cfg    = null;  // qui metteremo le impostazioni lette dal JSON

// Il nome puo' contenere solo lettere, numeri, _ e - (cosi' nessuno
// puo' scrivere nell'indirizzo un percorso strano). Poi controlla che il file esista.
if (!preg_match('/^[\w-]+$/', $charId) || !is_file($file)) {
    $errore = "Personaggio non trovato: characters/$charId.json";
} else {
    // Legge il file e lo trasforma in un array PHP
    $cfg = json_decode(file_get_contents($file), true);

    // Controlla che ci siano almeno i dati della camminata
    if (!isset($cfg['walk']['prefix'], $cfg['walk']['firstFrame'], $cfg['walk']['lastFrame'])) {
        $errore = 'JSON non valido: manca la sezione "walk" (prefix, firstFrame, lastFrame).';
        $cfg = null;
    }
}

// Crea la lista dei file di una sezione (walk o attack).
// Esempio: prefisso "mini_pekka_forward_blue_" + numero "003" + ".png"
//   -> assets/mini_pekka/mini_pekka_forward_blue_003.png
function elencoFrame($cartella, $sezione) {
    $lista = [];
    for ($i = $sezione['firstFrame']; $i <= $sezione['lastFrame']; $i++) {
        // sprintf('%03d', 3) scrive il numero con 3 cifre: 3 -> "003"
        // "?v=" + ora attuale: il browser non usa una vecchia versione dei PNG
        $lista[] = $cartella . '/' . $sezione['prefix'] . sprintf('%03d', $i) . '.png?v=' . time();
    }
    return $lista;
}

if ($cfg) {
    // Cartella dei PNG, presa dal campo "assetsDir" del JSON.
    // ATTENZIONE: il valore dopo ?? ('assets') si usa SOLO se nel JSON
    // "assetsDir" non c'e'. Se c'e', vince il JSON: per cambiare cartella
    // si modifica il JSON, non questa riga.
    $cartella = $cfg['assetsDir'] ?? 'assets';

    // Aggiunge al JSON la lista dei PNG, che poi passiamo a JavaScript
    $cfg['walk']['urls'] = elencoFrame($cartella, $cfg['walk']);
    if (isset($cfg['attack'])) {   // la sezione "attack" e' facoltativa
        $cfg['attack']['urls'] = elencoFrame($cartella, $cfg['attack']);
    }
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="utf-8">
<title><?= htmlspecialchars($cfg['name'] ?? 'Animazione') ?></title>
<style>
  /* Pagina a tutto schermo, senza margini e senza barre di scorrimento */
  html, body { margin: 0; height: 100%; background: #2b2b2b; color: #eee; font-family: Arial, sans-serif; }
  body   { overflow: hidden; }
  /* pixelated = i pixel restano nitidi quando si ingrandisce */
  canvas { display: block; background: #444; image-rendering: pixelated; }
  /* Scritta con lo stato, fissa in basso a sinistra */
  #info  { position: fixed; left: 10px; bottom: 8px; font-size: 14px; opacity: .8; }
  .errore { color: #ff8080; padding: 10px; }
</style>
</head>
<body>

<?php if ($errore): ?>
  <!-- Se c'e' un errore (JSON mancante o sbagliato) lo mostra e basta -->
  <div class="errore"><?= htmlspecialchars($errore) ?></div>
<?php else: ?>
<!-- Il canvas e' la "tela" su cui JavaScript disegna lo sprite -->
<canvas id="stage"></canvas>
<div id="info">caricamento...</div>

<script>
// ============================================================
//  PARTE JAVASCRIPT: gira nel browser e fa muovere il personaggio
// ============================================================

// ---------- IMPOSTAZIONI (arrivano dal JSON tramite PHP) ----------
const CFG    = <?= json_encode($cfg, JSON_UNESCAPED_SLASHES) ?>;
const WALK   = CFG.walk;
const ATTACK = CFG.attack ?? { urls: [] };   // senza "attack" il personaggio cammina e basta

// Nota: "A ?? B" significa "usa A, ma se A non esiste usa B".
//       "A?.b" significa "leggi b, ma senza errori se A non esiste".

const TICK_RATE = 60;                         // aggiornamenti della logica al secondo
const SCALE     = CFG.scale ?? 1;             // 2 = sprite grande il doppio
const SPEED_X   = CFG.movement?.speedX ?? 0;  // pixel per tick (negativo = sinistra)
const SPEED_Y   = CFG.movement?.speedY ?? 2;  // pixel per tick (negativo = su)

// Durata di ogni frame, in tick (1 tick = 1/60 di secondo).
// Si possono usare i decimali (es. 2.5), ma mai meno di 1.
const WALK_TICKS       = WALK.ticksPerFrame ?? 3;                 // camminata
const SLOW_TICKS       = ATTACK.slowTicksPerFrame ?? 3;           // primi frame dell'attacco
const FAST_TICKS       = ATTACK.fastTicksPerFrame ?? SLOW_TICKS;  // frame successivi
const SLOW_UNTIL       = ATTACK.slowUntilFrame ?? 0;              // ultimo frame "lento"
const ATTACKS_PER_STOP = ATTACK.attacksPerStop ?? 1;              // attacchi per sosta
const RELOAD_TICKS     = (ATTACK.reloadSeconds ?? 1) * TICK_RATE; // secondi -> tick

// ---------- VARIABILI ----------
const canvas = document.getElementById('stage');   // la tela
const ctx    = canvas.getContext('2d');            // lo strumento per disegnarci sopra
const info   = document.getElementById('info');    // la scritta in basso

let walkImages = [], attackImages = [];  // le immagini gia' caricate
let spriteW = 0, spriteH = 0;            // dimensioni dello sprite
let posX = 0, posY = 0;                  // posizione (angolo in alto a sinistra)

let state = 'walk';        // stato attuale: 'walk', 'attack' o 'reload'
let currentFrame = 0;      // quale immagine mostrare
let frameTime    = 0;      // da quanti tick si vede il frame corrente
let attackCount  = 0;      // attacchi fatti in questa sosta
let reloadTicks  = 0;      // tick passati in ricarica
let attackDone   = false;  // ha gia' attaccato in questo passaggio?

// ---------- POSIZIONE ----------
// Mette lo sprite appena fuori dal bordo da cui "arriva"
function resetPosition() {
  posX = (canvas.width  - spriteW) / 2;   // di base: al centro dello schermo
  posY = (canvas.height - spriteH) / 2;
  if (SPEED_X > 0) posX = -spriteW;       // va a destra: parte fuori a sinistra
  if (SPEED_X < 0) posX = canvas.width;   // va a sinistra: parte fuori a destra
  if (SPEED_Y > 0) posY = -spriteH;       // va giu': parte fuori in alto
  if (SPEED_Y < 0) posY = canvas.height;  // va su: parte fuori in basso
  attackDone = false;                     // nel nuovo passaggio potra' attaccare di nuovo
}

// Lo sprite e' uscito del tutto dallo schermo?
function isOutside() {
  return (SPEED_X > 0 && posX > canvas.width)  || (SPEED_X < 0 && posX < -spriteW)
      || (SPEED_Y > 0 && posY > canvas.height) || (SPEED_Y < 0 && posY < -spriteH);
}

// Il centro dello sprite ha raggiunto il centro dello schermo?
function isAtMiddle() {
  const cx = posX + spriteW / 2;   // centro dello sprite
  const cy = posY + spriteH / 2;
  return (SPEED_X > 0 && cx >= canvas.width  / 2) || (SPEED_X < 0 && cx <= canvas.width  / 2)
      || (SPEED_Y > 0 && cy >= canvas.height / 2) || (SPEED_Y < 0 && cy <= canvas.height / 2);
}

// ---------- ANIMAZIONE ----------
// Fa passare un tick. Quando il frame ha finito il suo tempo, passa al successivo.
// Ritorna true quando l'animazione ha finito un giro completo.
function nextFrame(duration, totalFrames) {
  frameTime++;
  if (frameTime < duration) return false;     // il frame deve durare ancora
  frameTime -= duration;                      // il resto decimale non si perde
  currentFrame++;
  if (currentFrame < totalFrames) return false;
  currentFrame = 0;                           // ultimo frame finito: si ricomincia
  return true;
}

// Inizia un colpo: riparte dal primo frame di attacco
function startSwing() {
  state = 'attack';
  currentFrame = 0;
  frameTime = 0;
}

// ---------- LOGICA DEI 3 STATI (eseguita a ogni tick) ----------
function updateWalk() {
  // Arrivato a meta' schermo (e non ha ancora attaccato): inizia l'attacco
  if (!attackDone && attackImages.length > 0 && isAtMiddle()) {
    attackDone = true;                        // un solo attacco per passaggio
    attackCount = 0;
    startSwing();
    return;
  }
  posX += SPEED_X;                            // si muove
  posY += SPEED_Y;
  if (isOutside()) resetPosition();           // uscito dallo schermo: teletrasporto
  nextFrame(WALK_TICKS, walkImages.length);   // fa avanzare le gambe
}

function updateAttack() {
  // I primi frame durano di piu', gli altri meno
  const duration = currentFrame <= SLOW_UNTIL ? SLOW_TICKS : FAST_TICKS;
  if (!nextFrame(duration, attackImages.length)) return;   // colpo non ancora finito

  attackCount++;                              // colpo finito
  frameTime = 0;
  reloadTicks = 0;
  // Ci sono altri colpi da fare? Allora ricarica, altrimenti riparte a camminare
  state = attackCount < ATTACKS_PER_STOP ? 'reload' : 'walk';
}

function updateReload() {
  // Resta fermo sul primo frame di attacco finche' la ricarica non e' finita
  reloadTicks++;
  if (reloadTicks >= RELOAD_TICKS) startSwing();
}

// Sceglie cosa fare in base allo stato
function update() {
  if (state === 'walk')   updateWalk();
  if (state === 'attack') updateAttack();
  if (state === 'reload') updateReload();
}

// ---------- DISEGNO ----------
function render() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);   // cancella il frame precedente
  ctx.imageSmoothingEnabled = false;                  // pixel nitidi

  // Camminata: immagini di walk. Attacco e ricarica: immagini di attack.
  const img = (state === 'walk' ? walkImages : attackImages)[currentFrame];
  const w = img.naturalWidth  * SCALE;
  const h = img.naturalHeight * SCALE;
  // Se i frame hanno dimensioni diverse, li centra nel riquadro dello sprite
  ctx.drawImage(img, Math.round(posX + (spriteW - w) / 2), Math.round(posY + (spriteH - h) / 2), w, h);
}

// ---------- LOOP PRINCIPALE ----------
// update() viene chiamato esattamente 60 volte al secondo,
// anche se il monitor e' a 144 Hz. Il browser chiama loop() a ogni
// aggiornamento dello schermo: noi calcoliamo quanti tick sono passati.
let lastTime = 0, accumulator = 0;

function loop(now) {
  // Tempo passato dall'ultima volta (massimo 250 ms: niente salti dopo una pausa)
  accumulator += Math.min(now - lastTime, 250);
  lastTime = now;

  // Ogni 1/60 di secondo accumulato = un tick di logica
  while (accumulator >= 1000 / TICK_RATE) {
    update();
    accumulator -= 1000 / TICK_RATE;
  }
  render();

  info.textContent = CFG.name + ' | ' + state + ' | frame ' + currentFrame +
                     ' | x: ' + Math.round(posX) + ' y: ' + Math.round(posY);
  requestAnimationFrame(loop);   // chiede al browser di richiamare loop() al prossimo schermo
}

// ---------- AVVIO ----------
// Carica un'immagine e aspetta che sia pronta. Se il file non c'e',
// l'errore mostra il percorso che ha provato: utile per correggere "assetsDir".
function loadImage(src) {
  return new Promise((ok, errore) => {
    const img = new Image();
    img.onload  = () => ok(img);
    img.onerror = () => errore(new Error('Immagine non trovata: ' + src));
    img.src = src;
  });
}

// Il canvas occupa tutta la finestra
function resizeCanvas() {
  canvas.width  = window.innerWidth;
  canvas.height = window.innerHeight;
}
window.addEventListener('resize', resizeCanvas);

// Carica tutte le immagini; quando sono pronte tutte, parte l'animazione
Promise.all([
  Promise.all(WALK.urls.map(loadImage)),
  Promise.all(ATTACK.urls.map(loadImage))
])
  .then(([walk, attack]) => {
    walkImages   = walk;
    attackImages = attack;
    spriteW = walkImages[0].naturalWidth  * SCALE;   // dimensioni prese dal primo frame
    spriteH = walkImages[0].naturalHeight * SCALE;
    resizeCanvas();
    resetPosition();
    lastTime = performance.now();
    requestAnimationFrame(loop);
  })
  .catch(err => { info.textContent = err.message; });   // mostra l'errore in basso a sinistra
</script>
<?php endif; ?>

</body>
</html>