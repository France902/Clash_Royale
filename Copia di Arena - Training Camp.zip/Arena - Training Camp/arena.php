<?php
// ============================================================
//  SCHEDA DEL FILE: arena.php
//
//  A COSA SERVE
//    E' la porta d'ingresso del gioco: il browser apre SOLO questo file.
//    Da solo non fa quasi niente: controlla che l'utente abbia fatto
//    l'accesso, poi "monta" gli altri pezzi con require, nell'ordine giusto.
//    Lo stesso indirizzo risponde a due tipi di richiesta:
//      - arena.php                 -> la pagina HTML con il canvas
//      - arena.php?azione=stato    -> JSON per js/rete.js  (vedi inc/api.php)
//      - arena.php?azione=schiera  -> JSON per js/input.js (vedi inc/api.php)
//      - arena.php?azione=ricomincia -> JSON per js/ricomincia.js (vedi inc/api.php)
//
//  SI COLLEGA A
//    arriva da:   accesso.php (dopo il login mette $_SESSION['utente'] e
//                 fa il redirect qui)
//    include:     fazioni.php, lobby.php, inc/config.php, inc/personaggi.php,
//                 inc/prepara.php, inc/difese.php, inc/elisir.php,
//                 inc/api.php, inc/pagina.php
//    rimanda a:   accesso.php (se manca la sessione)
//    chiamato da: js/rete.js e js/input.js (richieste AJAX a se' stesso)
//    file letti:  characters/*.json e assets/... (tramite inc/)
//    file scritti: lobby.json (tramite lobby.php)
//
//  Qui sotto c'e' la descrizione completa delle regole di gioco e la mappa
//  di tutti i file.
// ============================================================
// ============================================================
//  MAPPA DELL'ARENA CON TORRI, BARRE DELLA VITA E PERSONAGGI DA SCHIERARE
//
//  Ogni giocatore ha un MAZZO di carte (inc/config.php, $mazzi): per ora
//  Mini P.E.K.K.A e Cavaliere. I personaggi BLU partono in basso, i ROSSI in
//  alto, e seguono tutti le STESSE regole, verso la meta' avversaria.
//  Ogni ponte ha 3 ASSI (sinistra, centro, destra). Per ogni squadra, ogni
//  asse ha 3 punti sulla stessa x: un QUADRATO d'ingresso prima del ponte,
//  un CERCHIO sul ponte e un QUADRATO davanti alle torri avversarie.
//    1. parte dove il giocatore ha cliccato, nella sua meta' del campo
//    2. va al proprio quadrato d'ingresso PIU' VICINO (tra tutti e 6).
//       Le torri sono BLOCCHI SOLIDI: se ne tocca una, SCIVOLA di lato
//       finche' la strada dritta verso il punto non e' di nuovo libera
//    3. attraversa il ponte lungo il SUO asse: quadrato -> cerchio sul ponte
//    4. sul ponte: avversario piu' vicino -> lo insegue,
//       altrimenti va dritto al quadrato della torre
//    5. in QUALSIASI momento: se l'avversario e' piu' vicino della meta lo
//       insegue (distanza "a piedi", passando dai ponti); se e' a portata
//       ("range" nel JSON) si ferma e lo attacca
//    6. davanti alla torre la ATTACCA: colpo, ricarica, colpo...
//    7. torre a 0 = DISTRUTTA: punta l'obiettivo piu' vicino.
//       Distrutto un re la partita e' finita: si fermano tutti.
//
//  RICOMINCIA: il bottone in basso a destra fa ripartire la partita da capo
//  in qualsiasi momento, per entrambi i giocatori (conto alla rovescia di 3 s).
//
//  LE TORRI SPARANO ai personaggi nemici che entrano nel loro raggio:
//  la principessa con l'animazione e le frecce, il re con il cannone.
//  Il colpo vola fino a dove era il nemico e fa danno quando arriva.
//
//  Con piu' personaggi in campo, "l'avversario" e' sempre il NEMICO VIVO
//  PIU' VICINO (a piedi); se quello che insegue muore, sceglie di nuovo.
//
//  ELISIR: ogni giocatore parte con 10 di elisir e ne recupera 1 ogni 2
//  secondi. Ogni carta costa quanto dice "elixir" nel suo JSON (Mini
//  P.E.K.K.A 4, Cavaliere 3). Si schiera quanto si vuole, finche' c'e' elisir.
//  La carta da schierare si sceglie con i bottoni a sinistra o con le frecce.
//  L'elisir non si salva da nessuna parte: si ricalcola dagli schieramenti.
//
//  DUE GIOCATORI (lobby.php): il primo che entra e' BLU, il secondo ROSSO.
//  Il server NON simula niente: tiene l'ora d'inizio e gli schieramenti con
//  il loro TICK. Ogni client calcola dal tempo del server a che tick e'
//  arrivata la partita e fa girare la simulazione (DETERMINISTICA) fino a li'.
//
//  Il gioco e' diviso in tanti file, ognuno con uno scopo:
//
//    arena.php              <- QUESTO: il direttore d'orchestra, li mette insieme
//    inc/config.php         impostazioni (mappa, torri, corsie, personaggi...)
//    inc/personaggi.php     legge i JSON dei personaggi
//    inc/prepara.php        prepara i dati per JavaScript
//    inc/difese.php         legge come sparano le torri (characters/princess.json, king.json)
//    inc/elisir.php         quanto elisir ha una squadra (stesso conto di js/elisir.js)
//    inc/api.php            risposte AJAX (?azione=stato, ?azione=schiera)
//    inc/pagina.php         la pagina HTML
//    css/arena.css          lo stile
//    js/utilita.js          piccoli aiuti (distanze, valori mancanti)
//    js/direzioni.js        le 6 direzioni degli sprite
//    js/fiume.js            fiume, ponti e strada a piedi
//    js/solidi.js           le torri come blocchi solidi (collisioni)
//    js/torri.js            torri e quadrati di attacco
//    js/unita.js            i personaggi e lo schieramento
//    js/obiettivi.js        dove andare e quando cambiare idea
//    js/attacco.js          colpo, danno, ricarica
//    js/movimento.js        passi, scivolate, camminata, tick di logica
//    js/difese.js           le torri che sparano e i loro proiettili
//    js/schermo.js          canvas e conversione mappa <-> schermo
//    js/segnaposto.js       i segnaposto di debug
//    js/disegno.js          tutto quello che si disegna sul canvas
//    js/sopra_torri.js      re, cannone, principesse e proiettili (il disegno)
//    js/hud.js              avvisi, righe di info, pannelli dei giocatori
//    js/elisir.js           l'elisir e la sua barra
//    js/mazzo.js            le carte del mio mazzo: bottoni a sinistra e frecce
//    js/input.js            il clic che schiera
//    js/rete.js             sincronizzazione con il server e simulazione
//    js/ricomincia.js       il bottone "Ricomincia" in basso a destra
//    js/avvio.js            caricamento immagini, ciclo di animazione
//
//  Gli altri file restano come prima:
//    accesso.php, logout.php, fazioni.php, utenti.json (creato da solo)
//    lobby.php, lobby.json (creato da solo)
//    characters/mini_pekka.json, characters/mini_pekka_red.json
//    characters/knight_blue.json, characters/knight_red.json
//    characters/princess.json, characters/king.json   (come sparano le torri)
//    characters/princess_red.json, princess_blue.json (da importa_sprite.php)
//    assets/... (mappa, torri, personaggi, barre della vita)
// ============================================================

// La cartella del gioco: i file in inc/ la usano per trovare characters/ e
// assets/, e controllano che esista per non funzionare se aperti da soli.
// SERVE A: dare ai file in inc/ un "lasciapassare" e la cartella del gioco.
// I file in inc/ controllano che ARENA_DIR esista: se qualcuno li apre
// direttamente dal browser (es. .../inc/api.php) non fanno niente.
// ARENA_DIR contiene la cartella di questo file (es. C:\xampp\htdocs\Clash_Royale),
// cosi' i file in inc/ trovano characters/ e assets/ ovunque sia il progetto.
define('ARENA_DIR', __DIR__);

// ---------- SESSIONE ----------
// Chi non ha fatto l'accesso torna alla pagina di accesso
// SERVE A: sapere CHI sta aprendo la pagina. Recupera i dati salvati da
// accesso.php al momento del login (nome e fazione del giocatore).
session_start();
if (!isset($_SESSION['utente'])) {
    // SERVE A: mandare alla pagina di accesso chi non ha fatto il login.
    // exit subito dopo e' obbligatorio: senza, PHP continuerebbe e mostrerebbe
    // comunque l'arena a uno sconosciuto.
    header('Location: accesso.php');
    exit;
}
// SERVE A: caricare i pezzi che servono qui, come se il loro codice fosse
// scritto in questo punto.
//   fazioni.php -> l'elenco delle fazioni (per i pannelli dei giocatori)
//   lobby.php   -> le funzioni per entrare in una partita
// require (e non include): se un file manca, meglio fermarsi subito che far
// partire un gioco a meta'.
require __DIR__ . '/fazioni.php';
require __DIR__ . '/lobby.php';
// SERVE A: avere a portata di mano chi gioca, es. ['username' => 'France', 'fazione' => 'rune'].
$utente = $_SESSION['utente'];                    // ['username' => ..., 'fazione' => ...]

// Da qui in poi la sessione si legge soltanto: la si chiude subito, cosi' le
// richieste continue del client (ogni 150 ms) non si bloccano a vicenda.
// SERVE A: non rallentare il gioco. Finche' la sessione e' aperta, PHP serve
// le richieste dello stesso giocatore una alla volta, in fila. Il gioco chiede
// lo stato ogni 150 ms: chiudendo la sessione le richieste non si aspettano.
session_write_close();

// ---------- I PEZZI, IN ORDINE ----------
require __DIR__ . '/inc/config.php';      // 1. le impostazioni
require __DIR__ . '/inc/personaggi.php';  // 2. i personaggi
require __DIR__ . '/inc/prepara.php';     // 3. i dati per JavaScript
require __DIR__ . '/inc/difese.php';      //    ...e come sparano le torri
require __DIR__ . '/inc/elisir.php';      // 4. il calcolo dell'elisir
// ATTENZIONE: se il browser sta chiedendo dati (arena.php?azione=...),
// inc/api.php risponde e si ferma li'. Le righe sotto (entrare in lobby e
// mostrare la pagina) valgono solo per chi apre la pagina normalmente.
require __DIR__ . '/inc/api.php';         // 5. se e' una richiesta AJAX risponde e si ferma qui

// ---------- INGRESSO NELLA LOBBY ----------
// Aprendo la pagina si entra in una lobby (o si torna nella propria)
// SERVE A: mettere il giocatore in una partita e sapere se e' blu o rosso.
// Il primo che entra e' blu, il secondo rosso. Da questo dipende tutto: dove
// puo' schierare, dove sta la sua barra dell'elisir, chi sono i nemici.
$miaSquadra = entraInLobby($fileLobby, $utente['username'], $utente['fazione']);

// 6. la pagina
// SERVE A: mandare al browser la pagina vera e propria, con dentro tutti i
// dati preparati sopra (torri, corsie, personaggi...) per JavaScript.
require __DIR__ . '/inc/pagina.php';
