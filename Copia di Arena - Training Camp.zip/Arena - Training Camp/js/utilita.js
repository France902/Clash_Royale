// ============================================================
//  js/utilita.js - PICCOLI AIUTI
//
//  A COSA SERVE
//    Funzioni piccole usate dappertutto: valori mancanti, distanze, punto
//    piu' vicino. E' il PRIMO script caricato: non dipende da nessuno.
//
//  DEFINISCE
//    manca(), oppure(), lunghezza(), distanza(), piuVicino()
//
//  USATO DA
//    quasi tutti: js/torri.js, js/fiume.js, js/unita.js, js/obiettivi.js,
//    js/attacco.js, js/movimento.js, js/difese.js, js/sopra_torri.js...
// ============================================================

// Vero se un valore NON c'e' (per esempio manca nel JSON)
// SERVE A: capire se un'impostazione non c'e' (es. manca nel JSON).
function manca(valore) {
  return valore === undefined || valore === null;
}

// Restituisce il valore, oppure quello predefinito se il valore manca.
// Esempio: oppure(cfg.scale, 1) -> la scala del JSON, o 1 se non c'e'.
// SERVE A: usare un valore di riserva quando nel JSON manca qualcosa.
// Es. oppure(cfg.scale, 1): la scala del JSON, o 1 se non e' scritta.
// A differenza di "||", uno 0 scritto nel JSON viene rispettato.
function oppure(valore, predefinito) {
  if (manca(valore)) return predefinito;
  return valore;
}

// Lunghezza di un vettore (dx, dy): teorema di Pitagora.
// Si usa Math.sqrt e non Math.hypot: sqrt da' lo STESSO risultato su ogni
// browser, e i due giocatori devono calcolare esattamente gli stessi numeri.
function lunghezza(dx, dy) {
  return Math.sqrt(dx * dx + dy * dy);
}

// Distanza tra due punti
function distanza(x1, y1, x2, y2) {
  return lunghezza(x2 - x1, y2 - y1);
}

// Tra i punti della lista, quello piu' vicino al punto (x, y)
function piuVicino(lista, x, y) {
  // A parita' di distanza vince il primo della lista: cosi' entrambi i giocatori
  // fanno sempre la stessa scelta.
  let migliore = lista[0];
  for (const p of lista) {
    if (distanza(p.x, p.y, x, y) < distanza(migliore.x, migliore.y, x, y)) {
      migliore = p;
    }
  }
  return migliore;
}
