// ============================================================
//  js/input.js - IL CLIC CHE SCHIERA
//
//  A COSA SERVE
//    Quando il giocatore clicca sul canvas: converte il punto in coordinate
//    della mappa, fa i primi controlli, "paga" subito l'elisir della carta
//    scelta e chiede al server di registrare lo schieramento. Il personaggio
//    NON compare qui: compare quando la simulazione raggiunge il tick deciso
//    dal server.
//
//  DEFINISCE
//    nellaMiaMeta(), sopraUnaTorre(), contaClic, clicGiocatore()
//
//  USA
//    LIMITI, MIA_SQUADRA, PERSONAGGI (da PHP), SOLIDS + insideBox()
//    (js/solidi.js), toMapX/Y, mapImg (js/schermo.js), partitaIniziata,
//    inAttesa, togliAttesa, chiediStato (js/rete.js), partitaFinita
//    (js/torri.js), hoElisir, costoCarta (js/elisir.js), cartaAttuale
//    (js/mazzo.js), mostraAvviso (js/hud.js)
//    server: arena.php?azione=schiera (inc/api.php)
//
//  USATO DA
//    js/avvio.js (canvas.addEventListener('click', clicGiocatore))
// ============================================================

// Il punto (y) e' nella meta' della mia squadra?
function nellaMiaMeta(y) {
  if (MIA_SQUADRA === 'blue') return y >= LIMITI.blue;
  return y <= LIMITI.red;
}

// Il punto e' sopra una torre (anche distrutta)? Come il controllo del server,
// che non sa quali torri sono cadute: sulle rovine non si schiera.
// Anche sulle rovine di una torre non si schiera (come controlla il server).
function sopraUnaTorre(x, y) {
  for (const b of SOLIDS) {
    if (insideBox(x, y, b)) return true;
  }
  return false;
}

// Ogni schieramento ha un "numero di ricevuta" (cid): il server lo rimette
// nell'evento, cosi' quando l'evento arriva si sa quale clic in attesa togliere
let contaClic = 0;

// Il giocatore ha cliccato: chiede al server di schierare la carta scelta
// (bottoni a sinistra o frecce, vedi js/mazzo.js).
// Si puo' cliccare di nuovo subito (anche prima della risposta), se c'e'
// abbastanza elisir. Il personaggio NON compare subito: compare quando la
// simulazione arriva al tick deciso dal server, uguale per tutti e due.
// SERVE A: trasformare un clic in una richiesta di schieramento al server.
async function clicGiocatore(evento) {
  // Dalla posizione del mouse sullo schermo alla posizione sulla mappa.
  const x = toMapX(evento.clientX);
  const y = toMapY(evento.clientY);

  // Primi controlli qui (il server li rifa' comunque)
  const dentroMappa = x >= 0 && x <= mapImg.width && y >= 0 && y <= mapImg.height;
  if (!dentroMappa) return;
  if (!partitaIniziata()) {
    mostraAvviso('La partita non e\' ancora iniziata');
    return;
  }
  if (partitaFinita()) {
    mostraAvviso('La partita e\' finita');
    return;
  }
  if (!nellaMiaMeta(y)) {
    mostraAvviso('Puoi schierarlo solo nella tua meta\' del campo');
    return;
  }
  if (sopraUnaTorre(x, y)) {
    mostraAvviso('Non puoi schierarlo sopra una torre');
    return;
  }
  // La carta scelta nella pila a sinistra (js/mazzo.js).
  const carta = cartaAttuale();
  if (!hoElisir(carta)) {
    mostraAvviso('Elisir insufficiente per ' + PERSONAGGI[MIA_SQUADRA][carta].name);
    return;
  }

  // Finche' il server non lo conferma: un cerchio li' e l'elisir gia' pagato
  // SERVE A: ricordare il clic finche' il server non lo conferma: dove, quale
  // carta, quanto costa (per scalare subito l'elisir) e un numero di ricevuta
  // unico (cid) per riconoscerlo quando torna.
  const attesa = { x: x, y: y, carta: carta, costo: costoCarta(carta), cid: Date.now() + '-' + contaClic };
  contaClic++;
  // Da subito si vede il cerchio e l'elisir scende, senza aspettare il server.
  inAttesa.push(attesa);

  // Invio al server (POST, come un form)
  try {
    // I dati del clic, inviati come un normale form.
    const dati = new FormData();
    dati.append('x', x);
    dati.append('y', y);
    dati.append('carta', carta);
    dati.append('cid', attesa.cid);
    // Manda il clic a arena.php (inc/api.php) e aspetta la risposta.
    const risposta = await fetch('?azione=schiera', { method: 'POST', body: dati });
    const esito = await risposta.json();
    if (!esito.ok) {
      mostraAvviso(esito.errore);
      togliAttesa(attesa.cid);     // rifiutato: l'elisir torna indietro
    }
  // Connessione persa: il clic viene annullato e l'elisir restituito.
  } catch (err) {
    mostraAvviso('Connessione al server persa');
    togliAttesa(attesa.cid);
  }
  // Chiede subito lo stato, per ricevere al piu' presto il tick dello schieramento.
  chiediStato();   // si fa dare subito l'evento con il suo tick
}
