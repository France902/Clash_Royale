// ============================================================
//  js/elisir.js - L'ELISIR E LA SUA BARRA
//
//  A COSA SERVE
//    Come per la partita, l'elisir non si "tiene": si CALCOLA dagli
//    schieramenti e dal tempo del server, con lo stesso conto del server.
//    Ogni carta ha il suo costo ("elixir" nel suo JSON). Si conta in tick di
//    ricarica: 1 di elisir = TICK_PER_ELISIR tick; sullo schermo si divide
//    e diventa elisir vero. Poi disegna la barra (10 tacche di div HTML).
//
//  DEFINISCE
//    elisirAl(), elisirMio(), costoCarta(), hoElisir(), barraElisir,
//    creaBarraElisir(), posizionaBarraElisir(), aggiornaBarraElisir()
//
//  USA
//    ELISIR_MAX, TICK_PER_ELISIR, TACCHE, BARRA_ELISIR, TICK_RATE,
//    MIA_SQUADRA, PERSONAGGI (da PHP), eventi, inAttesa, inizioPartita,
//    oraServer() (js/rete.js), cartaAttuale() (js/mazzo.js),
//    mapImg, mapScale, mapLeft, info (js/schermo.js), #elisir (inc/pagina.php)
//  GEMELLO
//    inc/elisir.php, funzioni costoCarta() ed elisirAl(): STESSO conto. Se
//    si cambia uno, va cambiato anche l'altro, o client e server non saranno
//    d'accordo.
//
//  USATO DA
//    js/input.js (hoElisir, costoCarta), js/mazzo.js (hoElisir: carte
//    sbiadite), js/disegno.js e js/hud.js (hoElisir), js/schermo.js
//    (posizionaBarraElisir), js/avvio.js (creaBarraElisir, aggiornaBarraElisir)
// ============================================================

// L'elisir di una squadra al tick dato (in tick di ricarica).
// Si parte con la barra piena. Ogni schieramento, nel tick del CLIC ('clic'),
// toglie il SUO costo ('costo'); tra uno schieramento e l'altro la barra
// cresce di 1 per tick, ma mai oltre il massimo. (Uguale a elisirAl in inc/elisir.php)
// SERVE A: sapere quanto elisir ha una squadra in un certo momento, rifacendo
// il conto da inizio partita. Stesso identico conto del server.
function elisirAl(squadra, tick) {
  tick = Math.max(tick, 0);       // prima dell'inizio la barra e' piena
  let elisir = ELISIR_MAX;
  let ultimo = 0;                 // il tick dell'ultimo conto fatto
  for (const e of eventi) {
    if (e.squadra !== squadra || e.clic > tick) continue;
    elisir = Math.min(ELISIR_MAX, elisir + (e.clic - ultimo)) - e.costo;
    ultimo = e.clic;
  }
  return Math.min(ELISIR_MAX, elisir + (tick - ultimo));
}

// Il mio elisir ADESSO (in tick di ricarica). Si usa il tick con la virgola,
// cosi' la barra cresce fluida. Gli schieramenti appena cliccati, che il
// server non ha ancora confermato, si pagano subito: la barra scende al clic.
function elisirMio() {
  if (inizioPartita === null) return ELISIR_MAX;   // si aspetta l'avversario: barra piena
  // Con i decimali: la barra si riempie in modo fluido, non a scatti.
  let tick = (oraServer() - inizioPartita) * TICK_RATE / 1000;
  // Un mio schieramento confermato e' sempre gia' successo, anche se il
  // nostro orologio e' un pelo indietro rispetto a quello del server
  for (const e of eventi) {
    // Se il nostro orologio e' un pelo indietro, un nostro schieramento gia'
    // confermato va comunque pagato.
    if (e.squadra === MIA_SQUADRA) tick = Math.max(tick, e.clic);
  }
  let elisir = elisirAl(MIA_SQUADRA, tick);
  // SERVE A: far scendere la barra SUBITO al clic, senza aspettare il server:
  // ogni clic non ancora confermato paga gia' il costo della sua carta.
  // Se il server rifiuta, l'elisir torna indietro (js/input.js).
  for (const p of inAttesa) elisir -= p.costo;
  return Math.max(elisir, 0);
}

// Quanto costa una carta del mio mazzo, in tick di ricarica (come il server)
// Stesso calcolo di costoCarta() in inc/elisir.php: es. Mini P.E.K.K.A 4 -> 480 tick.
function costoCarta(carta) {
  return Math.round(PERSONAGGI[MIA_SQUADRA][carta].elixir * TICK_PER_ELISIR);
}

// Ho abbastanza elisir per schierare la carta? (senza dirla: quella scelta)
function hoElisir(carta) {
  // Se non si dice quale carta, si intende quella scelta nella pila (js/mazzo.js).
  if (carta === undefined) carta = cartaAttuale();
  return elisirMio() >= costoCarta(carta);
}

// ---------- LA BARRA ----------
// #elisir (in pagina.php) e' la BASE scura, sempre visibile. Dentro ci sono
// TACCHE div (una per elisir), ognuna con il suo riempimento colorato.
// L'ultima tacca piena a meta' si riempie a meta': la barra cresce fluida.
const barraElisir = document.getElementById('elisir');
const riempimenti = [];            // il div colorato di ogni tacca
const larghezzeAttuali = [];       // l'ultima larghezza scritta (per non riscriverla a ogni fotogramma)

function creaBarraElisir() {
  for (let i = 0; i < TACCHE; i++) {
    const tacca = document.createElement('div');
    tacca.className = 'tacca';
    const riempimento = document.createElement('div');
    riempimento.className = 'riempimento';
    tacca.appendChild(riempimento);
    barraElisir.appendChild(tacca);
    riempimenti.push(riempimento);
    larghezzeAttuali.push('');
  }
}

// Mette la barra al suo posto (la chiama layout() quando cambia la finestra):
// centrata sulla mappa, dalla parte del mio campo (blu in basso, rosso in alto)
function posizionaBarraElisir() {
  const larghezza = mapImg.width * mapScale * BARRA_ELISIR.larghezza;
  const s = barraElisir.style;
  s.width  = larghezza + 'px';
  s.height = BARRA_ELISIR.altezza * mapScale + 'px';
  s.left   = mapLeft + (mapImg.width * mapScale - larghezza) / 2 + 'px';
  if (MIA_SQUADRA === 'blue') {
    // Si toglie l'impostazione dell'altro lato (la barra sta in basso o in alto).
    s.top = '';
    s.bottom = BARRA_ELISIR.bordo + 'px';
    // le righe di debug (in basso a destra) salgono sopra la barra, per non finirci sotto
    // ...e comunque sopra il bottone "Ricomincia", che sta nello stesso angolo
    const sopraBarra   = BARRA_ELISIR.bordo + BARRA_ELISIR.altezza * mapScale + 8;
    const sopraBottone = 10 + bottoneRicomincia.offsetHeight + 8;
    info.style.bottom = Math.max(sopraBarra, sopraBottone) + 'px';
  } else {
    s.bottom = '';
    s.top = BARRA_ELISIR.bordo + 'px';
  }
}

// A ogni fotogramma: ogni tacca si riempie di quanto le spetta
// (tacca i: piena se elisir >= i + 1, vuota se elisir <= i, a meta' in mezzo)
function aggiornaBarraElisir() {
  const elisir = elisirMio() / TICK_PER_ELISIR;   // da tick di ricarica a elisir
  for (let i = 0; i < TACCHE; i++) {
    // Quanto e' piena questa tacca: 0 = vuota, 1 = piena, 0.4 = al 40%.
    const pieno = Math.min(Math.max(elisir - i, 0), 1);
    // Si aggiorna la tacca solo se e' cambiata: meno lavoro per il browser.
    const larghezza = (pieno * 100).toFixed(1) + '%';
    if (larghezza !== larghezzeAttuali[i]) {
      riempimenti[i].style.width = larghezza;
      larghezzeAttuali[i] = larghezza;
    }
  }
}
