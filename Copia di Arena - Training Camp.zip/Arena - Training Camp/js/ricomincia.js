// ============================================================
//  js/ricomincia.js - IL BOTTONE "RICOMINCIA"
//
//  A COSA SERVE
//    Il bottone in basso a destra della PAGINA (non del canvas): in qualsiasi
//    momento fa ripartire la partita da capo, per entrambi i giocatori.
//    Questo file chiede soltanto al server di ricominciare: chi azzera
//    davvero il campo e' js/rete.js (ricominciaDaCapo), quando vede che
//    l'ora d'inizio e' cambiata. Cosi' anche l'avversario riparte insieme a noi.
//
//  DEFINISCE
//    bottoneRicomincia, ricominciaPartita()
//
//  USA
//    server: arena.php?azione=ricomincia (inc/api.php)
//    chiediStato() (js/rete.js), mostraAvviso() (js/hud.js)
//
//  USATO DA
//    js/avvio.js (collega il clic), js/elisir.js (#info sta sopra il bottone)
// ============================================================

const bottoneRicomincia = document.getElementById('ricomincia');

// SERVE A: chiedere al server una partita nuova.
// Il bottone si disattiva finche' il server non risponde: due clic veloci
// non fanno ricominciare due volte.
async function ricominciaPartita() {
  bottoneRicomincia.disabled = true;
  try {
    const risposta = await fetch('?azione=ricomincia', { method: 'POST' });
    const dati = await risposta.json();
    if (dati.ok) chiediStato();             // lo stato nuovo subito, senza aspettare 150 ms
    else         mostraAvviso(dati.errore);
  } catch (err) {
    mostraAvviso('Connessione al server persa, riprova.');
  }
  bottoneRicomincia.disabled = false;
  bottoneRicomincia.blur();   // cosi' le frecce della tastiera tornano alle carte
}
