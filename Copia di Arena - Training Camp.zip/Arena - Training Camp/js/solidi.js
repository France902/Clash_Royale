// ============================================================
//  js/solidi.js - LE TORRI COME BLOCCHI SOLIDI
//
//  A COSA SERVE
//    Geometria delle collisioni: un punto e' dentro una torre? Un segmento
//    la attraversa? Le torri sono rettangoli allineati agli assi (gia'
//    allargati del "raggio" del personaggio in inc/prepara.php).
//
//  DEFINISCE
//    insideBox(), torreCheContiene(), segmentHitsBox(), trattoDentro()
//
//  USA
//    SOLIDS (inc/prepara.php: $blocchi), e b.torre (aggiunto da js/torri.js)
//    distrutta() (js/torri.js, caricato DOPO: va bene, si chiama a gioco avviato)
//
//  USATO DA
//    js/movimento.js (scivolare intorno alle torri)
//    js/input.js     (insideBox: niente schieramenti sopra una torre)
// ============================================================

// Il punto (x, y) e' DENTRO il rettangolo b? (Sul bordo non conta.)
// SERVE A: sapere se un punto e' dentro una torre. Il bordo non conta,
// cosi' chi scivola lungo il bordo non resta incastrato.
function insideBox(x, y, b) {
  const dentroX = x > b.x - b.halfW && x < b.x + b.halfW;
  const dentroY = y > b.y - b.halfH && y < b.y + b.halfH;
  return dentroX && dentroY;
}

// La torre che contiene il punto (x, y), oppure null se il punto e' libero.
// Le torri distrutte non contano: ci si passa sopra.
function torreCheContiene(x, y) {
  for (const b of SOLIDS) {
    // Le torri distrutte non sono piu' un ostacolo.
    if (!distrutta(b.torre) && insideBox(x, y, b)) return b;
  }
  return null;
}

// Il segmento da (x1, y1) a (x2, y2) passa DENTRO il rettangolo b?
// Metodo delle "fasce": il segmento si percorre con t da 0 (inizio) a 1 (fine).
// Si calcola in quale tratto di t si e' dentro le x della torre, e in quale
// tratto si e' dentro le y. Se i due tratti si sovrappongono, in quel momento
// si e' dentro tutte e due: il segmento entra nella torre.
// Toccare solo il bordo non conta.
function segmentHitsBox(x1, y1, x2, y2, b) {
  // SERVE A: capire se andando dritti verso la meta si sbatte contro la torre.
  // Se si', il personaggio continua a scivolare di lato; se no, va dritto.
  const trattoX = trattoDentro(x1, x2, b.x - b.halfW, b.x + b.halfW);
  const trattoY = trattoDentro(y1, y2, b.y - b.halfH, b.y + b.halfH);
  if (trattoX === null || trattoY === null) return false;

  const inizio = Math.max(trattoX.da, trattoY.da);
  const fine   = Math.min(trattoX.a,  trattoY.a);
  return inizio < fine;
}

// Una coordinata va da p1 a p2. Per quale tratto di t (da 0 a 1) sta tra min e max?
// Restituisce { da, a }, oppure null se non ci sta mai.
function trattoDentro(p1, p2, min, max) {
  const d = p2 - p1;

  // La coordinata non cambia (segmento parallelo alla fascia):
  // o e' dentro per tutto il segmento, o non lo e' mai
  // Il segmento non si muove su questo asse: o e' dentro tutto il tempo, o mai.
  if (Math.abs(d) < 1e-9) {
    if (p1 <= min || p1 >= max) return null;
    return { da: 0, a: 1 };
  }

  // In che momento del tragitto (da 0 a 1) si entra e si esce dalla fascia.
  let da = (min - p1) / d;
  let a  = (max - p1) / d;
  if (da > a) {          // se si va all'indietro, i due valori vanno scambiati
    // Se si va al contrario, entrata e uscita vanno scambiate.
    const tmp = da;
    da = a;
    a = tmp;
  }
  da = Math.max(da, 0);  // il segmento comincia a t = 0...
  a  = Math.min(a, 1);   // ...e finisce a t = 1
  if (da >= a) return null;
  return { da: da, a: a };
}
