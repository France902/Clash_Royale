// ============================================================
//  js/schermo.js - CANVAS E COORDINATE
//
//  A COSA SERVE
//    Prepara il canvas, calcola quanto ingrandire la mappa per farla stare
//    nella finestra e converte le coordinate: pixel della MAPPA (quelli di
//    config.php e della logica) <-> pixel dello SCHERMO (quelli del disegno
//    e del mouse).
//
//  DEFINISCE
//    canvas, ctx, info, mapImg, barImgs, mapScale, mapLeft, mapTop,
//    arenaLeft/Top/W/H, viewW/H, layout(), toScreenX/Y(), toMapX/Y()
//
//  USA
//    MARGIN, MAP_HEIGHT (da PHP), placeDots() (js/segnaposto.js),
//    posizionaBarraElisir() (js/elisir.js), posizionaPilaCarte() (js/mazzo.js)
//
//  USATO DA
//    js/disegno.js, js/sopra_torri.js, js/segnaposto.js, js/elisir.js,
//    js/mazzo.js (mapLeft), js/input.js (toMapX/Y), js/hud.js (info),
//    js/avvio.js (mapImg, barImgs, layout al caricamento e a ogni resize)
// ============================================================

// La tela su cui si disegna e lo "strumento" (ctx) per disegnarci.
const canvas = document.getElementById('stage');
const ctx    = canvas.getContext('2d');
const info   = document.getElementById('info');

// L'immagine della mappa e delle barre: le carica js/avvio.js.
let mapImg  = null;
let barImgs = {};

let mapScale = 1;
let mapLeft  = 0;
let mapTop   = 0;
let arenaLeft = 0, arenaTop = 0, arenaW = 0, arenaH = 0;
let viewW = 0, viewH = 0;   // dimensioni della finestra in pixel CSS

// ---------- POSIZIONE E GRANDEZZA ----------
function layout() {
  // Schermi ad alta densita' e zoom del browser: il canvas ha piu' pixel
  // di quelli che occupa nella pagina (dpr = pixel reali per pixel CSS),
  // cosi' le immagini restano nitide invece di essere ingrandite dal browser.
  // SERVE A: immagini nitide su schermi ad alta risoluzione e con lo zoom del browser.
  const dpr = window.devicePixelRatio || 1;
  viewW = window.innerWidth;
  viewH = window.innerHeight;
  // Il canvas ha piu' pixel "interni" di quelli che occupa: cosi' resta nitido.
  canvas.width  = Math.round(viewW * dpr);
  canvas.height = Math.round(viewH * dpr);
  canvas.style.width  = viewW + 'px';
  canvas.style.height = viewH + 'px';
  // Da qui in poi si disegna in pixel normali: l'ingrandimento lo fa il canvas.
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);   // da qui in poi si disegna in pixel CSS
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';

  // Grandezza della mappa con il margine intorno
  const w = mapImg.width  + 2 * MARGIN;
  const h = mapImg.height + 2 * MARGIN;

  // Il fattore di ingrandimento e' il piu' grande che fa stare tutto nella finestra
  // SERVE A: ingrandire la mappa il piu' possibile, ma senza farla uscire dalla finestra.
  mapScale  = Math.min(viewW / w, viewH * MAP_HEIGHT / h);
  arenaW    = w * mapScale;
  arenaH    = h * mapScale;
  arenaLeft = (viewW - arenaW) / 2;   // centrata in orizzontale
  arenaTop  = (viewH - arenaH) / 2;   // e in verticale

  mapLeft = arenaLeft + MARGIN * mapScale;
  mapTop  = arenaTop  + MARGIN * mapScale;

  placeDots();   // anche i segnaposto vanno rimessi al loro posto
  posizionaBarraElisir();   // e anche la barra dell'elisir...
  posizionaPilaCarte();     // ...e la pila delle carte
}

// Da pixel della mappa a pixel dello schermo
// SERVE A: convertire le posizioni. La logica ragiona in pixel della mappa
// (che non cambiano mai), il disegno e il mouse in pixel dello schermo.
function toScreenX(mx) { return mapLeft + mx * mapScale; }
function toScreenY(my) { return mapTop  + my * mapScale; }

// Dal punto dello schermo (pixel CSS) al punto della mappa: il contrario di toScreenX/Y
function toMapX(sx) { return (sx - mapLeft) / mapScale; }
function toMapY(sy) { return (sy - mapTop)  / mapScale; }
