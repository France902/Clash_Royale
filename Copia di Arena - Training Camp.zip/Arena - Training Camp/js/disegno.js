// ============================================================
//  js/disegno.js - TUTTO QUELLO CHE SI VEDE SUL CANVAS
//
//  A COSA SERVE
//    Disegna un fotogramma: mappa, torri (con re e principesse), zone
//    vietate, cerchi degli schieramenti in arrivo, personaggi, proiettili,
//    barre della vita e scritte al centro. Non cambia lo stato del gioco:
//    lo legge e basta.
//
//  DEFINISCE
//    drawSolids(), drawHealthBar(), barraPersonaggio(), disegnaBarra(),
//    drawRoute(), drawZonaVietata(), cerchioSchieramento(),
//    drawSchieramentiInArrivo(), drawMessaggioCentrale(), drawUnita(), draw()
//
//  USA
//    js/schermo.js (ctx, mapImg, barImgs, mapScale, toScreenX/Y...),
//    BARS, BAR_K, BAR_FILL, CHAR_BAR_K, CHAR_BAR_GAP, LIMITI, MIA_SQUADRA,
//    DEBUG (da PHP), TOWERS, SOLIDS, UNITA, js/sopra_torri.js
//    (disegnaSopraTorre, disegnaProiettili, disegnaRaggiTorri), js/rete.js
//    (eventi, inAttesa, tickSimulato, partitaIniziata,
//    messaggioPrimaDellaPartita), js/elisir.js (hoElisir), js/hud.js
//    (messaggioFinePartita)
//
//  USATO DA
//    js/avvio.js (loop chiama draw() a ogni fotogramma)
// ============================================================

// Disegna i blocchi solidi (solo in debug)
function drawSolids() {
  // save/restore: le impostazioni di disegno (colori, tratteggi...) cambiate qui
  // dentro non "sporcano" i disegni successivi.
  ctx.save();
  ctx.strokeStyle = 'rgba(255, 60, 60, .9)';
  ctx.fillStyle   = 'rgba(255, 60, 60, .15)';
  ctx.lineWidth = 2;
  for (const b of SOLIDS) {
    if (distrutta(b.torre)) continue;   // torre distrutta: niente blocco
    const x = toScreenX(b.x - b.halfW);
    const y = toScreenY(b.y - b.halfH);
    const w = 2 * b.halfW * mapScale;
    const h = 2 * b.halfH * mapScale;
    ctx.fillRect(x, y, w, h);
    ctx.strokeRect(x, y, w, h);
  }
  ctx.restore();
}

// La barra della vita di una torre: sopra la cima della torre o sopra la base
function drawHealthBar(t, cx, cy, s) {
  // Dove finiscono in alto e in basso la torre, per metterci la barra della vita.
  const towerTop    = cy - (t.anchorY - t.top)    * s;
  const towerBottom = cy + (t.bottom - t.anchorY) * s;

  let refY = towerBottom;
  if (BARS.position[t.team] === 'cima') refY = towerTop;

  const k = t.bar * BAR_K * mapScale;   // ingrandimento della barra: segue la mappa
  disegnaBarra(t.team, t.hp, t.maxHp, cx, refY - BARS.gap[t.team] * mapScale, k);
}

// La barra della vita sopra un personaggio
function barraPersonaggio(u) {
  if (u.maxHp <= 0) return;             // senza "hp" nel JSON: niente barra
  const k = CHAR_BAR_K * BAR_K * mapScale;
  disegnaBarra(u.team, u.hp, u.maxHp, toScreenX(u.x), u.cima - CHAR_BAR_GAP * mapScale, k);
}

// Disegna una barra della vita (per torri e personaggi).
//   team  = 'red' o 'blue' (il colore)
//   cx    = centro orizzontale, fondo = dove finisce in basso (pixel dello schermo)
//   k     = ingrandimento dell'immagine della barra
function disegnaBarra(team, hp, maxHp, cx, fondo, k) {
  const colorImg = barImgs[team];
  const barW = colorImg.width  * k;
  const barH = colorImg.height * k;
  const x = cx - barW / 2;
  const y = fondo - barH;

  // Sfondo nero e base grigia
  ctx.fillStyle = '#000';
  ctx.fillRect(x, y, barW, barH);
  ctx.drawImage(barImgs.base, x + BAR_FILL.x * k, y + BAR_FILL.y * k, BAR_FILL.w * k, BAR_FILL.h * k);

  // Barra colorata: lunga quanto la vita rimasta. Si taglia l'immagine da destra
  // (sorgente e destinazione della stessa frazione), cosi' sotto appare la base grigia.
  const vita = hp / maxHp;                   // 1 = piena, 0 = vuota
  if (vita > 0) {
    // SERVE A: accorciare la barra colorata in base alla vita rimasta, tagliando
    // l'immagine invece di schiacciarla. Sotto si vede la base grigia.
    ctx.drawImage(colorImg,
                  0, 0, colorImg.width * vita, colorImg.height,   // pezzo dell'immagine
                  x, y, barW * vita, barH);                       // dove disegnarlo
  }

  // Numero della vita: dentro la barra, centrato (orizzontale e verticale)
  // rispetto all'area di riempimento della barra
  const fontSize = barH * 1.5;
  const textX = x + (BAR_FILL.x + BAR_FILL.w / 2) * k;
  const textY = y + (BAR_FILL.y + BAR_FILL.h / 2) * k;
  ctx.save();
  ctx.font = 'bold ' + fontSize + 'px Arial, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'alphabetic';
  ctx.lineJoin = 'round';
  ctx.lineWidth = fontSize * 0.22;
  ctx.strokeStyle = '#000';
  ctx.fillStyle = '#fff';
  // Centro verticale reale delle cifre (non quello "teorico" del font)
  // Misura le cifre per centrare bene il numero della vita nella barra.
  const m = ctx.measureText(String(hp));
  const baseY = textY + (m.actualBoundingBoxAscent - m.actualBoundingBoxDescent) / 2;
  ctx.strokeText(hp, textX, baseY);     // contorno nero
  ctx.fillText(hp, textX, baseY);       // cifre bianche
  ctx.restore();
}

// Linea tratteggiata di controllo: partenza -> ingresso -> ponte -> (nemico) -> torre
function drawRoute(u) {
  if (!u.alive || u.path.length === 0) return;
  ctx.save();
  ctx.strokeStyle = 'rgba(255, 255, 255, .8)';
  ctx.lineWidth = 2;
  // Linea tratteggiata: 8 pixel pieni, 6 vuoti.
  ctx.setLineDash([8, 6]);   // 8 pixel di linea, 6 di vuoto
  ctx.beginPath();
  ctx.moveTo(toScreenX(u.inizio.x), toScreenY(u.inizio.y));
  for (const p of u.path) {
    ctx.lineTo(toScreenX(p.x), toScreenY(p.y));
  }
  if (u.preda !== null) {
    ctx.lineTo(toScreenX(u.preda.x), toScreenY(u.preda.y));
  }
  ctx.stroke();
  ctx.restore();
}

// Quando posso schierare (c'e' abbastanza elisir): la meta' dove NON posso
// schierare e' velata di rosso
function drawZonaVietata() {
  if (!partitaIniziata() || partitaFinita() || !hoElisir()) return;
  let da = 0, a = LIMITI.blue;                       // per il blu: tutto sopra il suo limite
  // Per il rosso la zona vietata e' quella in basso.
  if (MIA_SQUADRA === 'red') { da = LIMITI.red; a = mapImg.height; }   // per il rosso: tutto sotto
  ctx.save();
  ctx.fillStyle = 'rgba(255, 40, 40, .18)';
  ctx.fillRect(toScreenX(0), toScreenY(da), mapImg.width * mapScale, (a - da) * mapScale);
  ctx.restore();
}

// Un cerchio tratteggiato dove sta per comparire un personaggio
function cerchioSchieramento(x, y, team) {
  ctx.save();
  if (team === 'blue') ctx.strokeStyle = 'rgba(58, 176, 255, .95)';
  else                 ctx.strokeStyle = 'rgba(255, 70, 70, .95)';
  ctx.lineWidth = 3;
  ctx.setLineDash([6, 4]);
  ctx.beginPath();
  // Un cerchio completo.
  ctx.arc(toScreenX(x), toScreenY(y), 22 * mapScale, 0, 2 * Math.PI);
  ctx.stroke();
  ctx.restore();
}

// Gli schieramenti che non sono ancora "avvenuti": i miei appena cliccati
// (in viaggio verso il server) e quelli con il tick ancora nel futuro
function drawSchieramentiInArrivo() {
  for (const p of inAttesa) cerchioSchieramento(p.x, p.y, MIA_SQUADRA);
  for (const e of eventi) {
    // Schieramenti confermati ma non ancora comparsi: si mostra dove arriveranno.
    if (e.tick >= tickSimulato) cerchioSchieramento(e.x, e.y, e.squadra);
  }
}

// Una scritta grande al centro dello schermo (attesa, conto alla rovescia...)
function drawMessaggioCentrale(testo) {
  ctx.save();
  ctx.font = 'bold ' + Math.round(40 * mapScale) + 'px Arial, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.lineJoin = 'round';
  ctx.lineWidth = 8 * mapScale;
  ctx.strokeStyle = '#000';
  ctx.fillStyle = '#fff';
  ctx.strokeText(testo, viewW / 2, viewH / 2);
  ctx.fillText(testo, viewW / 2, viewH / 2);
  ctx.restore();
}

// Disegna un personaggio: il suo punto "ancora" (0-1) finisce sulla sua
// posizione. Si ricorda la y della cima dello sprite (serve per la barra).
function drawUnita(u) {
  // Attacco e ricarica: frame d'attacco. Altrimenti: la camminata in uso.
  let img;
  if (u.state === 'attack' || u.state === 'reload') img = u.attackSets[u.attackSet][u.frame];
  else                                             img = u.walkSets[u.set][u.frame];

  const s = mapScale * u.scale;                    // ingrandimento totale
  const w = img.naturalWidth  * s;
  const h = img.naturalHeight * s;
  const x = toScreenX(u.x) - w * u.anchor.x;
  const y = toScreenY(u.y) - h * u.anchor.y;
  ctx.drawImage(img, x, y, w, h);
  // Si ricorda dov'e' la testa del personaggio, per mettergli sopra la barra.
  u.cima = y;
}

// SERVE A: disegnare un fotogramma. Si disegna a strati, dal fondo:
// mappa, torri, personaggi, proiettili, barre, scritte.
function draw() {
  ctx.clearRect(0, 0, viewW, viewH);

  // La mappa
  ctx.drawImage(mapImg, mapLeft, mapTop, mapImg.width * mapScale, mapImg.height * mapScale);

  // Da qui in poi si disegna solo dentro l'arena (mappa + margine)
  ctx.save();
  ctx.beginPath();
  ctx.rect(arenaLeft, arenaTop, arenaW, arenaH);
  // Da qui in poi niente esce dall'arena.
  ctx.clip();

  // Le torri, con sopra re, cannone e principesse (quelle distrutte spariscono)
  for (const t of TOWERS) {
    if (distrutta(t)) continue;
    const s  = mapScale * t.scale;
    const cx = toScreenX(t.x);
    const cy = toScreenY(t.y);
    ctx.drawImage(t.img, cx - t.anchorX * s, cy - t.anchorY * s, t.img.width * s, t.img.height * s);
    disegnaSopraTorre(t);   // il re col cannone, o la principessa
  }

  if (DEBUG) {
    drawSolids();
    disegnaRaggiTorri();
    for (const u of UNITA) drawRoute(u);
  }
  drawZonaVietata();
  drawSchieramentiInArrivo();

  // I personaggi vivi stanno sopra le torri e sotto le barre.
  // Chi e' piu' in basso sulla mappa e' piu' vicino a chi guarda: va disegnato
  // dopo. Quindi si mettono in ordine di y, dal piu' in alto al piu' in basso.
  const vivi = [];
  for (const u of UNITA) {
    if (u.alive) vivi.push(u);
  }
  // SERVE A: far sembrare la scena "in profondita'": chi e' piu' in basso e'
  // piu' vicino a chi guarda, quindi viene disegnato dopo e sta davanti.
  vivi.sort(function (a, b) { return a.y - b.y; });
  for (const u of vivi) drawUnita(u);
  disegnaProiettili();   // frecce e palle di cannone volano sopra i personaggi

  // Le barre della vita: prima le torri (non quelle distrutte), poi i personaggi
  for (const t of TOWERS) {
    if (distrutta(t)) continue;
    const s = mapScale * t.scale;
    drawHealthBar(t, toScreenX(t.x), toScreenY(t.y), s);
  }
  for (const u of vivi) barraPersonaggio(u);
  ctx.restore();

  // Prima della partita: attesa dell'avversario o conto alla rovescia.
  // Alla fine: chi ha vinto.
  let messaggio = messaggioPrimaDellaPartita();
  if (messaggio === '') messaggio = messaggioFinePartita();
  if (messaggio !== '') drawMessaggioCentrale(messaggio);
}
