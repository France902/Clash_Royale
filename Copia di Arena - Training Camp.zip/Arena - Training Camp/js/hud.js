// ============================================================
//  js/hud.js - AVVISI, RIGHE DI INFO E PANNELLI DEI GIOCATORI
//
//  A COSA SERVE
//    Tutto il testo intorno al gioco: avvisi brevi ("elisir insufficiente"),
//    la scritta di fine partita, le righe di info in basso a destra e i
//    pannelli con nome, fazione e pulsante Esci dei due giocatori.
//
//  DEFINISCE
//    avviso, avvisoFino, mostraAvviso(), messaggioFinePartita(),
//    descriviUnita(), writeInfo(), ultimiPannelli, aggiornaPannelli(),
//    riempiPannello()
//
//  USA
//    info (js/schermo.js), UNITA, eUnita (js/unita.js), TOWERS,
//    distrutta, partitaFinita (js/torri.js), lobbyAttuale, ultimaOraServer,
//    tickSimulato, partitaIniziata (js/rete.js), hoElisir (js/elisir.js),
//    cartaAttuale (js/mazzo.js), immaginiSopra, proiettiliMancanti
//    (js/sopra_torri.js), FAZIONI, PERSONAGGI, MIA_SQUADRA, DEBUG (da PHP),
//    #pannello-red/#pannello-blue (inc/pagina.php), logout.php (link Esci),
//    css/arena.css (.giocatore...)
//
//  USATO DA
//    js/avvio.js (writeInfo a ogni fotogramma), js/rete.js (mostraAvviso,
//    aggiornaPannelli), js/input.js (mostraAvviso), js/disegno.js
//    (messaggioFinePartita)
// ============================================================

// Messaggio breve in basso (es. "elisir insufficiente").
// Dura 2 secondi VERI (non tick: la simulazione a volte corre per recuperare).
let avviso = '';
let avvisoFino = 0;
function mostraAvviso(testo) {
  avviso = testo;
  // L'avviso resta 2 secondi veri (non tick: la simulazione a volte accelera).
  avvisoFino = performance.now() + 2000;
}

// La scritta grande alla fine della partita ('' = non e' finita)
function messaggioFinePartita() {
  for (const t of TOWERS) {
    if (t.type !== 'king' || !distrutta(t)) continue;
    if (t.team === MIA_SQUADRA) return 'Hai perso!';
    return 'Hai vinto!';
  }
  return '';
}

// Una riga di testo per personaggio, in basso a destra
function descriviUnita(u) {
  let testo = u.nome;
  if (u.team === 'blue') testo += ' blu';
  else                   testo += ' rosso';
  testo += ' #' + u.numero;

  testo += ' | vita: ' + u.hp + ' | ' + u.state;
  if (u.slide !== null) {
    if (u.slide.side < 0) testo += ' (scivola a sinistra)';
    else                  testo += ' (scivola a destra)';
  }
  testo += ' | verso: ' + u.phase;

  const b = u.bersaglio;
  if (b !== null) {
    if (eUnita(b)) testo += ' | attacca il nemico: ';
    else           testo += ' | attacca la torre: ';
    testo += b.hp + '/' + b.maxHp;
  }

  // La direzione in cui guarda: quella dell'attacco se sta attaccando
  if (u.state === 'attack' || u.state === 'reload') testo += ' | ' + u.attackSet;
  else                                             testo += ' | ' + u.set;
  testo += ' | x: ' + Math.round(u.x) + ' y: ' + Math.round(u.y);
  return testo;
}

// SERVE A: mostrare in basso a destra cosa sta facendo ogni personaggio
// (utile per capire il gioco mentre lo sviluppi).
// Nella versione da giocare (DEBUG = false) le righe di controllo non si
// vedono: resta solo l'avviso del momento, es. "Elisir insufficiente".
function writeInfo() {
  if (!DEBUG) {
    if (performance.now() < avvisoFino) info.textContent = avviso;
    else                                info.textContent = '';
    return;
  }

  // Una riga per ogni personaggio vivo
  const righe = [];
  for (const u of UNITA) {
    if (u.alive) righe.push(descriviUnita(u));
  }
  if (righe.length === 0) righe.push('nessun personaggio in campo');
  let testo = righe.join('\n');

  // Chi sta giocando contro chi
  if (lobbyAttuale !== null) {
    const nomi = [];
    for (const g of lobbyAttuale.giocatori) {
      let nome = g.username;
      if (g.squadra === 'blue') nome += ' (blu)';
      else                      nome += ' (rosso)';
      if (g.squadra === MIA_SQUADRA) nome += ' = tu';
      // L'avversario non si fa sentire da piu' di 5 secondi.
      else if (ultimaOraServer - g.visto > 5000) nome += ' - NON RISPONDE';
      nomi.push(nome);
    }
    testo += '\nlobby: ' + nomi.join(' contro ') + ' | tick: ' + tickSimulato;
  }

  if (partitaIniziata() && !partitaFinita() && hoElisir()) {
    testo += '\nclicca nella tua meta\' per schierare: ' + PERSONAGGI[MIA_SQUADRA][cartaAttuale()].name;
  }
  // In debug: le principesse non ancora importate
  if (DEBUG) {
    if (immaginiSopra.red.principessa === null)  testo += '\nmanca la principessa rossa: importala con importa_sprite.php';
    if (immaginiSopra.blue.principessa === null) testo += '\nmanca la principessa blu: importala con importa_sprite.php';
    for (const url of proiettiliMancanti) testo += '\nproiettile non trovato: ' + url;
  }
  if (performance.now() < avvisoFino) testo += '\n' + avviso;
  info.textContent = testo;
}

// ---------- I PANNELLI DEI GIOCATORI ----------
// Il giocatore blu in basso a sinistra, il rosso in alto a sinistra.
// Si rifanno solo quando cambia qualcosa: rifarli ogni 150 ms farebbe
// "perdere" il clic sul pulsante Esci.
let ultimiPannelli = '';

function aggiornaPannelli() {
  // Chi gioca in ogni squadra (null = posto ancora libero)
  const perSquadra = { blue: null, red: null };
  for (const g of lobbyAttuale.giocatori) {
    perSquadra[g.squadra] = g;
  }

  // SERVE A: rifare i pannelli solo quando cambiano i giocatori. Rifarli ogni
  // 150 ms farebbe "perdere" il clic sul pulsante Esci.
  const chiave = JSON.stringify([perSquadra.blue && perSquadra.blue.username,
                                 perSquadra.red  && perSquadra.red.username]);
  if (chiave === ultimiPannelli) return;   // niente di nuovo
  ultimiPannelli = chiave;

  riempiPannello('blue', perSquadra.blue);
  riempiPannello('red',  perSquadra.red);
}

// Riempie il pannello di una squadra. Si usano textContent e createElement
// (non innerHTML): un nome scritto dall'utente non puo' diventare codice HTML.
function riempiPannello(team, giocatore) {
  const pannello = document.getElementById('pannello-' + team);
  // SICUREZZA: i nomi si scrivono come testo, mai come HTML, cosi' un nome
  // "furbo" non puo' diventare codice nella pagina dell'avversario.
  pannello.textContent = '';   // svuota

  if (giocatore === null) {
    const attesa = document.createElement('span');
    attesa.className = 'attesa';
    attesa.textContent = 'In attesa di un avversario...';
    pannello.appendChild(attesa);
    return;
  }

  let fazione = FAZIONI[giocatore.fazione];
  if (!fazione) fazione = { nome: 'Senza fazione', colore: '#888', icona: '⚔️' };
  // Il pannello prende il colore della fazione del giocatore.
  pannello.style.setProperty('--colore', fazione.colore);

  const icona = document.createElement('span');
  icona.textContent = fazione.icona;

  const testi = document.createElement('div');
  const nome = document.createElement('div');
  nome.textContent = giocatore.username;
  if (giocatore.squadra === MIA_SQUADRA) nome.textContent += ' (tu)';
  const nomeFazione = document.createElement('div');
  nomeFazione.className = 'fazione';
  nomeFazione.textContent = fazione.nome;
  testi.appendChild(nome);
  testi.appendChild(nomeFazione);

  pannello.appendChild(icona);
  pannello.appendChild(testi);

  // Il pulsante Esci solo nel proprio pannello
  if (giocatore.squadra === MIA_SQUADRA) {
    const esci = document.createElement('a');
    // Il pulsante Esci, solo nel proprio pannello.
    esci.href = 'logout.php';
    esci.textContent = 'Esci';
    pannello.appendChild(esci);
  }
}
