// ============================================================
//  js/rete.js - SINCRONIZZAZIONE CON IL SERVER
//
//  A COSA SERVE
//    Il collegamento con il server e il cuore della partita in rete:
//      - stima l'ora del server (gli orologi dei due PC non coincidono)
//      - chiede lo stato ogni 150 ms (giocatori, inizio, schieramenti)
//      - fa avanzare la SIMULAZIONE DETERMINISTICA tick per tick: stessi
//        eventi negli stessi tick = stessa partita su entrambi gli schermi
//      - se un evento arriva in ritardo, rifa' la simulazione da capo
//
//  DEFINISCE
//    differenzaOrologio, viaggioMigliore, ultimaOraServer, oraServer(),
//    lobbyAttuale, inizioPartita, eventi, tickSimulato, inAttesa,
//    partitaIniziata(), togliAttesa(), messaggioPrimaDellaPartita(),
//    chiediStato(), riceviEventi(), resetArena(), ricominciaDaCapo(),
//    avanzaFinoA()
//
//  USA
//    server: arena.php?azione=stato (inc/api.php, dati da lobby.json)
//    schiera() e UNITA (js/unita.js), update() (js/movimento.js),
//    preparaDifese() (js/difese.js), mostraAvviso(), aggiornaPannelli()
//    (js/hud.js), colorDots(), placeDots(), rimuoviPartenze()
//    (js/segnaposto.js), TOWERS
//
//  USATO DA
//    js/avvio.js (chiediStato, avanzaFinoA, resetArena, oraServer...),
//    js/input.js, js/elisir.js, js/disegno.js, js/hud.js
//  ANTENATO
//    prova_movimento_latenza.php: la posizione si ricava dal tempo.
// ============================================================

// ---------- L'OROLOGIO DEL SERVER ----------
// Gli orologi dei due computer non segnano la stessa ora: si usa quella del
// server. Ad ogni risposta si stima la differenza tra il nostro orologio e il
// suo. La risposta ci mette un po' ad arrivare: si suppone che l'andata e il
// ritorno durino uguale, quindi l'ora del server "adesso" e' quella che ci ha
// mandato piu' meta' del viaggio. Si tiene la stima del viaggio piu' veloce
// (quella con meno incertezza).
let differenzaOrologio = 0;      // ora del server - ora nostra (millisecondi)
let viaggioMigliore = Infinity;  // il viaggio piu' veloce visto finora
let ultimaOraServer = 0;         // l'ultima ora ricevuta dal server

// L'ora del server stimata, uguale per entrambi i giocatori.
function oraServer() {
  return Date.now() + differenzaOrologio;
}

// ---------- LO STATO DELLA PARTITA ----------
let lobbyAttuale  = null;   // la lobby ricevuta dal server (null = non ancora arrivata)
let inizioPartita = null;   // ora (del server) in cui e' partita la partita
// Tutti gli schieramenti della partita, in ordine.
let eventi        = [];     // gli schieramenti: { squadra, carta, costo, x, y, clic, tick, cid }
let tickSimulato  = 0;      // fin dove e' arrivata la nostra simulazione
let inAttesa      = [];     // i miei clic non ancora confermati: { x, y, carta, costo, cid }

function partitaIniziata() {
  return inizioPartita !== null && oraServer() >= inizioPartita;
}

// Toglie dai clic in attesa quello con questo numero di ricevuta (se c'e')
function togliAttesa(cid) {
  for (let i = 0; i < inAttesa.length; i++) {
    if (inAttesa[i].cid === cid) {
      // Il clic e' stato confermato: non e' piu' "in attesa".
      inAttesa.splice(i, 1);
      return;
    }
  }
}

// Il testo grande al centro prima della partita ('' = niente)
function messaggioPrimaDellaPartita() {
  if (lobbyAttuale === null) return 'Connessione...';
  if (inizioPartita === null) return 'In attesa di un avversario...';
  const mancano = inizioPartita - oraServer();
  if (mancano > 0) return 'Si parte tra ' + Math.ceil(mancano / 1000) + '...';
  return '';
}

// ---------- CHIEDERE LO STATO AL SERVER ----------
// Come nel test del movimento sincronizzato: si chiede continuamente al server
// lo stato. Qui ogni 150 ms basta, perche' gli schieramenti valgono 1 secondo
// dopo il clic: c'e' tutto il tempo di riceverli.
let richiestaInCorso = false;

async function chiediStato() {
  // Una richiesta alla volta: non si accumulano richieste se il server e' lento.
  if (richiestaInCorso) return;   // una richiesta alla volta
  richiestaInCorso = true;
  try {
    const partenza = Date.now();
    // Chiede al server l'ora e lo stato della partita.
    const risposta = await fetch('?azione=stato');
    const dati = await risposta.json();
    const arrivo = Date.now();

    // Aggiorna la stima dell'orologio del server
    const viaggio = arrivo - partenza;
    if (viaggio <= viaggioMigliore) {
      viaggioMigliore = viaggio;
      // SERVE A: capire di quanto il nostro orologio e' avanti o indietro rispetto
      // al server. La risposta ha viaggiato per meta' del tempo totale, quindi
      // l'ora del server "adesso" e' quella ricevuta + meta' viaggio.
      differenzaOrologio = (dati.ora + viaggio / 2) - arrivo;
    }
    ultimaOraServer = dati.ora;

    // La lobby non c'e' piu' (l'avversario e' uscito): si ricarica la pagina
    // e si entra in una lobby nuova, in attesa di un altro avversario
    if (dati.lobby === null) {
      mostraAvviso('L\'avversario e\' uscito: nuova lobby...');
      // L'avversario e' uscito: dopo 1,5 secondi si ricarica la pagina e si
      // entra in una nuova lobby. (Il return sotto salta "richiestaInCorso = false",
      // ma non importa perche' la pagina si ricarica.)
      setTimeout(function () { location.reload(); }, 1500);
      return;
    }

    // L'ora d'inizio e' cambiata mentre si giocava: qualcuno ha premuto
    // "Ricomincia" (inc/api.php, ?azione=ricomincia). Si riparte da zero.
    if (inizioPartita !== null && dati.lobby.inizio !== inizioPartita) {
      ricominciaDaCapo();
    }

    lobbyAttuale  = dati.lobby;
    inizioPartita = dati.lobby.inizio;
    aggiornaPannelli();
    riceviEventi(dati.lobby.eventi);
  } catch (err) {
    mostraAvviso('Connessione al server persa, riprovo...');
  }
  richiestaInCorso = false;
}

// Arrivano gli schieramenti dal server. Il server li aggiunge solo in fondo,
// quindi quelli nuovi sono quelli dopo i vecchi.
// SERVE A: aggiungere gli schieramenti nuovi arrivati dal server.
function riceviEventi(nuovi) {
  if (nuovi.length === eventi.length) return;   // niente di nuovo

  // Uno schieramento nuovo doveva gia' succedere (e' arrivato in ritardo)?
  // Allora la simulazione e' sbagliata: si rifa' tutto da capo, dal tick 0.
  let daRifare = false;
  for (let i = eventi.length; i < nuovi.length; i++) {
    // SERVE A: correggere un ritardo. Se uno schieramento arriva quando il suo
    // momento e' gia' passato, la partita si rigioca da capo in un attimo (solo
    // calcoli, niente disegni), cosi' il risultato e' uguale per entrambi.
    if (nuovi[i].tick < tickSimulato) daRifare = true;
    if (nuovi[i].squadra === MIA_SQUADRA) togliAttesa(nuovi[i].cid);   // il mio e' arrivato
  }
  eventi = nuovi;
  if (daRifare) {
    resetArena();
    tickSimulato = 0;
  }
}

// ---------- NUOVA PARTITA ----------
// Torri a vita piena e campo vuoto (si usa anche per rifare la simulazione da capo)
function resetArena() {
  for (const t of TOWERS) {
    t.hp = t.maxHp;
  }
  // Toglie tutti i personaggi dal campo.
  UNITA.length = 0;          // via tutti i personaggi...
  rimuoviPartenze();         // ...e i loro segnaposto di partenza
  preparaDifese();           // torri pronte, nessun proiettile in volo
  colorDots();
  placeDots();
}

// ---------- RICOMINCIARE ----------
// SERVE A: dimenticare la partita vecchia quando il server ne fa partire una
// nuova. Esempio: al minuto 2 il re rosso ha meta' vita e ci sono 4 personaggi
// in campo; uno dei due preme "Ricomincia" -> entrambi i browser svuotano il
// campo, rimettono le torri a vita piena e ripartono dal tick 0 (dopo il conto
// alla rovescia). L'elisir torna pieno da solo: si ricalcola dagli eventi, che
// adesso non ci sono piu'.
function ricominciaDaCapo() {
  eventi = [];
  inAttesa = [];          // i clic non confermati appartenevano alla partita vecchia
  resetArena();
  tickSimulato = 0;
  mostraAvviso('Partita ricominciata!');
}

// ---------- LA SIMULAZIONE ----------
// Porta la simulazione fino al tick "obiettivo". A ogni tick: prima gli
// schieramenti di quel tick (nell'ordine del server), poi un passo di
// logica. Stessi eventi negli stessi tick = stesso risultato.
// SERVE A: portare la partita fino al momento attuale, un tick alla volta.
// Se il computer e' rimasto indietro, recupera tutti i tick mancanti.
function avanzaFinoA(obiettivo) {
  while (tickSimulato < obiettivo) {
    for (const e of eventi) {
      if (e.tick === tickSimulato) {
        schiera(e.squadra, e.x, e.y, e.carta);
        colorDots();
        placeDots();
      }
    }
    update();
    tickSimulato++;
  }
}
