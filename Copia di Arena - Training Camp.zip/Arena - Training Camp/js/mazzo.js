// ============================================================
//  js/mazzo.js - IL MAZZO: LE CARTE CHE POSSO SCHIERARE
//
//  A COSA SERVE
//    A sinistra della mappa c'e' una pila di bottoni, uno per carta, con il
//    nome del personaggio e il suo costo. La carta scelta e' evidenziata e si
//    cambia cliccando un bottone o con le frecce della tastiera. Un bottone
//    diventa sbiadito quando non c'e' abbastanza elisir per quella carta.
//    Il clic sulla mappa schiera sempre la carta scelta qui.
//
//  DEFINISCE
//    MAZZO, cartaScelta, pilaCarte, bottoniCarte, cartaAttuale(),
//    scegliCarta(), creaPilaCarte(), tastoPremuto(), posizionaPilaCarte(),
//    aggiornaPilaCarte()
//
//  USA
//    MAZZI, MIA_SQUADRA, PERSONAGGI (da PHP: inc/config.php e
//    inc/personaggi.php), #carte (inc/pagina.php), mapLeft (js/schermo.js),
//    hoElisir() (js/elisir.js), lo stile #carte in css/arena.css
//
//  USATO DA
//    js/input.js (cartaAttuale: quale carta schierare), js/elisir.js e
//    js/hud.js (cartaAttuale), js/schermo.js (posizionaPilaCarte),
//    js/avvio.js (creaPilaCarte, aggiornaPilaCarte, tastoPremuto sui tasti)
// ============================================================

// Solo le MIE carte: l'avversario non vede (e non puo' scegliere) le mie.
const MAZZO = MAZZI[MIA_SQUADRA];   // le mie carte, in ordine (es. ['mini_pekka', 'knight'])
// Si ricorda la POSIZIONE della carta scelta (0 = la prima), non il nome:
// cosi' "carta dopo" e "carta prima" sono solo +1 e -1.
let cartaScelta = 0;                // il posto della carta scelta nel mazzo

const pilaCarte = document.getElementById('carte');
const bottoniCarte = [];            // un bottone per carta, nello stesso ordine del mazzo

// La carta scelta adesso (es. 'knight')
function cartaAttuale() {
  return MAZZO[cartaScelta];
}

// Sceglie la carta al posto i. Si gira in tondo: dopo l'ultima torna la prima.
// SERVE A: cambiare carta ed evidenziare il bottone giusto.
// Si gira in tondo: dall'ultima carta "avanti" torna alla prima, e dalla
// prima "indietro" va all'ultima (il + MAZZO.length evita i numeri negativi).
function scegliCarta(i) {
  cartaScelta = (i + MAZZO.length) % MAZZO.length;   // % = resto: tiene i tra 0 e il numero di carte
  for (let j = 0; j < bottoniCarte.length; j++) {
    // Il bottone della carta scelta prende la classe "scelta", gli altri la perdono.
    bottoniCarte[j].classList.toggle('scelta', j === cartaScelta);
  }
}

// Crea un bottone per ogni carta: nome del personaggio e costo nella goccia.
// textContent (non innerHTML): un nome nel JSON non puo' diventare codice HTML.
// SERVE A: creare i bottoni delle carte una volta sola, all'avvio.
function creaPilaCarte() {
  for (let i = 0; i < MAZZO.length; i++) {
    const cfg = PERSONAGGI[MIA_SQUADRA][MAZZO[i]];

    const bottone = document.createElement('button');
    bottone.type = 'button';
    const nome = document.createElement('span');
    nome.textContent = cfg.name;
    const costo = document.createElement('span');
    costo.className = 'costo';
    costo.textContent = cfg.elixir;
    bottone.appendChild(nome);
    bottone.appendChild(costo);

    // Ogni bottone ricorda il suo numero i: cliccandolo si sceglie quella carta.
    bottone.addEventListener('click', function () {
      scegliCarta(i);
      // Senza blur il bottone resterebbe "selezionato" e le frecce lo attiverebbero.
      bottone.blur();   // il bottone non resta "attivo": le frecce continuano a funzionare
    });
    pilaCarte.appendChild(bottone);
    bottoniCarte.push(bottone);
  }
  scegliCarta(0);
}

// Le frecce cambiano carta: su/sinistra = quella prima, giu'/destra = quella dopo
// SERVE A: cambiare carta senza staccare la mano dalla tastiera.
// evento.key dice quale tasto e' stato premuto ('ArrowUp', 'ArrowDown'...).
function tastoPremuto(evento) {
  let passo = 0;
  if (evento.key === 'ArrowUp'   || evento.key === 'ArrowLeft')  passo = -1;
  if (evento.key === 'ArrowDown' || evento.key === 'ArrowRight') passo = 1;
  if (passo === 0) return;
  // Senza questa riga le frecce farebbero anche scorrere la pagina.
  evento.preventDefault();          // le frecce non fanno scorrere la pagina
  scegliCarta(cartaScelta + passo);
}

// Mette la pila nello spazio vuoto a sinistra della mappa, a meta' altezza
// (la chiama layout() quando cambia la finestra)
// SERVE A: adattare la larghezza dei bottoni allo spazio libero a sinistra
// della mappa, che cambia con la grandezza della finestra.
function posizionaPilaCarte() {
  const larghezza = Math.max(Math.min(mapLeft - 20, 190), 100);   // tra 100 e 190 pixel
  pilaCarte.style.width = larghezza + 'px';
}

// A ogni fotogramma: sbiadisce le carte che adesso non posso permettermi
// SERVE A: farti vedere a colpo d'occhio cosa puoi schierare adesso: le carte
// troppo care diventano sbiadite (classe "scarica" in css/arena.css).
function aggiornaPilaCarte() {
  for (let i = 0; i < MAZZO.length; i++) {
    bottoniCarte[i].classList.toggle('scarica', !hoElisir(MAZZO[i]));
  }
}
