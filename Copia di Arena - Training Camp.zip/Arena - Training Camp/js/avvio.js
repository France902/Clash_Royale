// ============================================================
//  js/avvio.js - CARICAMENTO E CICLO DI ANIMAZIONE
//
//  A COSA SERVE
//    L'ULTIMO script caricato: carica tutte le immagini, prepara segnaposto,
//    barra dell'elisir, pila delle carte e dimensioni, collega gli eventi
//    (resize, clic, frecce), avvia le richieste al server e il ciclo di
//    animazione. Il ciclo, a ogni fotogramma: porta la simulazione al tick
//    attuale, disegna, aggiorna scritte, barra dell'elisir e carte.
//
//  DEFINISCE
//    loop(), loadImage(), caricaTutte(), avvio()
//
//  USA (praticamente tutto)
//    MAP_URL, BARS, TOWERS, PERSONAGGI, MAZZI, TICK_RATE (da PHP), DIREZIONI
//    e sezionePer (js/direzioni.js), SPRITE (js/unita.js), mapImg, barImgs,
//    layout, canvas, info (js/schermo.js), caricaSopraTorri
//    (js/sopra_torri.js), creaSegnaposto (js/segnaposto.js),
//    creaBarraElisir, aggiornaBarraElisir (js/elisir.js), creaPilaCarte,
//    aggiornaPilaCarte, tastoPremuto (js/mazzo.js), clicGiocatore
//    (js/input.js), resetArena, chiediStato, avanzaFinoA, oraServer,
//    inizioPartita (js/rete.js), draw (js/disegno.js), writeInfo (js/hud.js)
//
//  USATO DA
//    loadImage e caricaTutte anche da js/sopra_torri.js
// ============================================================

// ---------- ANIMAZIONE ----------
// Il browser chiama loop() a ogni fotogramma dello schermo (60, 144... volte al secondo).
// A che tick siamo NON lo decide il nostro computer: si calcola dall'ora del
// server, quindi e' lo stesso tick per tutti e due i giocatori.
// SERVE A: aggiornare e ridisegnare il gioco a ogni fotogramma dello schermo.
function loop() {
  if (inizioPartita !== null) {
    // SERVE A: sapere che momento della partita e' ADESSO, calcolandolo dall'ora del
    // server: entrambi i giocatori ottengono lo stesso numero.
    const tickAdesso = Math.floor((oraServer() - inizioPartita) * TICK_RATE / 1000);
    avanzaFinoA(tickAdesso);
  }

  draw();
  writeInfo();
  aggiornaBarraElisir();
  // Sbiadisce le carte che adesso non ci si puo' permettere.
  aggiornaPilaCarte();
  requestAnimationFrame(loop);   // richiama loop() al prossimo fotogramma
}

// ---------- AVVIO ----------

// Carica un'immagine. Una "Promise" e' una promessa di risultato:
// l'immagine arriva dopo un po', e "await" aspetta che arrivi.
// SERVE A: poter ASPETTARE che un'immagine sia caricata prima di usarla.
function loadImage(src) {
  return new Promise(function (ok, errore) {
    const img = new Image();
    img.onload  = function () { ok(img); };
    img.onerror = function () { errore(new Error('Immagine non trovata: ' + src)); };
    img.src = src;
  });
}

// Carica tutte le immagini di una lista (insieme) e aspetta che arrivino tutte
function caricaTutte(indirizzi) {
  const promesse = [];
  for (const url of indirizzi) {
    promesse.push(loadImage(url));
  }
  // Carica tutte le immagini di una lista insieme e aspetta che siano pronte.
  return Promise.all(promesse);
}

// SERVE A: preparare tutto prima di far partire il gioco. Se manca
// un'immagine, il messaggio lo dice in basso.
async function avvio() {
  try {
    // 1) Le immagini
    // Prima la mappa e le barre della vita.
    mapImg = await loadImage(MAP_URL);

    barImgs = {
      base: await loadImage(BARS.base),
      red:  await loadImage(BARS.red),
      blue: await loadImage(BARS.blue)
    };

    // Camminate e attacchi di tutte le 6 direzioni, una volta per ogni carta
    // di ogni mazzo: li usano tutti i personaggi di quella carta
    for (const team of ['blue', 'red']) {
      // Per ogni carta del mazzo di ogni squadra: le sue animazioni in tutte le direzioni.
      for (const carta of MAZZI[team]) {
        const cfg = PERSONAGGI[team][carta];
        SPRITE[team][carta] = { walk: {}, attack: {} };
        for (const d in DIREZIONI) {
          const camminata = sezionePer(cfg, d, 'walk');
          const attacco   = sezionePer(cfg, d, 'attack');
          SPRITE[team][carta].walk[d] = await caricaTutte(camminata.urls);
          if (attacco !== null) SPRITE[team][carta].attack[d] = await caricaTutte(attacco.urls);
          else                  SPRITE[team][carta].attack[d] = [];   // nessun attacco
        }
      }
    }

    for (const t of TOWERS) {
      t.img   = await loadImage(t.url);
      // La vita piena di ogni torre (per le barre e per ricominciare).
      t.maxHp = t.hp;               // la vita iniziale e' anche quella massima
    }
    await caricaSopraTorri();       // re, cannoni e principesse

    // 2) I segnaposto di controllo, la barra dell'elisir e le carte
    creaSegnaposto();
    creaBarraElisir();
    creaPilaCarte();

    // 3) Posizioni, eventi e primo giro
    layout();
    // Se la finestra cambia grandezza, si ricalcolano dimensioni e posizioni.
    window.addEventListener('resize', layout);       // finestra ridimensionata = rifai i calcoli
    canvas.addEventListener('click', clicGiocatore); // clic = schiera la carta scelta
    // Le frecce della tastiera cambiano carta (js/mazzo.js).
    window.addEventListener('keydown', tastoPremuto); // frecce = cambia carta
    // Il bottone in basso a destra fa ripartire la partita (js/ricomincia.js).
    bottoneRicomincia.addEventListener('click', ricominciaPartita);

    resetArena();   // si parte con il campo vuoto

    // 4) Si chiede lo stato al server ogni 150 ms, e si parte
    chiediStato();
    // Chiede lo stato al server ogni 150 ms: abbastanza, perche' un personaggio
    // compare 1 secondo dopo il clic.
    setInterval(chiediStato, 150);
    requestAnimationFrame(loop);
  } catch (err) {
    info.textContent = err.message;   // se un'immagine manca, lo scrive in basso
  }
}

// Parte tutto da qui.
avvio();
