// ============================================================
//  js/torri.js - TORRI E QUADRATI DI ATTACCO
//
//  A COSA SERVE
//    Collega ogni blocco solido alla sua torre e prepara, per ogni squadra,
//    i "quadrati di attacco": i punti davanti alle torri avversarie dove un
//    personaggio si ferma per colpirle. Sa anche quando la partita e' finita.
//
//  DEFINISCE
//    distrutta(), QUADRATI_TORRE, partitaFinita()
//    e aggiunge il campo .torre a SOLIDS[i] e ai quadrati di ASSI
//
//  USA
//    TOWERS, SOLIDS, ASSI, QUADRATI_RE (da PHP), piuVicino() (js/utilita.js)
//
//  USATO DA
//    js/solidi.js, js/unita.js (QUADRATI_TORRE), js/obiettivi.js,
//    js/attacco.js, js/movimento.js, js/difese.js, js/disegno.js,
//    js/sopra_torri.js, js/hud.js, js/input.js, js/segnaposto.js
//
//  NOTA: i cicli qui sotto girano SUBITO al caricamento del file.
// ============================================================

// Una torre e' distrutta quando la sua vita e' a zero
// Una torre a vita zero sparisce: non si disegna, non spara, non blocca piu'.
function distrutta(t) {
  return t.hp <= 0;
}

// Ogni blocco solido "sa" a quale torre appartiene (sono nello stesso ordine)
// SERVE A: collegare ogni blocco solido alla sua torre, cosi' il blocco "sa"
// quando la torre e' distrutta e smette di bloccare.
for (let i = 0; i < SOLIDS.length; i++) {
  SOLIDS[i].torre = TOWERS[i];
}

// Per ogni squadra: i quadrati da cui attacca le torri avversarie.
// Ogni quadrato "sa" quale torre si attacca da li': quadrato.torre
// SERVE A: sapere, per ogni squadra, da dove si attacca ogni torre nemica.
const QUADRATI_TORRE = { blue: [], red: [] };

for (const team of ['blue', 'red']) {
  // Le torri avversarie, divise tra principesse e re
  const principesse = [];
  let re = null;
  for (const t of TOWERS) {
    if (t.team === team) continue;          // le proprie torri non si attaccano
    if (t.type === 'king') re = t;
    else                   principesse.push(t);
  }

  // I quadrati delle corsie: davanti alla torre principessa piu' vicina
  for (const asse of ASSI[team]) {
    const q = asse.tower;
    // Ogni punto d'arrivo di una corsia attacca la principessa piu' vicina.
    q.torre = piuVicino(principesse, q.x, q.y);
    QUADRATI_TORRE[team].push(q);
  }

  // I quadrati intorno al re. "Verso il centro" e' in giu' per il re rosso
  // (che sta in alto) e in su per il re blu (che sta in basso).
  // I due re sono uno in alto e uno in basso: "davanti" al re rosso e' piu'
  // in basso, davanti al re blu e' piu' in alto.
  let verso = 1;
  if (re.team === 'blue') verso = -1;
  for (const spostamento of QUADRATI_RE) {
    QUADRATI_TORRE[team].push({
      x: re.x + spostamento[0],
      y: re.y + verso * spostamento[1],
      torre: re
    });
  }
}

// La partita e' finita quando un re e' distrutto: da li' nessuno si muove piu'
// SERVE A: fermare tutto quando cade un re.
function partitaFinita() {
  for (const t of TOWERS) {
    if (t.type === 'king' && distrutta(t)) return true;
  }
  return false;
}
