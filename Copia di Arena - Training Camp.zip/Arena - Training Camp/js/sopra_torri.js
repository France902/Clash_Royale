// ============================================================
//  SCHEDA DEL FILE: js/sopra_torri.js
//
//  A COSA SERVE
//    Carica e disegna cio' che sta SOPRA le torri (re, cannone con la sua
//    base, principesse animate) e i proiettili in volo. In debug disegna
//    anche il raggio di tiro delle torri.
//
//  DEFINISCE
//    PEZZI, immaginiSopra, proiettiliMancanti, contenuto(), unione(),
//    caricaPezzo(), caricaProiettile(), caricaPrincipessa(),
//    caricaSopraTorri(), ingrandimento(), disegnaPezzo(), disegnaSu(),
//    disegnaCannone(), framePrincipessa(), disegnaSopraTorre(),
//    disegnaProiettili(), disegnaRaggiTorri()
//
//  USA
//    SOPRA_TORRI (inc/prepara.php), DIFESE (inc/difese.php),
//    loadImage(), caricaTutte() (js/avvio.js), ctx, mapScale, toScreenX/Y
//    (js/schermo.js), proiettili, t.difesa, t.arma (js/difese.js)
//
//  USATO DA
//    js/avvio.js   (await caricaSopraTorri)
//    js/disegno.js (disegnaSopraTorre, disegnaProiettili, disegnaRaggiTorri)
//    js/hud.js     (immaginiSopra, proiettiliMancanti: avvisi in debug)
// ============================================================
// ============================================================
//  SOPRA LE TORRI: il re e il suo cannone sulla torre del re, la
//  principessa (con la sua animazione) sulle torri principessa, e i
//  proiettili in volo
//
//  I PNG hanno tanto spazio trasparente intorno al disegno. All'avvio si
//  cerca il rettangolo che contiene il disegno vero (contenuto()) e si usa
//  solo quello: cosi' posizione e altezza scritte in inc/config.php valgono
//  per il disegno, qualunque sia il bordo vuoto del PNG.
// ============================================================

const PEZZI = SOPRA_TORRI.pezzi;   // posizioni e grandezze (inc/config.php)

// Le immagini caricate, ognuna con il rettangolo del suo disegno:
// { base, red: { re, cannone, principessa, freccia, palla }, blue: { ... } }
// Le immagini di re, cannoni, principesse e proiettili, una volta caricate.
let immaginiSopra = null;

// I PNG dei proiettili che non si trovano: il gioco va avanti lo stesso
// (il danno arriva comunque), ma in debug si scrive quali mancano
const proiettiliMancanti = [];

// Il rettangolo del disegno vero dentro un'immagine: { x, y, w, h }.
// Si disegna l'immagine su una tela nascosta e si guarda ogni pixel:
// si tengono il primo e l'ultimo pixel non trasparente, in orizzontale e in verticale.
function contenuto(img) {
  const tela = document.createElement('canvas');
  tela.width  = img.naturalWidth;
  tela.height = img.naturalHeight;
  const c = tela.getContext('2d');
  c.drawImage(img, 0, 0);
  // SERVE A: leggere i pixel dell'immagine per trovare dove inizia e finisce
  // il disegno vero, ignorando i bordi trasparenti.
  const pixel = c.getImageData(0, 0, tela.width, tela.height).data;   // 4 numeri per pixel: rosso, verde, blu, trasparenza

  let minX = tela.width, minY = tela.height, maxX = -1, maxY = -1;
  for (let y = 0; y < tela.height; y++) {
    for (let x = 0; x < tela.width; x++) {
      // La trasparenza del pixel (x, y): 0 = invisibile, 255 = pieno.
      const alfa = pixel[(y * tela.width + x) * 4 + 3];
      if (alfa > 10) {                 // quasi trasparente = vuoto
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
      }
    }
  }
  if (maxX < 0) return { x: 0, y: 0, w: tela.width, h: tela.height };   // tutta trasparente
  return { x: minX, y: minY, w: maxX - minX + 1, h: maxY - minY + 1 };
}

// Il rettangolo piu' piccolo che contiene tutti e due i rettangoli
function unione(a, b) {
  const x = Math.min(a.x, b.x);
  const y = Math.min(a.y, b.y);
  return {
    x: x,
    y: y,
    w: Math.max(a.x + a.w, b.x + b.w) - x,
    h: Math.max(a.y + a.h, b.y + b.h) - y
  };
}

// Carica un'immagine e trova subito il suo disegno vero (null = non c'e')
// SERVE A: caricare un'immagine e trovarne subito il disegno vero.
async function caricaPezzo(url) {
  if (url === null) return null;
  const img = await loadImage(url);
  return { img: img, box: contenuto(img) };
}

// Come caricaPezzo, ma se il PNG non c'e' non blocca il gioco
async function caricaProiettile(url) {
  try {
    // SERVE A: se il PNG del proiettile manca, il gioco va avanti lo stesso
    // (il danno arriva comunque, solo non si vede la freccia).
    // L'await qui e' necessario perche' il catch sotto intercetti l'errore.
    return await caricaPezzo(url);
  } catch (err) {
    // Si annota il file mancante (senza ?v=...) per l'avviso in debug.
    proiettiliMancanti.push(url.split('?')[0]);   // l'indirizzo senza ?v=...
    return null;
  }
}

// La principessa di una squadra: la posa ferma e i frame delle 3 pose d'attacco.
// Per tutti i frame si usa UN SOLO rettangolo (l'unione dei disegni): cosi'
// la principessa non "balla" passando da un frame all'altro.
// null = non ancora importata con importa_sprite.php.
async function caricaPrincipessa(team) {
  const sezioni = DIFESE[team].princess.sezioni;
  if (manca(sezioni.idle) && manca(sezioni.attack)) return null;

  const p = { idle: null, frames: {}, box: null };
  for (const nome of ['attack', 'attackRight', 'attackLeft']) {
    if (!manca(sezioni[nome])) p.frames[nome] = await caricaTutte(sezioni[nome]);
  }
  // La principessa ferma: la posa "idle" se c'e', altrimenti il primo frame dell'attacco.
  if (!manca(sezioni.idle)) p.idle = (await caricaTutte(sezioni.idle))[0];
  else                      p.idle = p.frames.attack[0];   // la posa ferma e' il primo frame di "attacca di fronte"

  p.box = contenuto(p.idle);
  for (const nome in p.frames) {
    // SERVE A: evitare che la principessa "balli": tutti i frame usano lo stesso riquadro.
    for (const img of p.frames[nome]) p.box = unione(p.box, contenuto(img));
  }
  return p;
}

async function caricaSopraTorri() {
  immaginiSopra = { base: await caricaPezzo(SOPRA_TORRI.base) };
  for (const team of ['red', 'blue']) {
    immaginiSopra[team] = {
      re:          await caricaPezzo(SOPRA_TORRI[team].re),
      cannone:     await caricaPezzo(SOPRA_TORRI[team].cannone),
      principessa: await caricaPrincipessa(team),
      freccia:     await caricaProiettile(DIFESE[team].princess.projectile.url),
      palla:       await caricaProiettile(DIFESE[team].king.projectile.url)
    };
  }
}

// Quanto ingrandire un pezzo perche' il suo disegno sia alto "altezza" pixel della mappa
function ingrandimento(pezzo, altezza) {
  return altezza / pezzo.box.h;
}

// Disegna solo il disegno vero di un pezzo, con il CENTRO nel punto (mx, my)
// della mappa. k = pixel della mappa per ogni pixel del PNG.
// Disegna solo la parte utile dell'immagine, centrata sul punto della mappa.
function disegnaPezzo(pezzo, mx, my, k) {
  const s = k * mapScale;
  const w = pezzo.box.w * s;
  const h = pezzo.box.h * s;
  ctx.drawImage(pezzo.img,
                pezzo.box.x, pezzo.box.y, pezzo.box.w, pezzo.box.h,   // il pezzo del PNG
                toScreenX(mx) - w / 2, toScreenY(my) - h / 2, w, h);  // dove disegnarlo
}

// Disegna un pezzo (re o principessa) nella sua posizione sopra la torre t
function disegnaSu(t, pezzo, impostazioni) {
  const pos = impostazioni.posizione[t.team];
  disegnaPezzo(pezzo, t.x + pos[0], t.y + pos[1], ingrandimento(pezzo, impostazioni.altezza));
}

// Il cannone con la sua base sotto. La base si ingrandisce come il cannone,
// cosi' i due restano in proporzione tra loro.
function disegnaCannone(t) {
  const cannone = immaginiSopra[t.team].cannone;
  const pos  = PEZZI.cannone.posizione[t.team];
  const base = PEZZI.cannone.base;
  const k = ingrandimento(cannone, PEZZI.cannone.altezza);
  disegnaPezzo(immaginiSopra.base, t.x + pos[0] + base[0], t.y + pos[1] + base[1], k);
  disegnaPezzo(cannone, t.x + pos[0], t.y + pos[1], k);
}

// Il frame della principessa adesso:
//   - durante il colpo: il frame dell'animazione, nella posa verso il nemico
//   - tra un colpo e l'altro (nemico ancora a portata): il primo frame di quella posa
//   - nessun nemico: la posa ferma
function framePrincipessa(t, p) {
  const d = t.difesa;
  let frames = p.frames[d.direzione];
  if (manca(frames)) frames = p.frames.attack;
  if (manca(frames)) return p.idle;

  if (d.stato === 'attacco') return frames[Math.min(d.frame, frames.length - 1)];
  if (d.bersaglio !== null)  return frames[0];
  return p.idle;
}

// Quello che sta sopra una torre (la torre e' appena stata disegnata)
function disegnaSopraTorre(t) {
  const pezzi = immaginiSopra[t.team];

  if (t.type === 'king') {
    // Prima chi sta piu' in alto sulla mappa: chi e' piu' in basso e' piu'
    // vicino a chi guarda, quindi gli sta davanti
    // Chi sta piu' in alto si disegna prima, chi sta piu' in basso gli passa davanti.
    if (PEZZI.re.posizione[t.team][1] < PEZZI.cannone.posizione[t.team][1]) {
      disegnaSu(t, pezzi.re, PEZZI.re);
      disegnaCannone(t);
    } else {
      disegnaCannone(t);
      disegnaSu(t, pezzi.re, PEZZI.re);
    }
    return;
  }

  // Torre principessa: la principessa, se e' gia' stata importata
  const p = pezzi.principessa;
  if (p === null) return;
  // La principessa nel frame giusto (ferma, in attesa o mentre tira).
  disegnaSu(t, { img: framePrincipessa(t, p), box: p.box }, PEZZI.principessa);
}

// ---------- I PROIETTILI ----------
// Ogni proiettile sta sulla linea tra la partenza e l'arrivo, a che punto
// del viaggio e' arrivato, girato nella direzione del volo
function disegnaProiettili() {
  for (const p of proiettili) {
    const t = p.torre;
    let pezzo = immaginiSopra[t.team].freccia;
    if (t.type === 'king') pezzo = immaginiSopra[t.team].palla;
    if (pezzo === null) continue;                      // PNG mancante: si vede solo il danno
    const cfg = DIFESE[t.team][t.type].projectile;

    // A che punto del viaggio e' il proiettile: 0 = appena partito, 1 = arrivato.
    const fatto = p.tick / p.viaggio;                  // 0 = appena partito, 1 = arrivato
    const mx = p.da.x + (p.a.x - p.da.x) * fatto;
    const my = p.da.y + (p.a.y - p.da.y) * fatto;

    // Grandezza: il lato piu' lungo del disegno diventa lungo "size" pixel della mappa
    const s = oppure(cfg.size, 20) / Math.max(pezzo.box.w, pezzo.box.h) * mapScale;
    const w = pezzo.box.w * s;
    const h = pezzo.box.h * s;

    // Rotazione: la direzione del volo, meno quella in cui punta gia' il PNG
    // (gradi -> radianti: * PI / 180)
    ctx.save();
    // SERVE A: girare la freccia nella direzione in cui vola, su se' stessa.
    ctx.translate(toScreenX(mx), toScreenY(my));
    ctx.rotate((p.angolo - oppure(cfg.imageAngle, 0)) * Math.PI / 180);
    ctx.drawImage(pezzo.img, pezzo.box.x, pezzo.box.y, pezzo.box.w, pezzo.box.h, -w / 2, -h / 2, w, h);
    ctx.restore();
  }
}

// Il raggio di ogni torre in piedi, tratteggiato (solo in debug)
function disegnaRaggiTorri() {
  ctx.save();
  ctx.lineWidth = 1.5;
  ctx.setLineDash([4, 6]);
  for (const t of TOWERS) {
    if (distrutta(t)) continue;
    if (t.team === 'blue') ctx.strokeStyle = 'rgba(58, 176, 255, .7)';
    else                   ctx.strokeStyle = 'rgba(255, 70, 70, .7)';
    ctx.beginPath();
    ctx.arc(toScreenX(t.x), toScreenY(t.y), t.arma.range * mapScale, 0, 2 * Math.PI);
    ctx.stroke();
  }
  ctx.restore();
}
