// ============================================================
//  js/segnaposto.js - I SEGNAPOSTO DI DEBUG
//
//  A COSA SERVE
//    Cerchi e quadrati colorati (div HTML sopra il canvas) che mostrano i
//    punti delle corsie, i quadrati d'attacco e i punti di partenza. Si
//    vedono solo con $debug = true (inc/config.php).
//
//  DEFINISCE
//    segnaposto, aggiungiSegnaposto(), creaSegnaposto(), rimuoviPartenze(),
//    placeDots(), colorDots()
//
//  USA
//    DEBUG, ASSI, SQUARE, DOT_SIZE (da PHP), QUADRATI_TORRE (js/torri.js),
//    UNITA (js/unita.js), mapScale, toScreenX/Y (js/schermo.js)
//    le classi .punto, .ponte, .ingresso... di css/arena.css
//
//  USATO DA
//    js/unita.js (aggiungiSegnaposto), js/schermo.js (placeDots),
//    js/obiettivi.js e js/difese.js (colorDots), js/rete.js (rimuoviPartenze,
//    colorDots, placeDots), js/avvio.js (creaSegnaposto)
// ============================================================

// I segnaposto di controllo (div). Ognuno ricorda: il div, il punto che
// segna, quanto e' grande, il tipo ('ponte', 'ingresso', 'arrivo',
// 'partenza'), la squadra e l'asse a cui appartiene. Quelli di 'partenza'
// ricordano anche il loro personaggio (unita).
// Tutti i pallini e quadratini di debug sopra la mappa.
let segnaposto = [];

// Crea un segnaposto, lo aggiunge alla lista e lo restituisce
function aggiungiSegnaposto(punto, lato, tipo, team, asse) {
  // Ogni segnaposto e' un piccolo div HTML (il suo aspetto e' in css/arena.css).
  const div = document.createElement('div');
  div.className = 'punto ' + tipo;
  if (DEBUG) div.style.display = 'block';
  else       div.style.display = 'none';
  document.body.appendChild(div);
  const s = { div: div, punto: punto, lato: lato, tipo: tipo, team: team, asse: asse, unita: null };
  segnaposto.push(s);
  return s;
}

// I segnaposto fissi: quelli delle corsie e quelli intorno ai re.
// Quelli di partenza li aggiunge schiera(), uno per personaggio.
function creaSegnaposto() {
  for (const team of ['blue', 'red']) {
    for (const asse of ASSI[team]) {
      aggiungiSegnaposto(asse.bridge, DOT_SIZE, 'ponte',    team, asse);
      aggiungiSegnaposto(asse.entry,  SQUARE,   'ingresso', team, asse);
      aggiungiSegnaposto(asse.tower,  SQUARE,   'arrivo',   team, asse);
    }
  }
  // I quadrati intorno ai re (quelli delle corsie ci sono gia')
  for (const team of ['blue', 'red']) {
    for (const q of QUADRATI_TORRE[team]) {
      if (q.torre.type === 'king') aggiungiSegnaposto(q, SQUARE, 'arrivo', team, null);
    }
  }
}

// Toglie i segnaposto di partenza (nuova partita: i personaggi non ci sono piu')
function rimuoviPartenze() {
  const restano = [];
  for (const s of segnaposto) {
    // Nuova partita: via i pallini di partenza dei vecchi personaggi.
    if (s.tipo === 'partenza') s.div.remove();
    else                       restano.push(s);
  }
  segnaposto = restano;
}

// Mette ogni segnaposto sul suo punto della mappa
function placeDots() {
  for (const s of segnaposto) {
    const size = s.lato * mapScale;
    // Grandezza e posizione seguono lo zoom della mappa.
    s.div.style.width  = size + 'px';
    s.div.style.height = size + 'px';
    s.div.style.left   = toScreenX(s.punto.x) + 'px';
    s.div.style.top    = toScreenY(s.punto.y) + 'px';
  }
}

// Diventano verdi: gli assi scelti dai personaggi vivi (ingresso e ponte)
// e i quadrati di torre che fanno parte dei loro percorsi
function colorDots() {
  for (const s of segnaposto) {
    let scelto = false;
    for (const u of UNITA) {
      if (!u.alive || u.team !== s.team) continue;
      if ((s.tipo === 'ponte' || s.tipo === 'ingresso') && s.asse === u.axis) scelto = true;
      // Il quadrato e' verde se fa parte del percorso di un personaggio vivo.
      if (s.tipo === 'arrivo' && u.path.includes(s.punto)) scelto = true;
    }

    let classe = 'punto ' + s.tipo;
    if (s.tipo === 'ponte' && scelto) classe = 'punto bersaglio';   // il cerchio scelto
    else if (scelto)                  classe += ' scelto';
    if (s.team === 'red') classe += ' rossa';

    // Le classi decidono il colore (vedi css/arena.css).
    s.div.className = classe;

    // Il punto di partenza si vede solo finche' il suo personaggio e' vivo
    if (s.tipo === 'partenza') {
      if (DEBUG && s.unita.alive) s.div.style.display = 'block';
      else                        s.div.style.display = 'none';
    }
  }
}
