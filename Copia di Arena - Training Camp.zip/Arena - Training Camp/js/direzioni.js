// ============================================================
//  js/direzioni.js - LE 6 DIREZIONI DEGLI SPRITE
//
//  A COSA SERVE
//    Dice quale animazione usare in base alla direzione di marcia (o di
//    attacco), e quale animazione di riserva usare se una manca nel JSON.
//
//  DEFINISCE
//    DIREZIONI, sezionePer(), angoloDi(), direzioneDaAngolo()
//
//  USA
//    le sezioni del JSON del personaggio con il campo "urls", preparate da
//    inc/personaggi.php (const PERSONAGGI)
//
//  USATO DA
//    js/unita.js     (sezionePer: le animazioni di ogni personaggio)
//    js/avvio.js     (DIREZIONI, sezionePer: quali immagini caricare)
//    js/attacco.js   (angoloDi, direzioneDaAngolo: girarsi verso il bersaglio)
//    js/movimento.js (setDirection: la camminata giusta)
//    js/difese.js    (angoloDi: direzione della principessa e dei proiettili)
//    stessi nomi in importa_sprite.php e anteprima_animazioni.php ($riserva)
// ============================================================

// Ogni personaggio puo' guardare in 6 direzioni SULLO SCHERMO, ognuna con la
// sua camminata e il suo attacco:
//
//        left     forward     right         <- verso l'alto
//                    |
//      backLeft     back    backRight       <- verso il basso
//
// Per ogni direzione: il nome della sezione nel JSON per camminare ('walk')
// e per attaccare ('attack'). 'riserva' = la direzione da usare se nel JSON
// questa manca (es. manca attackRight -> si usa attack, quello dritto).
// SERVE A: collegare ogni direzione alle sue animazioni nel JSON, e dire quale
// usare se una manca (es. manca "a destra indietro": si usa "indietro").
const DIREZIONI = {
  forward:   { walk: 'walk',          attack: 'attack',          riserva: null },
  right:     { walk: 'walkRight',     attack: 'attackRight',     riserva: 'forward' },
  left:      { walk: 'walkLeft',      attack: 'attackLeft',      riserva: 'forward' },
  back:      { walk: 'walkBack',      attack: 'attackBack',      riserva: 'forward' },
  backRight: { walk: 'walkBackRight', attack: 'attackBackRight', riserva: 'back' },
  backLeft:  { walk: 'walkBackLeft',  attack: 'attackBackLeft',  riserva: 'back' }
};

// La sezione del JSON (cfg) per una direzione; tipo = 'walk' oppure 'attack'.
// Se manca, prova con la sua riserva, poi con la riserva della riserva...
function sezionePer(cfg, direzione, tipo) {
  let d = direzione;
  while (d !== null) {
    // Es. direzione 'right' + tipo 'walk' -> cerca cfg.walkRight.
    const sezione = cfg[DIREZIONI[d][tipo]];
    // Trovata e completa: si usa questa. Altrimenti si prova la riserva.
    if (sezione && sezione.urls) return sezione;
    d = DIREZIONI[d].riserva;
  }
  return null;   // non c'e' nemmeno quella dritta
}

// L'angolo di una direzione (dx, dy), in gradi:
// 0 = verso l'alto, positivo = verso destra, negativo = verso sinistra, 180 = verso il basso
function angoloDi(dx, dy) {
  // SERVE A: trasformare "verso dove vado" in un angolo in gradi:
  // 0 = su, 90 = destra, -90 = sinistra, 180 = giu'.
  // (Il -dy serve perche' sullo schermo la y cresce verso il basso.)
  return Math.atan2(dx, -dy) * 180 / Math.PI;   // atan2 da' radianti: * 180 / PI li fa gradi
}

// Da un angolo alla direzione giusta tra le 6.
// Entro "tolleranza" gradi dal dritto (su o giu') conta come dritto.
function direzioneDaAngolo(angolo, tolleranza) {
  // Conta quanto si gira, non da che lato: la regola vale uguale a destra e a sinistra.
  const quanto = Math.abs(angolo);   // quanto si gira, senza badare al lato
  const aDestra = angolo > 0;

  if (quanto <= tolleranza)       return 'forward';
  if (quanto >= 180 - tolleranza) return 'back';

  if (quanto <= 90) {                // diagonale verso l'alto
    if (aDestra) return 'right';
    return 'left';
  }
  if (aDestra) return 'backRight';   // diagonale verso il basso
  return 'backLeft';
}
