<?php
// ============================================================
//  inc/api.php - LE RISPOSTE AJAX DEL SERVER
//
//  A COSA SERVE
//    Quando JavaScript chiama arena.php?azione=..., questo file risponde con
//    un JSON e chiude lo script (exit): niente pagina HTML.
//      ?azione=stato    -> ora del server (ms) + la lobby del giocatore
//                          (giocatori, inizio partita, eventi/schieramenti)
//      ?azione=schiera  -> POST x, y, carta, cid: controlla e registra uno
//                          schieramento con il suo tick e il suo costo
//      ?azione=ricomincia -> POST: svuota gli schieramenti e fissa un nuovo
//                          inizio (la partita riparte da capo per entrambi)
//    Il server NON simula la partita: tiene solo l'ora d'inizio e la lista
//    degli schieramenti. La simulazione la fa ogni client (js/rete.js).
//
//  SI COLLEGA A
//    incluso da: arena.php (dopo inc/elisir.php)
//    usa:        lobby.php (apriLobby, chiudiLobby, pulisciLobby, cercaLobbyDi,
//                aggiornaVisto, squadraDi, oraMs), inc/elisir.php (elisirAl,
//                costoCarta), inc/personaggi.php ($cfgPersonaggi),
//                inc/prepara.php ($blocchi), inc/config.php ($mappa, $mazzi,
//                $limiteSchieramento, $ritardoSchieramento, $tickAlSecondo)
//    chiamato da: js/rete.js  -> chiediStato()   (ogni 150 ms)
//                 js/input.js -> clicGiocatore() (a ogni clic)
//                 js/ricomincia.js -> ricominciaPartita() (bottone Ricomincia)
//    scrive:     lobby.json (aggiornando 'visto' e aggiungendo eventi)
//
//  La riga qui sotto e' la "guardia": si usa solo dentro arena.php.
// ============================================================
defined('ARENA_DIR') or exit;

// SERVE A: capire cosa chiede il browser. Se l'indirizzo non ha ?azione=...
// e' una visita normale: nessuna risposta qui, si va avanti verso la pagina.
$azione = $_GET['azione'] ?? '';

// Risponde al client con un JSON e chiude
// SERVE A: mandare la risposta in JSON e FERMARE tutto: dopo una risposta
// AJAX non deve partire anche la pagina HTML.
function rispondi($dati) {
    header('Content-Type: application/json');
    echo json_encode($dati);
    exit;
}

// ---------- STATO: l'ora del server e la mia lobby ----------
if ($azione === 'stato') {
    $aperto = apriLobby($fileLobby);
    $ora = oraMs();
    $lobby = pulisciLobby($aperto['lobby'], $ora);
    $i = cercaLobbyDi($lobby, $utente['username']);
    // SERVE A: dire "il giocatore e' ancora collegato". Chi non si fa sentire per
    // 15 secondi e' considerato uscito e la sua partita viene chiusa.
    if ($i !== -1) aggiornaVisto($lobby, $i, $utente['username'], $ora);   // "ci sono ancora"
    chiudiLobby($aperto, $lobby, true);

    $miaLobby = null;
    if ($i !== -1) $miaLobby = $lobby[$i];
    rispondi(['ora' => $ora, 'lobby' => $miaLobby]);
}

// ---------- SCHIERA: il giocatore mette in campo una carta del suo mazzo ----------
// Se ne possono schierare quante se ne vuole: basta avere l'elisir.
if ($azione === 'schiera') {
    // SERVE A: trasformare in numero la posizione del clic (dal browser arriva come
    // testo). Se manca, -1 la fa scartare come "fuori dalla mappa".
    $x = (float) ($_POST['x'] ?? -1);
    $y = (float) ($_POST['y'] ?? -1);
    // La carta scelta dal giocatore (es. 'knight'), mandata da js/input.js.
    $carta = (string) ($_POST['carta'] ?? '');
    // Il "numero di ricevuta" scelto dal client: torna indietro dentro l'evento,
    // cosi' il client riconosce il suo schieramento quando arriva
    // SERVE A: proteggere lobby.json: la "ricevuta" del clic viene tagliata a 40
    // caratteri, cosi' nessuno puo' riempire il file di testo inutile.
    $cid = substr((string) ($_POST['cid'] ?? ''), 0, 40);

    $aperto = apriLobby($fileLobby);
    $ora = oraMs();
    $lobby = $aperto['lobby'];
    $i = cercaLobbyDi($lobby, $utente['username']);

    // Tutti i controlli: se uno fallisce, $errore dice perche'
    $errore = '';
    $squadra = null;
    $tickAdesso = 0;
    $costo = null;
    if ($i === -1) {
        $errore = 'Non sei in nessuna lobby.';
    } else {
        $squadra = squadraDi($lobby[$i], $utente['username']);
        // La carta deve essere nel mazzo della squadra; il costo lo dice il suo JSON
        // SICUREZZA: si accetta solo una carta del proprio mazzo, e il prezzo lo
        // decide il server leggendo il JSON (non il browser, che si puo' truccare).
        // Il true chiede un confronto esatto (niente conversioni tra testo e numeri).
        if (in_array($carta, $mazzi[$squadra], true)) {
            $costo = costoCarta($cfgPersonaggi, $squadra, $carta, $tickPerElisir);
        }
        // SERVE A: sapere quanto e' grande la mappa, per scartare i clic fuori.
        $dimensioni = getimagesize(ARENA_DIR . '/' . $mappa);   // [larghezza, altezza] della mappa

        if ($lobby[$i]['inizio'] === null || $ora < $lobby[$i]['inizio']) {
            $errore = 'La partita non e\' ancora iniziata.';
        } else {
            // Il tick in cui siamo adesso: e' qui che si paga l'elisir
            // SERVE A: sapere a che momento della partita siamo, in tick. E' la stessa
            // formula che usa il browser (js/avvio.js): cosi' sono sempre d'accordo.
            $tickAdesso = (int) floor(($ora - $lobby[$i]['inizio']) * $tickAlSecondo / 1000);
            if ($costo !== null && elisirAl($lobby[$i]['eventi'], $squadra, $tickAdesso, $elisirMassimoTick) < $costo) {
                $errore = 'Elisir insufficiente.';
            }
        }
        if ($x < 0 || $y < 0 || $x > $dimensioni[0] || $y > $dimensioni[1]) {
            $errore = 'Fuori dalla mappa.';
        }
        if ($squadra === 'blue' && $y < $limiteSchieramento['blue']) $errore = 'Puoi schierarlo solo nella tua meta\'.';
        if ($squadra === 'red'  && $y > $limiteSchieramento['red'])  $errore = 'Puoi schierarlo solo nella tua meta\'.';
        foreach ($blocchi as $b) {
            if (abs($x - $b['x']) < $b['halfW'] && abs($y - $b['y']) < $b['halfH']) {
                $errore = 'Non puoi schierarlo sopra una torre.';
            }
        }
        if ($costo === null) $errore = 'Questa carta non e\' nel tuo mazzo.';
    }

    // Se un controllo e' fallito: si chiude il file senza salvare e si spiega perche'.
    if ($errore !== '') {
        chiudiLobby($aperto, $lobby, false);
        rispondi(['ok' => false, 'errore' => $errore]);
    }

    // L'elisir si paga adesso ('clic'); il personaggio compare dopo il ritardo ('tick')
    // SERVE A: registrare lo schieramento nella partita. Entrambi i browser lo
    // riceveranno e faranno comparire il personaggio nello stesso tick.
    //   carta = quale personaggio
    //   costo = quanto e' costato (serve a ricalcolare l'elisir: inc/elisir.php)
    //   clic  = quando si paga l'elisir (adesso)
    //   tick  = quando compare (1 secondo dopo)
    //   cid   = la ricevuta, per far riconoscere al browser il suo clic
    $lobby[$i]['eventi'][] = [
        'squadra' => $squadra,
        'carta'   => $carta,
        'costo'   => $costo,
        'x'       => round($x, 2),
        'y'       => round($y, 2),
        'clic'    => $tickAdesso,
        'tick'    => $tickAdesso + $ritardoSchieramento,
        'cid'     => $cid,
    ];
    chiudiLobby($aperto, $lobby, true);
    rispondi(['ok' => true]);
}

// ---------- RICOMINCIA: la partita riparte da capo ----------
// SERVE A: azzerare la partita in qualsiasi momento (bottone in basso a destra,
// js/ricomincia.js). Il server non simula niente, quindi ricominciare vuol dire
// solo due cose: niente piu' schieramenti e una nuova ora d'inizio, con il solito
// conto alla rovescia. Ogni client si accorge che "inizio" e' cambiato e
// rifa' il campo da capo (js/rete.js, ricominciaDaCapo): vale per ENTRAMBI.
if ($azione === 'ricomincia') {
    // Solo POST: un semplice link o un'anteprima del browser non deve azzerare la partita.
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') rispondi(['ok' => false, 'errore' => 'Richiesta non valida.']);

    $aperto = apriLobby($fileLobby);
    $ora = oraMs();
    $lobby = $aperto['lobby'];
    $i = cercaLobbyDi($lobby, $utente['username']);

    $errore = '';
    if ($i === -1) {
        $errore = 'Non sei in nessuna lobby.';
    } elseif ($lobby[$i]['inizio'] === null) {
        $errore = 'Manca ancora l\'avversario: non c\'e\' niente da ricominciare.';
    }
    if ($errore !== '') {
        chiudiLobby($aperto, $lobby, false);
        rispondi(['ok' => false, 'errore' => $errore]);
    }

    $lobby[$i]['eventi'] = [];                       // campo vuoto, elisir di nuovo pieno
    $lobby[$i]['inizio'] = $ora + ATTESA_INIZIO;     // "Si parte tra 3..."
    chiudiLobby($aperto, $lobby, true);
    rispondi(['ok' => true]);
}
