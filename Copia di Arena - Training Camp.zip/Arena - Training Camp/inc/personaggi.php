<?php
// ============================================================
//  inc/personaggi.php - CARICAMENTO DELLE CARTE
//
//  A COSA SERVE
//    Per ogni squadra legge il JSON di OGNI carta del suo mazzo (es. Mini
//    P.E.K.K.A e Cavaliere) e, per ogni animazione (walk, attackRight...),
//    costruisce la lista completa degli indirizzi dei PNG. JavaScript cosi'
//    non deve indovinare i nomi dei file: li riceve gia' pronti in "urls".
//    Controlla anche che ogni carta abbia il suo costo ("elixir").
//
//  SI COLLEGA A
//    incluso da: arena.php (dopo inc/config.php)
//    usa:        $carte, $mazzi e $versione (inc/config.php)
//    legge:      characters/mini_pekka.json, mini_pekka_red.json,
//                knight_blue.json, knight_red.json (quelli citati in $carte)
//    produce:    $cfgPersonaggi[squadra][carta] -> inc/pagina.php ->
//                const PERSONAGGI in JS (js/unita.js, js/avvio.js,
//                js/mazzo.js, js/elisir.js, js/hud.js, js/input.js)
//                e in PHP inc/elisir.php (costoCarta) e inc/api.php
//                $errore -> inc/pagina.php (mostra l'errore al posto del gioco)
//    presta:     haSezione() ed elencoFrame() a inc/difese.php
//
//  La riga qui sotto e' la "guardia": si usa solo dentro arena.php.
// ============================================================
defined('ARENA_DIR') or exit;


// ---------- CARICAMENTO DEI PERSONAGGI ----------

// Una sezione del JSON (es. "walk") e' completa se ha prefix, firstFrame e lastFrame
function haSezione($cfg, $nome) {
    // SERVE A: capire se un'animazione nel JSON e' usabile. Servono tutte e tre le
    // informazioni (inizio del nome del file, primo e ultimo frame): se ne manca
    // anche una sola, quell'animazione viene ignorata.
    return isset($cfg[$nome]['prefix'], $cfg[$nome]['firstFrame'], $cfg[$nome]['lastFrame']);
}

// Lista dei PNG di una sezione, es. assets/mini_pekka/blue/mini_pekka_forward_blue_003.png
// str_pad scrive il numero sempre con 3 cifre: 3 -> "003", 12 -> "012"
function elencoFrame($cartella, $sezione, $versione) {
    $lista = [];
    for ($i = $sezione['firstFrame']; $i <= $sezione['lastFrame']; $i++) {
        // SERVE A: scrivere il numero del frame come nei nomi dei file: 3 -> "003".
        $numero  = str_pad($i, 3, '0', STR_PAD_LEFT);
        $lista[] = $cartella . '/' . $sezione['prefix'] . $numero . '.png?v=' . $versione;
    }
    return $lista;
}

// Legge il JSON di un personaggio e prepara la lista dei PNG di ogni animazione.
// Restituisce ['cfg' => i dati, 'errore' => '' se e' andato tutto bene]
function caricaPersonaggio($id, $versione) {
    $file = ARENA_DIR . '/characters/' . $id . '.json';
    if (!is_file($file)) {
        return ['cfg' => null, 'errore' => "Personaggio non trovato: characters/$id.json"];
    }

    // SERVE A: leggere il file JSON del personaggio e trasformarlo in un array
    // PHP, da cui leggere i dati con $cfg['walk'], $cfg['scale']...
    $cfg = json_decode(file_get_contents($file), true);
    if (!haSezione($cfg, 'walk')) {
        // SERVE A: spiegare chiaramente cosa non va, con il nome del file sbagliato.
        return ['cfg' => null, 'errore' => "characters/$id.json non valido: manca la sezione \"walk\" (prefix, firstFrame, lastFrame)."];
    }

    // La cartella delle immagini: quella scritta nel JSON, altrimenti 'assets'
    $cartella = 'assets';
    if (isset($cfg['assetsDir'])) {
        $cartella = $cfg['assetsDir'];
    }

    // Tutte le animazioni che il JSON puo' avere. Solo "walk" e' obbligatoria:
    // se ne manca una, JavaScript usa quella piu' simile (vedi DIREZIONI).
    // SERVE A: elencare tutte le animazioni che il gioco sa usare. Solo "walk" e'
    // obbligatoria: per le altre, se mancano, il gioco ne usa una simile.
    $animazioni = [
        'walk',     'walkRight',     'walkLeft',        // cammina verso l'alto
        'walkBack', 'walkBackRight', 'walkBackLeft',    // cammina verso il basso
        'attack',     'attackRight',     'attackLeft',      // attacca verso l'alto
        'attackBack', 'attackBackRight', 'attackBackLeft',  // attacca verso il basso
    ];
    foreach ($animazioni as $nome) {
        if (haSezione($cfg, $nome)) {
            // SERVE A: dare a JavaScript la lista COMPLETA dei PNG gia' pronta, es.
            // ['assets/mini_pekka/blue/mini_pekka_forward_blue_000.png', ..._001.png, ...]
            // cosi' JavaScript non deve ricostruire i nomi dei file.
            $cfg[$nome]['urls'] = elencoFrame($cartella, $cfg[$nome], $versione);
        }
    }
    // SERVE A: restituire due cose insieme: i dati e l'eventuale errore.
    return ['cfg' => $cfg, 'errore' => ''];
}

// Si caricano le carte dei due mazzi: $cfgPersonaggi[squadra][carta] = il suo JSON
$errore = '';
$cfgPersonaggi = ['blue' => [], 'red' => []];
// SERVE A: caricare tutte le carte che i due giocatori possono schierare.
// Risultato: $cfgPersonaggi['blue']['knight'] = il JSON del Cavaliere blu.
// Se una carta ha un problema, la pagina mostrera' l'errore invece del gioco.
foreach ($mazzi as $squadra => $mazzo) {
    foreach ($mazzo as $carta) {
        // Una carta del mazzo che non e' descritta in $carte: errore chiaro, e si salta.
        if (!isset($carte[$carta][$squadra])) {
            $errore = "La carta \"$carta\" del mazzo $squadra non e' in \$carte (inc/config.php).";
            continue;
        }
        $id = $carte[$carta][$squadra];
        $caricato = caricaPersonaggio($id, $versione);
        // SERVE A: non far partire una carta senza prezzo: server e browser non
        // saprebbero quanto elisir togliere.
        if ($caricato['errore'] === '' && !isset($caricato['cfg']['elixir'])) {
            $caricato['errore'] = "characters/$id.json non valido: manca \"elixir\" (quanto costa la carta).";
        }
        $cfgPersonaggi[$squadra][$carta] = $caricato['cfg'];
        if ($caricato['errore'] !== '') {
            $errore = $caricato['errore'];
        }
    }
}

