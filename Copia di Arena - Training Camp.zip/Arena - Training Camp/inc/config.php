<?php
// ============================================================
//  inc/config.php - LE IMPOSTAZIONI DEL GIOCO
//
//  A COSA SERVE
//    Raccoglie in un posto solo TUTTI i numeri che si possono cambiare:
//    mappa, torri (posizione, vita, immagini), corsie e ponti, carte e mazzi,
//    schieramento, elisir, blocchi solidi, debug. Non contiene logica:
//    solo variabili. Per cambiare il gioco si tocca soprattutto questo file.
//
//  SI COLLEGA A
//    incluso da: arena.php (e' il primo pezzo che viene caricato)
//    usato da:   inc/personaggi.php ($carte, $mazzi, $versione)
//                inc/prepara.php    (posizioni, corsie, solidi, barre...)
//                inc/difese.php     ($versione)
//                inc/elisir.php     (elisir, tick al secondo)
//                inc/api.php        ($mappa, $mazzi, $limiteSchieramento,
//                                    $ritardoSchieramento)
//                inc/pagina.php     (quasi tutto, trasformato in costanti JS:
//                                    $mazzi diventa MAZZI per js/mazzo.js)
//    il COSTO di ogni carta non e' qui: e' "elixir" nel JSON del personaggio.
//
//  UNITA' DI MISURA
//    "pixel della mappa" = pixel dell'immagine training_camp.png, NON dello
//    schermo. Il gioco li converte in pixel dello schermo in js/schermo.js,
//    cosi' tutto resta al suo posto qualunque sia la grandezza della finestra.
//
//  La riga qui sotto e' la "guardia": si usa solo dentro arena.php.
// ============================================================
// SERVE A: impedire di aprire questo file da solo dal browser.
// Si legge "ARENA_DIR esiste, altrimenti esci": esiste solo se il file e'
// stato incluso da arena.php.
defined('ARENA_DIR') or exit;


// Numero aggiunto in fondo agli indirizzi delle immagini (?v=...):
// cambia a ogni caricamento, cosi' il browser non usa immagini vecchie.
// SERVE A: far vedere SEMPRE le immagini aggiornate. Il browser tiene in
// memoria le immagini gia' viste; se modifichi un PNG potrebbe mostrarti
// quello vecchio. Aggiungendo ?v=<numero che cambia ogni secondo> in fondo
// all'indirizzo, il browser crede che sia un file nuovo e lo riscarica.
$versione = time();

// La mappa
$mappa = 'assets/training_camp/training_camp.png';

// Spazio vuoto intorno alla mappa, in pixel della mappa (su tutti e 4 i lati).
$margine = 100;

// Quanto dell'altezza della pagina occupano mappa + margine (0.9 = 90%, 1 = tutta).
$altezzaMappa = 0.9;

// Come e' fatta l'immagine di ogni tipo di torre:
//   'ancora' = il punto dell'immagine che va messo sulla posizione della torre
//   'scala'  = quanto ingrandire l'immagine
//   'cima'   = y del punto piu' alto della torre nell'immagine
//   'fondo'  = y del punto piu' basso della torre nell'immagine
//   'barra'  = grandezza della barra della vita
// SERVE A: sapere come disegnare ogni tipo di torre (dove "appoggiarla",
// quanto ingrandirla, dov'e' la cima per la barra della vita).
// Per leggere un valore si scende di livello: $tipi['king']['scala'] = 0.85.
$tipi = [
    'king'     => ['ancora' => [203, 182], 'scala' => 0.85, 'cima' => 69, 'fondo' => 295, 'barra' => 0.2],
    'princess' => ['ancora' => [201, 181], 'scala' => 0.8,  'cima' => 86, 'fondo' => 282, 'barra' => 0.1],
];

// Le torri: tipo, squadra e posizione (centro della piattaforma, in pixel della mappa).
// Rosso = in alto, blu = in basso.
// SERVE A: dire dove sta ogni torre e di che squadra e'.
// L'ORDINE CONTA: anche altre liste (blocchi solidi) vengono create in questo
// stesso ordine, e il gioco abbina la torre 1 al blocco 1, la 2 al 2...
$posizioni = [
    ['tipo' => 'king',     'squadra' => 'red',  'x' => 398, 'y' => 40],
    ['tipo' => 'princess', 'squadra' => 'red',  'x' => 149, 'y' => 173],
    ['tipo' => 'princess', 'squadra' => 'red',  'x' => 651, 'y' => 174],
    ['tipo' => 'princess', 'squadra' => 'blue', 'x' => 151, 'y' => 888],
    ['tipo' => 'princess', 'squadra' => 'blue', 'x' => 652, 'y' => 889],
    ['tipo' => 'king',     'squadra' => 'blue', 'x' => 404, 'y' => 1010],
];

// ---------- SOPRA LE TORRI: RE, CANNONE E PRINCIPESSE ----------
// Le immagini del re (cartella del re):
//   <squadra>_king.png, <squadra>_king_cannon.png e cannon_base.png (una per tutti)
// Le principesse sono quelle importate con importa_sprite.php
// (characters/princess_<squadra>.json, posa ferma "idle").
$cartellaRe = 'assets/king_tower';

// Dove stanno e quanto sono grandi:
//   'posizione' = [x, y] del CENTRO del disegno, rispetto al centro della torre,
//                 in pixel della mappa (y negativo = piu' in alto).
//                 Da qui partono anche i colpi: le frecce dalla principessa,
//                 le palle dal cannone.
//   'altezza'   = quanto e' alto il disegno sulla mappa, in pixel della mappa
// I bordi trasparenti dei PNG non contano: il gioco li toglie da solo.
// In cima alla torre del re c'e' una piattaforma: il re sta sul legno, nella
// meta' DIETRO (rosso: alta, blu: bassa), il cannone nella meta' DAVANTI,
// verso il centro dell'arena.
// SERVE A: posizionare re, cannone e principesse sopra le torri.
// Le posizioni servono anche a sapere da dove partono frecce e palle di cannone.
$sopraLeTorri = [
    're' => [
        'altezza'   => 62,
        'posizione' => ['red' => [0, -50], 'blue' => [0, -20]],
    ],
    'cannone' => [
        'altezza'   => 34,           // la base si ingrandisce insieme al cannone
        'posizione' => ['red' => [0, -8], 'blue' => [0, -52]],
        'base'      => [0, 0],       // la base sotto il cannone: spostamento rispetto al cannone
    ],
    'principessa' => [
        'altezza'   => 44,
        'posizione' => ['red' => [0, -30], 'blue' => [0, -28]],
    ],
];

// ---------- Barre della vita ----------
$cartellaUi = 'assets/ui';

// Vita iniziale delle torri (scende quando vengono attaccate)
$hp_princess = 3800;   // torri principessa
$hp_king     = 6300;   // torre del re

// Dove sta la barra: sopra la torre (rosse) o sotto la base (blu)
$posizioneBarra = ['red' => 'cima', 'blue' => 'base'];

// Grandezza delle barre RISPETTO ALLA MAPPA: la barra si ingrandisce e si
// rimpicciolisce insieme alla mappa, quindi con lo zoom resta sempre della
// stessa dimensione rispetto alle torri. Piu' alto = barre piu' grandi.
$scalaBarra = 5.5;
$distanzaBarra = ['red' => 15, 'blue' => 40];

// Barre dei personaggi: grandezza (come 'barra' delle torri) e quanto stanno
// sopra la cima dello sprite, in pixel della mappa (negativo = piu' in basso)
$scalaBarraPersonaggio    = 0.08;
$distanzaBarraPersonaggio = 2;

// ---------- LE CARTE E I MAZZI ----------
// Ogni carta e' un personaggio: per ogni squadra il nome del suo JSON nella
// cartella characters/. Tutto il resto (nome, vita, danno, velocita' e il
// costo in elisir "elixir") sta nel JSON.
// SERVE A: dire quale file JSON usa ogni carta per ogni squadra.
// Es. la carta 'knight' della squadra blu e' characters/knight_blue.json.
// Per aggiungere una carta: una riga qui + i suoi due JSON (blu e rosso).
$carte = [
    'mini_pekka' => ['blue' => 'mini_pekka',  'red' => 'mini_pekka_red'],
    'knight'     => ['blue' => 'knight_blue', 'red' => 'knight_red'],
    'valkyrie'   => ['blue' => 'valkyrie_blue', 'red' => 'valkyrie_red'],
];

// Il mazzo di ogni squadra: le carte che puo' schierare, nell'ordine dei
// bottoni sullo schermo. Per ora sono uguali; in futuro, per esempio:
//   'blue' => ['knight', 'prince'],      'red' => ['mini_pekka', 'valkyrie'],
// SERVE A: decidere quali carte puo' schierare ogni giocatore, e in che ordine
// compaiono i bottoni a sinistra (js/mazzo.js). Il server controlla questo
// elenco: una carta fuori dal mazzo viene rifiutata (inc/api.php).
$mazzi = [
    'blue' => ['mini_pekka', 'knight', 'valkyrie'],
    'red'  => ['mini_pekka', 'knight', 'valkyrie'],
];

// ---------- CORSIE ----------
// Ogni ponte ha un 'asse' (la x del centro del ponte) e, PER OGNI SQUADRA,
// tre y in pixel della mappa:
//   'ingresso' = y dei quadrati PRIMA del ponte (nella propria meta')
//   'ponte'    = y dei cerchi sul ponte
//   'torre'    = y dei quadrati DAVANTI alle torri avversarie (dove si ferma)
// Sono stime fatte sul tuo schermo: usa i segnaposto per controllare.
// SERVE A: descrivere la strada che fanno i personaggi: prima del ponte,
// sul ponte, davanti alla torre nemica. Da qui si ricavano anche i ponti
// per attraversare il fiume.
$corsie = [
    [   // ponte di sinistra
        'asse' => 151,
        'blue' => ['ingresso' => 610, 'ponte' => 545, 'torre' => 260],
        'red'  => ['ingresso' => 510, 'ponte' => 575, 'torre' => 800],
    ],
    [   // ponte di destra
        'asse' => 659,
        'blue' => ['ingresso' => 610, 'ponte' => 545, 'torre' => 260],
        'red'  => ['ingresso' => 510, 'ponte' => 575, 'torre' => 800],
    ],
];

// I quadrati intorno alle torri del re (da dove si attacca il re): due ai lati
// e due davanti. Per ogni quadrato: [spostamento in x, spostamento verso il
// centro dell'arena], rispetto al centro della torre del re, in pixel della mappa.
// Valgono per tutte e due le torri del re (per quella blu "verso il centro" e' in su).
// SERVE A: indicare da dove i personaggi attaccano il re (ai lati e davanti),
// una volta caduta la torre principessa.
$quadratiRe = [
    [-107,  39],   // a sinistra
    [ 107,  39],   // a destra
    [ -58, 119],   // davanti a sinistra
    [  58, 119],   // davanti a destra
];

// Distanza tra un asse e l'altro: gli assi sono a -scarto, 0 e +scarto dal centro.
// I punti di uno stesso asse hanno la stessa x, quindi si attraversa dritti.
$scarto = 26;

// Grandezze dei segnaposto, in pixel della mappa
$latoQuadrato     = 24;   // quadrati d'ingresso e d'arrivo
$diametroCerchio  = 20;   // cerchi sul ponte

// ---------- SCHIERAMENTO ----------
// Dove ogni giocatore puo' schierare le sue carte (la sua meta'):
//   blu   -> solo SOTTO la sua y (y piu' grande)
//   rosso -> solo SOPRA la sua y (y piu' piccola)
// In ogni caso mai dentro una torre.
// SERVE A: impedire di schierare nella meta' avversaria.
// Viene controllato due volte: nel browser (per avvisare subito il giocatore)
// e sul server (perche' il browser si puo' "truccare").
$limiteSchieramento = ['blue' => 600, 'red' => 520];

// Dopo quanti tick dal clic il personaggio compare (60 tick = 1 secondo).
// Serve a far arrivare lo schieramento a tutti e due i client prima che valga.
// SERVE A: dare il tempo al clic di arrivare all'avversario. Il personaggio
// compare 1 secondo dopo il clic, cosi' entrambi i giocatori ricevono
// l'informazione PRIMA che debba comparire.
$ritardoSchieramento = 60;

// Tick al secondo della simulazione (deve essere uguale a TICK_RATE in JavaScript)
// SERVE A: dare al gioco un "orologio" comune. Il tempo si conta in tick
// (60 al secondo): server e client contano allo stesso modo, quindi sono
// sempre d'accordo su che momento della partita e'.
$tickAlSecondo = 60;

// ---------- ELISIR ----------
// Ogni giocatore ha la sua barra di elisir: si parte pieni, ogni carta
// schierata costa elisir (quanto, lo dice "elixir" nel suo JSON) e la barra
// si ricarica da sola col tempo. Si schiera quanto si vuole, se c'e' l'elisir.
// SERVE A: regolare l'economia della partita (quanto elisir e quanto in fretta
// si ricarica). Quanto costa ogni carta lo dice "elixir" nel suo JSON.
$elisirMassimo    = 10;   // elisir con la barra piena (= numero di tacche della barra)
$secondiPerElisir = 2;    // ogni quanti secondi torna 1 di elisir

// La barra sullo schermo: dalla parte del proprio campo (blu in basso, rosso in alto)
$barraElisir = [
    'larghezza' => 0.6,   // rispetto alla larghezza della mappa (0.6 = 60%)
    'altezza'   => 44,    // in pixel della mappa: segue lo zoom come tutto il resto
    'bordo'     => 8,     // distanza dal bordo della finestra, in pixel dello schermo
];

// ---------- TORRI SOLIDE ----------
// Ogni torre e' un rettangolo che non si puo' attraversare, centrato sulla
// torre. Per tipo: [meta' larghezza, meta' altezza], in pixel della mappa.
// SERVE A: rendere le torri "solide": i personaggi ci girano intorno invece di
// attraversarle, e non ci si puo' schierare sopra.
$solidi = [
    'king'     => [60, 55],
    'princess' => [45, 45],
];
// "Spessore" dei personaggi: allarga i rettangoli, cosi' non ci entrano
// nemmeno con il corpo (il loro punto e' il centro dello sprite).
$raggio = 12;

// Mostrare i segnaposto di controllo? (true = si, false = nascosti)
// SERVE A: vedere cosa "pensa" il gioco (percorsi, segnaposto, raggi delle
// torri, blocchi solidi). Utile mentre lo sviluppi; per giocare metti false.
// Con false spariscono anche le righe di info in basso a destra (js/hud.js):
// restano solo gli avvisi di gioco (es. "Elisir insufficiente").
$debug = false;
