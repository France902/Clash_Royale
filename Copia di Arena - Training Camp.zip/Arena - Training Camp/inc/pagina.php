<?php
// ============================================================
//  inc/pagina.php - LA PAGINA HTML DELL'ARENA
//
//  A COSA SERVE
//    Manda al browser la pagina: i due pannelli dei giocatori, il canvas, la
//    riga di info, la base della barra dell'elisir, la pila delle carte e gli
//    script. E' il PONTE tra PHP e JavaScript: le variabili preparate dagli
//    altri file inc/ diventano costanti JavaScript (blocco script qui sotto)
//    grazie a json_encode. Il resto del codice sta nei file della cartella js/.
//
//  SI COLLEGA A
//    incluso da: arena.php (ultimo pezzo, solo per le visite normali)
//    usa:        inc/config.php ($mazzi...), inc/personaggi.php ($cfgPersonaggi,
//                $errore), inc/prepara.php, inc/difese.php, inc/elisir.php,
//                $miaSquadra (arena.php)
//    carica:     css/arena.css e i 21 file js/ (l'ORDINE e' importante)
//    link:       logout.php (se c'e' un errore)
//
//  La riga qui sotto e' la "guardia": si usa solo dentro arena.php.
// ============================================================
defined('ARENA_DIR') or exit;

?>
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="utf-8">
<title>Arena - Training Camp</title>
<!-- Lo stile della pagina, con ?v= per avere sempre la versione aggiornata. -->
<link rel="stylesheet" href="css/arena.css?v=<?= $versione ?>">
</head>
<body>

<!-- I pannelli dei due giocatori: li riempie JavaScript con i dati della lobby -->
<!-- Pannelli vuoti: li riempie js/hud.js quando arrivano i dati della partita. -->
<div class="giocatore" id="pannello-red"></div>
<div class="giocatore" id="pannello-blue"></div>

<!-- Se un personaggio non si e' caricato, si mostra l'errore invece del gioco. -->
<?php if ($errore): ?>
  <div style="color:#ff8080;padding:80px 10px 10px"><?= htmlspecialchars($errore) ?> <a href="logout.php" style="color:#fff">Esci</a></div>
<?php else: ?>

<!-- canvas = la tela su cui si disegna il gioco. #info = le righe di testo in basso a destra. -->
<canvas id="stage"></canvas>
<div id="info"></div>

<!-- La barra dell'elisir: questo div e' la BASE scura, le 10 tacche le crea js/elisir.js -->
<div id="elisir"></div>

<!-- Le carte del mio mazzo, una pila di bottoni a sinistra: li crea js/mazzo.js -->
<!-- Vuoto: i bottoni delle carte li crea js/mazzo.js (creaPilaCarte). -->
<div id="carte"></div>

<!-- Il bottone per ricominciare la partita, in basso a destra della PAGINA: js/ricomincia.js -->
<button id="ricomincia" type="button">&#x21bb; Ricomincia</button>

<script>
// ---------- IMPOSTAZIONI (arrivano da PHP) ----------
// SERVE A: passare i dati da PHP a JavaScript.
// PHP scrive qui i valori gia' pronti, e il browser li legge come normali
// costanti JavaScript. Aprendo "Visualizza sorgente" nel browser si vedono
// i numeri veri al posto del codice PHP.
const MAP_URL      = <?= json_encode($mappa . '?v=' . $versione) ?>;
const MARGIN       = <?= (int)$margine ?>;
const MAP_HEIGHT   = <?= (float)$altezzaMappa ?>;
const TOWERS       = <?= json_encode($torri, JSON_UNESCAPED_SLASHES) ?>;
const BARS         = <?= json_encode($barre, JSON_UNESCAPED_SLASHES) ?>;
const SOPRA_TORRI  = <?= json_encode($sopraTorri, JSON_UNESCAPED_SLASHES) ?>; // re e cannone di ogni squadra
const DIFESE       = <?= json_encode($difese, JSON_UNESCAPED_SLASHES) ?>;     // come sparano le torri (+ animazioni della principessa)
const ASSI         = <?= json_encode($assi) ?>;          // per squadra: { blue: [6 assi], red: [6 assi] }
const SOLIDS       = <?= json_encode($blocchi) ?>;       // le torri come blocchi solidi
const SQUARE       = <?= (int)$latoQuadrato ?>;          // lato dei quadrati, in pixel della mappa
const DOT_SIZE     = <?= (int)$diametroCerchio ?>;       // diametro dei cerchi, in pixel della mappa
// Si scrive esplicitamente 'true' o 'false': PHP da solo stamperebbe "1" o
// niente, e JavaScript riceverebbe una riga sbagliata.
const DEBUG        = <?= $debug ? 'true' : 'false' ?>;
const BAR_K        = <?= (float)$scalaBarra ?>;          // grandezza delle barre rispetto alla mappa
const CHAR_BAR_K   = <?= (float)$scalaBarraPersonaggio ?>;    // grandezza delle barre dei personaggi
const CHAR_BAR_GAP = <?= (float)$distanzaBarraPersonaggio ?>; // distanza della barra dalla cima dello sprite
const PERSONAGGI   = <?= json_encode($cfgPersonaggi, JSON_UNESCAPED_SLASHES) ?>; // i JSON delle carte: { blue: { mini_pekka: ..., knight: ... }, red: ... }
// Le carte di ogni squadra: js/mazzo.js mostra quelle della mia (MIA_SQUADRA).
const MAZZI        = <?= json_encode($mazzi) ?>;   // le carte di ogni squadra, in ordine
const QUADRATI_RE  = <?= json_encode($quadratiRe) ?>;    // i quadrati intorno alle torri del re
const LIMITI       = <?= json_encode($limiteSchieramento) ?>; // blu schiera sotto, rosso sopra
const MIA_SQUADRA  = <?= json_encode($miaSquadra) ?>;    // 'blue' o 'red': la squadra di chi guarda
const FAZIONI      = <?= json_encode($fazioniPerJs) ?>;  // nome, colore e icona di ogni fazione
const PONTI        = <?= json_encode($ponti) ?>;         // per ogni ponte: x del centro, y delle sponde nord e sud
const MEZZO_PONTE  = <?= (int)$mezzaLarghezzaPonte ?>;   // fin dove (in x dal centro) si e' sul ponte
const MARGINE_PORTE = <?= (int)$scarto ?>;               // le porte dei ponti stanno al massimo qui dal centro

// La parte colorata dentro l'immagine della barra della vita
const BAR_FILL = { x: 2, y: 2, w: 205, h: 17 };

// Aggiornamenti della logica al secondo (deve essere uguale a $tickAlSecondo in PHP)
// Deve essere uguale in PHP e JavaScript: e' l'orologio comune della partita.
const TICK_RATE = <?= (int)$tickAlSecondo ?>;

// L'elisir, in "tick di ricarica" (vedi inc/elisir.php): 1 di elisir = TICK_PER_ELISIR
const TACCHE          = <?= (int)$elisirMassimo ?>;      // quante tacche ha la barra (elisir massimo)
const TICK_PER_ELISIR = <?= (int)$tickPerElisir ?>;      // tick per ricaricare 1 di elisir
const ELISIR_MAX      = <?= (int)$elisirMassimoTick ?>;  // la barra piena
const BARRA_ELISIR    = <?= json_encode($barraElisir) ?>; // grandezza e posizione della barra
</script>

<!-- L'ORDINE CONTA: ogni file usa cose dei file prima di lui -->
<!-- SERVE A: caricare il gioco, un file per ogni compito. Tutti i file condividono le stesse variabili e funzioni. -->
<script src="js/utilita.js?v=<?= $versione ?>"></script>
<script src="js/direzioni.js?v=<?= $versione ?>"></script>
<script src="js/fiume.js?v=<?= $versione ?>"></script>
<script src="js/solidi.js?v=<?= $versione ?>"></script>
<script src="js/torri.js?v=<?= $versione ?>"></script>
<script src="js/unita.js?v=<?= $versione ?>"></script>
<script src="js/obiettivi.js?v=<?= $versione ?>"></script>
<script src="js/attacco.js?v=<?= $versione ?>"></script>
<script src="js/movimento.js?v=<?= $versione ?>"></script>
<script src="js/difese.js?v=<?= $versione ?>"></script>
<script src="js/schermo.js?v=<?= $versione ?>"></script>
<script src="js/segnaposto.js?v=<?= $versione ?>"></script>
<script src="js/disegno.js?v=<?= $versione ?>"></script>
<script src="js/sopra_torri.js?v=<?= $versione ?>"></script>
<script src="js/hud.js?v=<?= $versione ?>"></script>
<script src="js/elisir.js?v=<?= $versione ?>"></script>
<script src="js/mazzo.js?v=<?= $versione ?>"></script>
<script src="js/input.js?v=<?= $versione ?>"></script>
<script src="js/rete.js?v=<?= $versione ?>"></script>
<script src="js/ricomincia.js?v=<?= $versione ?>"></script>
<script src="js/avvio.js?v=<?= $versione ?>"></script>

<?php endif; ?>

</body>
</html>
