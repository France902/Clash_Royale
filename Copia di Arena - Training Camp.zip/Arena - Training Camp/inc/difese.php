<?php
// ============================================================
//  inc/difese.php - COME SPARANO LE TORRI
//
//  A COSA SERVE
//    Prepara per JavaScript i parametri di tiro delle torri (raggio, danno,
//    velocita' d'attacco, proiettile...) e le animazioni della principessa.
//
//    I PARAMETRI stanno nella sezione "tower" di:
//      characters/princess.json  -> torri principessa (tutte e due le squadre)
//      characters/king.json      -> torri del re
//    Le ANIMAZIONI della principessa stanno nel JSON di ogni squadra, quello
//    creato da importa_sprite.php (characters/princess_red.json e
//    princess_blue.json). Una sezione "tower" dentro quei due file NON conta.
//    Il significato di ogni parametro e' scritto in cima a js/difese.js.
//
//  SI COLLEGA A
//    incluso da: arena.php (dopo inc/prepara.php)
//    usa:        haSezione(), elencoFrame() (inc/personaggi.php), $versione
//    legge:      characters/princess.json, king.json, princess_<squadra>.json
//    produce:    $difese -> inc/pagina.php -> const DIFESE
//                -> js/difese.js (logica del tiro) e js/sopra_torri.js (disegno)
//
//  La riga qui sotto e' la "guardia": si usa solo dentro arena.php.
// ============================================================
defined('ARENA_DIR') or exit;


// Legge un JSON e lo restituisce come array ([] se manca o non e' valido)
function leggiJson($file) {
    if (!is_file($file)) return [];
    $dati = json_decode(file_get_contents($file), true);
    if (!is_array($dati)) return [];
    return $dati;
}

// Tutto quello che serve a JavaScript per una torre ($id = 'princess' o 'king')
function caricaDifesa($id, $squadra, $versione) {
    // I parametri: dal JSON comune
    $comune = leggiJson(ARENA_DIR . '/characters/' . $id . '.json');
    // SERVE A: non bloccare il gioco se nel JSON manca la sezione "tower":
    // in quel caso si parte da una lista vuota e JavaScript usa i valori predefiniti.
    $torre  = $comune['tower'] ?? [];

    // L'immagine del proiettile: nel nome, {team} diventa la squadra
    $proiettile = $torre['projectile'] ?? [];
    $proiettile['url'] = null;
    if (isset($proiettile['image'])) {
        // SERVE A: usare un solo nome di file nel JSON per tutte e due le squadre:
        // "arrow_{team}.png" diventa "arrow_red.png" o "arrow_blue.png".
        $proiettile['url'] = str_replace('{team}', $squadra, $proiettile['image']) . '?v=' . $versione;
    }
    $torre['projectile'] = $proiettile;

    // Le animazioni: dal JSON della squadra (solo la principessa ne ha).
    // stdClass = oggetto vuoto: in JavaScript diventa {} anche senza animazioni
    $animato  = leggiJson(ARENA_DIR . '/characters/' . $id . '_' . $squadra . '.json');
    $cartella = $animato['assetsDir'] ?? 'assets/' . $id . '_tower/' . $squadra;
    // SERVE A: far arrivare a JavaScript SEMPRE un oggetto {}, anche quando la torre
    // non ha animazioni (il re). Un array PHP vuoto arriverebbe come lista [],
    // e JavaScript si aspetta un oggetto con i nomi delle animazioni.
    $torre['sezioni'] = new stdClass();
    foreach (['idle', 'attack', 'attackRight', 'attackLeft'] as $nome) {
        if (haSezione($animato, $nome)) {
            // SERVE A: aggiungere all'oggetto l'animazione con il suo nome (idle, attack...).
            $torre['sezioni']->$nome = elencoFrame($cartella, $animato[$nome], $versione);
        }
    }
    // Da che numero partono i PNG dell'attacco (serve per "shootFrame")
    // SERVE A: sapere da che numero partono i PNG, per trovare il frame esatto in
    // cui la principessa scocca la freccia.
    $torre['firstFrame'] = $animato['attack']['firstFrame'] ?? 0;
    return $torre;
}

$difese = [];
foreach (['red', 'blue'] as $squadra) {
    $difese[$squadra] = [
        'princess' => caricaDifesa('princess', $squadra, $versione),
        'king'     => caricaDifesa('king',     $squadra, $versione),
    ];
}
