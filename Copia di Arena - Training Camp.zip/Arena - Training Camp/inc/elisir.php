<?php
// ============================================================
//  inc/elisir.php - QUANTO ELISIR HA UNA SQUADRA
//
//  A COSA SERVE
//    Il server non tiene un "contatore" di elisir: lo RICALCOLA ogni volta
//    dagli schieramenti, esattamente come fa il client (js/elisir.js). Cosi'
//    i due conti sono sempre uguali, anche ricaricando la pagina.
//    Ogni carta ha il suo costo ("elixir" nel suo JSON); ogni schieramento
//    si ricorda quanto e' costato (campo 'costo' dell'evento).
//
//    Si conta in TICK DI RICARICA invece che in elisir: 1 di elisir =
//    $tickPerElisir tick. Sono numeri interi, quindi PHP e JavaScript non
//    possono arrotondare in modo diverso.
//
//  SI COLLEGA A
//    incluso da: arena.php (dopo inc/difese.php)
//    usa:        $secondiPerElisir, $tickAlSecondo, $elisirMassimo
//                (inc/config.php), $cfgPersonaggi (inc/personaggi.php)
//    usato da:   inc/api.php (azione=schiera: costoCarta e "hai abbastanza elisir?")
//                inc/pagina.php (TICK_PER_ELISIR, ELISIR_MAX)
//    gemello:    js/elisir.js, funzioni costoCarta() ed elisirAl(): STESSO
//                conto. Se si cambia uno, va cambiato anche l'altro!
//    dati:       gli eventi della lobby (lobby.json), campi 'clic' e 'costo'
//
//  La riga qui sotto e' la "guardia": si usa solo dentro arena.php.
// ============================================================
defined('ARENA_DIR') or exit;


// SERVE A: contare l'elisir con numeri INTERI. 1 di elisir = 120 tick
// (2 secondi * 60). Con gli interi PHP e JavaScript non possono arrotondare in
// modo diverso e trovarsi in disaccordo.
$tickPerElisir     = (int) round($secondiPerElisir * $tickAlSecondo);   // 2 s * 60 = 120
$elisirMassimoTick = $elisirMassimo * $tickPerElisir;                   // barra piena

// Quanto costa una carta di una squadra, in tick di ricarica (null = non c'e')
// SERVE A: trasformare il costo della carta in tick di ricarica.
// Es. Cavaliere: elixir 3 -> 3 * 120 = 360 tick. null = carta sconosciuta.
function costoCarta($cfgPersonaggi, $squadra, $carta, $tickPerElisir) {
    if (!isset($cfgPersonaggi[$squadra][$carta]['elixir'])) return null;
    return (int) round($cfgPersonaggi[$squadra][$carta]['elixir'] * $tickPerElisir);
}

// L'elisir di una squadra al tick dato (in tick di ricarica).
// Si parte con la barra piena. Ogni schieramento, nel tick del CLIC ('clic'),
// toglie il SUO costo ('costo', scritto nell'evento quando e' stato fatto);
// tra uno schieramento e l'altro la barra cresce di 1 per tick, ma mai oltre
// il massimo. Gli schieramenti sono in ordine di tempo.
function elisirAl($eventi, $squadra, $tick, $massimo) {
    // Prima dell'inizio della partita la barra e' piena (tick negativi = 0).
    $tick   = max($tick, 0);      // prima dell'inizio la barra e' piena
    $elisir = $massimo;
    $ultimo = 0;                  // il tick dell'ultimo conto fatto
    foreach ($eventi as $e) {
        // Si considerano solo gli schieramenti di QUESTA squadra gia' avvenuti.
        if ($e['squadra'] !== $squadra || $e['clic'] > $tick) continue;
        // Il conto, passo per passo:
        //   1) dall'ultimo schieramento a questo la barra si e' ricaricata
        //   2) ma non oltre il pieno (min)
        //   3) poi si paga quella carta (il suo costo e' scritto nell'evento)
        $elisir = min($massimo, $elisir + ($e['clic'] - $ultimo)) - $e['costo'];
        $ultimo = $e['clic'];
    }
    return min($massimo, $elisir + ($tick - $ultimo));
}
