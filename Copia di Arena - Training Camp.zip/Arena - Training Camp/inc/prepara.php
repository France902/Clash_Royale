<?php
// ============================================================
//  inc/prepara.php - I DATI PRONTI PER JAVASCRIPT
//
//  A COSA SERVE
//    Trasforma le impostazioni "comode da scrivere" di inc/config.php nei
//    dati "comodi da usare" per JavaScript: assi delle corsie, blocchi solidi,
//    torri con immagine e vita, cosa sta sopra le torri, barre della vita,
//    fazioni e ponti. Non disegna e non decide niente: prepara.
//
//  SI COLLEGA A
//    incluso da: arena.php (dopo inc/personaggi.php)
//    usa:        inc/config.php (corsie, posizioni, tipi, solidi, raggio,
//                cartelle, hp...) e fazioni.php ($fazioni)
//    produce (variabile PHP -> costante JS in inc/pagina.php -> file JS):
//      $assi          -> ASSI        -> js/torri.js, js/unita.js, js/segnaposto.js
//      $blocchi       -> SOLIDS      -> js/solidi.js, js/torri.js, js/input.js
//                        (e in PHP: inc/api.php, niente schieramenti sulle torri)
//      $torri         -> TOWERS      -> quasi tutti i file JS
//      $sopraTorri    -> SOPRA_TORRI -> js/sopra_torri.js, js/difese.js
//      $barre         -> BARS        -> js/disegno.js, js/avvio.js
//      $fazioniPerJs  -> FAZIONI     -> js/hud.js (pannelli dei giocatori)
//      $ponti         -> PONTI       -> js/fiume.js
//      $mezzaLarghezzaPonte -> MEZZO_PONTE -> js/fiume.js
//
//  La riga qui sotto e' la "guardia": si usa solo dentro arena.php.
// ============================================================
defined('ARENA_DIR') or exit;


// Gli ASSI di ogni squadra: 3 per ponte, 6 in tutto.
// Ogni asse ha 3 punti sulla stessa x: ingresso, ponte e torre avversaria.
$assi = ['blue' => [], 'red' => []];
foreach ($corsie as $corsia) {
    // SERVE A: creare 3 strade per ogni ponte (sinistra, centro, destra), cosi'
    // piu' personaggi non camminano tutti sulla stessa riga.
    foreach ([-$scarto, 0, $scarto] as $spostamento) {   // sinistra, centro, destra
        $x = $corsia['asse'] + $spostamento;
        foreach (['blue', 'red'] as $squadra) {
            $y = $corsia[$squadra];
            // SERVE A: aggiungere una strada alla lista della squadra. Ogni strada ha 3 punti
            // sulla stessa x: prima del ponte, sul ponte, davanti alla torre nemica.
            $assi[$squadra][] = [
                'entry'  => ['x' => $x, 'y' => $y['ingresso']],
                'bridge' => ['x' => $x, 'y' => $y['ponte']],
                'tower'  => ['x' => $x, 'y' => $y['torre']],
            ];
        }
    }
}

// I blocchi solidi: uno per torre (centro + meta' larghezza/altezza, gia' allargate)
$blocchi = [];
foreach ($posizioni as $torre) {
    $tipo = $torre['tipo'];
    $blocchi[] = [
        'x'     => $torre['x'],
        'y'     => $torre['y'],
        // SERVE A: tenere lontano dalla torre tutto il corpo del personaggio, non solo
        // il suo centro: il rettangolo viene allargato del suo "spessore".
        'halfW' => $solidi[$tipo][0] + $raggio,   // meta' larghezza
        'halfH' => $solidi[$tipo][1] + $raggio,   // meta' altezza
    ];
}

// Tutto quello che serve per disegnare le torri
$torri = [];
foreach ($posizioni as $torre) {
    $tipo    = $torre['tipo'];
    $squadra = $torre['squadra'];

    if ($tipo === 'king') {
        $vita = $hp_king;
    } else {
        $vita = $hp_princess;
    }

    $torri[] = [
        // SERVE A: costruire il nome dell'immagine, es. assets/king_tower/king_tower_red.png
        // Le graffe dicono a PHP dove finisce il nome della variabile: senza,
        // leggerebbe "$tipo_tower" come un'unica variabile (che non esiste).
        'url'     => "assets/{$tipo}_tower/{$tipo}_tower_{$squadra}.png?v=" . $versione,
        'type'    => $tipo,
        'team'    => $squadra,
        'anchorX' => $tipi[$tipo]['ancora'][0],
        'anchorY' => $tipi[$tipo]['ancora'][1],
        'scale'   => $tipi[$tipo]['scala'],
        'top'     => $tipi[$tipo]['cima'],
        'bottom'  => $tipi[$tipo]['fondo'],
        'bar'     => $tipi[$tipo]['barra'],
        'hp'      => $vita,
        'x'       => $torre['x'],
        'y'       => $torre['y'],
    ];
}

// Cosa sta sopra le torri del re: per ogni squadra il re e il suo cannone,
// piu' la base del cannone (una per tutti). Le principesse sono in inc/difese.php
// SERVE A: preparare le immagini di re e cannone per ogni squadra.
$sopraTorri = [
    'base'  => "$cartellaRe/cannon_base.png?v=" . $versione,
    'pezzi' => $sopraLeTorri,   // posizioni e grandezze
];
foreach (['red', 'blue'] as $squadra) {
    $sopraTorri[$squadra] = [
        're'          => "$cartellaRe/{$squadra}_king.png?v=" . $versione,
        'cannone'     => "$cartellaRe/{$squadra}_king_cannon.png?v=" . $versione,
    ];
}

$barre = [
    'base'     => "$cartellaUi/health_bar_base.png?v=" . $versione,
    'red'      => "$cartellaUi/health_bar_red.png?v="  . $versione,
    'blue'     => "$cartellaUi/health_bar_blue.png?v=" . $versione,
    'gap'      => $distanzaBarra,
    'position' => $posizioneBarra,
];

// Per i pannelli dei giocatori: di ogni fazione bastano nome, colore e icona
// SERVE A: mandare a JavaScript solo cio' che serve ai pannelli (nome, colore,
// icona); il motto si vede solo nella pagina di accesso.
$fazioniPerJs = [];
foreach ($fazioni as $chiave => $f) {
    $fazioniPerJs[$chiave] = ['nome' => $f['nome'], 'colore' => $f['colore'], 'icona' => $f['icona']];
}

// I PONTI, ricavati dalle corsie: per ognuno la x del centro e le y delle due
// sponde (nord = ingresso dei rossi, sud = ingresso dei blu). Servono per
// attraversare il fiume quando si insegue un nemico dall'altra parte.
// SERVE A: dire a JavaScript dove sono i ponti, per attraversare il fiume
// quando un personaggio insegue un nemico dall'altra parte.
$ponti = [];
foreach ($corsie as $corsia) {
    $ponti[] = ['x' => $corsia['asse'], 'nord' => $corsia['red']['ingresso'], 'sud' => $corsia['blue']['ingresso']];
}
$mezzaLarghezzaPonte = $scarto + 4;   // fin dove (in x dal centro) si e' ancora sul ponte
